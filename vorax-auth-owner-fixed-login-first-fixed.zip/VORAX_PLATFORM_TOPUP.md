# VORAX — Platform Top-Up Flow

- Customers create top-up requests from `/wallet`.
- Requests are stored as `TopUpRequest(PENDING)`.
- Owner reviews requests from `/admin/topups`.
- Confirming credits the user's wallet and writes a `BalanceTransaction` with type `TOPUP`.
- Rejecting only changes the request status.
- Telegram top-up request/approval endpoints and the standalone Telegram top-up polling bot were removed.
- Telegram remains available for the platform chat/linking features.
