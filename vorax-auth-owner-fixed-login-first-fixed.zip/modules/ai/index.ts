// VORAX ai module boundary. Keep domain code isolated from unrelated modules.
export {};
