import type { Config } from "tailwindcss";

const config: Config = {
  content: [
    "./app/**/*.{ts,tsx}",
    "./components/**/*.{ts,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        ink: "#0B0D12",
        surface: "#151822",
        surface2: "#1D212C",
        gold: {
          DEFAULT: "#C6A15B",
          bright: "#E0BC7A",
          dim: "#8A703C",
        },
        mint: "#34D399",
        border: "#262B38",
        ivory: "#F2EFE9",
        muted: "#9AA1B2",
        // VORAX Neon Dark Theme — new design system tokens.
        // Kept separate from the tokens above (ink/gold/surface/etc.) so
        // existing pages keep working while pages are migrated in batches.
        neon: {
          bg: "#060914",
          card: "#0D1220",
          cardHover: "#141A2B",
          surface: "#090D18",
          purple: "#7C3AED",
          purpleBright: "#A855F7",
          blue: "#3B82F6",
          cyan: "#06B6D4",
          green: "#22C55E",
          text: "#FFFFFF",
          muted: "#94A3B8",
          danger: "#EF4444",
          warning: "#F59E0B",
          border: "#1E2740",
        },
      },
      fontFamily: {
        sans: ["var(--font-tajawal)", "sans-serif"],
      },
      backgroundImage: {
        "gold-fade": "linear-gradient(135deg, #C6A15B 0%, #8A703C 100%)",
      },
    },
  },
  plugins: [],
};

export default config;
