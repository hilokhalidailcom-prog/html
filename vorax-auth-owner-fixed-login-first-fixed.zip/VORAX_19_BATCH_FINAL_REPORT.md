# VORAX — 19-Batch Integrated Source Build

All 19 planned batches are now represented in the integrated source package, together with the requested merchant/customer chat and Telegram bridge.

## Batches
1. Core marketplace foundation
2. Authentication/RBAC and merchant foundation
3. Marketplace growth features
4. Commissions + withdrawals
5. Order + reservation engine
6. VORAX AI tool layer
7. AI shopping assistant
8. Telegram integration + merchant/customer chat bridge
9. Dynamic platform configuration
10. Unified notifications
11. Owner control center
12. Developer permissions
13. Security hardening
14. Platform analytics
15. Backup + recovery
16. Testing/CI
17. Performance/indexing/workers
18. Mobile-first surfaces
19. Modular architecture, final integration and audit

## Chat feature
- Customer web chat with merchants.
- Merchant web chat with customers.
- Optional order/phone-number context on a conversation.
- Server-side ownership checks.
- Read state and open/closed conversation state.
- Telegram delivery when the participant has a linked Telegram account.
- Telegram commands: `/start`, `/help`, `/chats`, `/chat ID`, `/close`.
- Normal Telegram messages are forwarded through the active conversation.

## Production status
The implementation is source-complete, but real production resources cannot be embedded in a ZIP. Production still requires real PostgreSQL, deployment, Telegram credentials, email credentials if enabled, external backup storage, and a real payout provider before automated real-money payouts.

Use `docs/PRODUCTION.md` and `scripts/production-setup.sh` for activation.
