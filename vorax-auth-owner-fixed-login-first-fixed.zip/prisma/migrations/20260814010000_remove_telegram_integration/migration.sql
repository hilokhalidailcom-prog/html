-- VORAX: Telegram is no longer part of the platform.
-- Chat and notifications are web-only (with optional email delivery).

ALTER TABLE IF EXISTS "MerchantChatMessage" DROP COLUMN IF EXISTS "telegramMessageId";

ALTER TABLE IF EXISTS "User" DROP COLUMN IF EXISTS "telegramAccountId";

DROP TABLE IF EXISTS "TelegramAccount";

UPDATE "NotificationDelivery" SET "status" = 'FAILED', "error" = 'Telegram delivery removed' WHERE "channel"::text = 'TELEGRAM';
UPDATE "Notification" SET "channel" = 'WEBSITE' WHERE "channel"::text = 'TELEGRAM';

DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM pg_type WHERE typname = 'NotificationChannel') THEN
    CREATE TYPE "NotificationChannel_new" AS ENUM ('WEBSITE', 'EMAIL');
    ALTER TABLE "NotificationDelivery" ALTER COLUMN "channel" TYPE "NotificationChannel_new" USING ("channel"::text::"NotificationChannel_new");
    ALTER TABLE "Notification" ALTER COLUMN "channel" TYPE "NotificationChannel_new" USING ("channel"::text::"NotificationChannel_new");
    DROP TYPE "NotificationChannel";
    ALTER TYPE "NotificationChannel_new" RENAME TO "NotificationChannel";
  END IF;
END $$;
