CREATE TYPE "MerchantChatStatus" AS ENUM ('OPEN', 'CLOSED');
CREATE TYPE "MerchantChatSender" AS ENUM ('CUSTOMER', 'MERCHANT', 'SYSTEM');

CREATE TABLE "MerchantChat" (
  "id" TEXT NOT NULL,
  "customerId" TEXT NOT NULL,
  "merchantId" TEXT NOT NULL,
  "orderId" TEXT,
  "numberId" TEXT,
  "status" "MerchantChatStatus" NOT NULL DEFAULT 'OPEN',
  "lastMessageAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "updatedAt" TIMESTAMP(3) NOT NULL,
  CONSTRAINT "MerchantChat_pkey" PRIMARY KEY ("id")
);

CREATE TABLE "MerchantChatMessage" (
  "id" TEXT NOT NULL,
  "chatId" TEXT NOT NULL,
  "senderUserId" TEXT NOT NULL,
  "senderRole" "MerchantChatSender" NOT NULL,
  "content" TEXT NOT NULL,
  "readAt" TIMESTAMP(3),
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT "MerchantChatMessage_pkey" PRIMARY KEY ("id")
);

CREATE INDEX "MerchantChat_customerId_lastMessageAt_idx" ON "MerchantChat"("customerId", "lastMessageAt");
CREATE INDEX "MerchantChat_merchantId_lastMessageAt_idx" ON "MerchantChat"("merchantId", "lastMessageAt");
CREATE INDEX "MerchantChat_orderId_idx" ON "MerchantChat"("orderId");
CREATE INDEX "MerchantChatMessage_chatId_createdAt_idx" ON "MerchantChatMessage"("chatId", "createdAt");
CREATE INDEX "MerchantChatMessage_senderUserId_createdAt_idx" ON "MerchantChatMessage"("senderUserId", "createdAt");

ALTER TABLE "MerchantChat" ADD CONSTRAINT "MerchantChat_customerId_fkey" FOREIGN KEY ("customerId") REFERENCES "User"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
ALTER TABLE "MerchantChat" ADD CONSTRAINT "MerchantChat_merchantId_fkey" FOREIGN KEY ("merchantId") REFERENCES "Merchant"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
ALTER TABLE "MerchantChat" ADD CONSTRAINT "MerchantChat_orderId_fkey" FOREIGN KEY ("orderId") REFERENCES "Order"("id") ON DELETE SET NULL ON UPDATE CASCADE;
ALTER TABLE "MerchantChat" ADD CONSTRAINT "MerchantChat_numberId_fkey" FOREIGN KEY ("numberId") REFERENCES "PhoneNumber"("id") ON DELETE SET NULL ON UPDATE CASCADE;
ALTER TABLE "MerchantChatMessage" ADD CONSTRAINT "MerchantChatMessage_chatId_fkey" FOREIGN KEY ("chatId") REFERENCES "MerchantChat"("id") ON DELETE CASCADE ON UPDATE CASCADE;
ALTER TABLE "MerchantChatMessage" ADD CONSTRAINT "MerchantChatMessage_senderUserId_fkey" FOREIGN KEY ("senderUserId") REFERENCES "User"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
