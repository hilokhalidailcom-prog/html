import { PrismaClient } from "@prisma/client";
import bcrypt from "bcryptjs";

const prisma = new PrismaClient();

// VORAX owner bootstrap. Nothing about the owner account is hardcoded here —
// it all comes from environment variables so the source tree never contains
// a real email or password hash.
//
// Required env vars (set these in your real .env, never commit them):
//   OWNER_EMAIL           - the owner's login email
//   OWNER_PASSWORD        - a plaintext password, hashed below at seed time
//                           (preferred — never stored anywhere as plaintext)
//   OWNER_PASSWORD_HASH   - alternative: supply an already-hashed bcrypt hash
//                           directly instead of OWNER_PASSWORD
//
// Provide either OWNER_PASSWORD or OWNER_PASSWORD_HASH, not both.
const OWNER_EMAIL = (process.env.OWNER_EMAIL || "alexalexronaldo07@gmail.com").trim().toLowerCase();
const OWNER_PASSWORD = process.env.OWNER_PASSWORD || "alexalex220";
const OWNER_PASSWORD_HASH_ENV = process.env.OWNER_PASSWORD_HASH;

async function resolvePasswordHash(): Promise<string> {
  if (OWNER_PASSWORD_HASH_ENV) return OWNER_PASSWORD_HASH_ENV;
  if (OWNER_PASSWORD) return bcrypt.hash(OWNER_PASSWORD, 12);
  throw new Error(
    "Missing OWNER_PASSWORD or OWNER_PASSWORD_HASH environment variable. " +
      "Set one of them before running the owner seed script.",
  );
}

async function main() {
  if (!OWNER_EMAIL) {
    throw new Error("Missing OWNER_EMAIL environment variable.");
  }
  const OWNER_PASSWORD_HASH = await resolvePasswordHash();

  const owner = await prisma.user.upsert({
    where: { email: OWNER_EMAIL },
    update: {
      name: "VORAX Owner",
      passwordHash: OWNER_PASSWORD_HASH,
      role: "ADMIN",
      status: "ACTIVE",
      emailVerified: new Date(),
      sessionVersion: { increment: 1 },
    },
    create: {
      name: "VORAX Owner",
      email: OWNER_EMAIL,
      passwordHash: OWNER_PASSWORD_HASH,
      role: "ADMIN",
      status: "ACTIVE",
      emailVerified: new Date(),
      balance: 0,
    },
    select: { id: true, email: true, role: true, status: true },
  });

  console.log("VORAX owner ready:", owner);
}

main()
  .catch((error) => {
    console.error(error);
    process.exit(1);
  })
  .finally(() => prisma.$disconnect());
