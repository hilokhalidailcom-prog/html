# VORAX — "صلح الكل" — نتيجة الفحص والإصلاح

## اللي اتصلح فعليًا (كود، جاهز للدمج)

```
app/api/admin/withdrawals/route.ts     → ملف جديد (كان الثغرة الحقيقية: GET list ناقص تمامًا)
app/admin/dashboard/page.tsx           → استبدال (بيلينك دلوقتي لكل صفحات الأدمن)
app/admin/developers/page.tsx          → ملف جديد
app/admin/users/page.tsx               → ملف جديد (read-only، لأن الـ API نفسه read-only)
app/admin/orders/page.tsx              → ملف جديد
app/admin/reports/page.tsx             → ملف جديد
app/admin/dynamic/page.tsx             → ملف جديد (تبويبات للـ 6 موارد)
app/admin/security/page.tsx            → ملف جديد (2FA setup + إبطال جلسات)
app/admin/analytics/page.tsx           → ملف جديد
app/admin/withdrawals/page.tsx         → ملف جديد
app/admin/commissions/page.tsx         → ملف جديد
app/admin/backups/page.tsx             → ملف جديد
tests/mocks/prisma.ts                  → استبدال (أضفت merchant/withdrawalRequest/ledgerEntry/activityLog)
tests/adversarial-admin.test.ts        → ملف جديد (5 اختبارات: Customer→Admin API، Developer بدون صلاحية×2، نجاح مع الصلاحية الصح)
```

انسخ كل ملف لنفس المسار في مشروعك، وشغّل `npx vitest run`.

## غلطة صغيرة عملتها وصلحتها أثناء الشغل
حاولت أستورد `MERCHANT_PERMISSIONS` من `lib/permissions.ts` مباشرة في صفحة `"use client"` (developers page) — ده كان هيكسر الـ build لأن `lib/permissions.ts` بيستورد `lib/prisma` في الأعلى، ومينفعش الـ Prisma client يترامى للـ browser bundle. صلحتها بتكرار القائمة محليًا في الصفحة نفسها (مع تعليق يوضح ليه، وتنويه إنها لازم تتزامن يدويًا مع `lib/permissions.ts` لحد ما نعمل endpoint بسيط يرجّعها من السيرفر).

## اللي **مش قادر أصلحه فعليًا** — وليه
كل واحدة من دي محتاجة إما بيئة تشغيل حقيقية (DB + شبكة) مش متاحة عندي هنا، أو أسرار/بنية تحتية حقيقية مفيش كود يقدر يخترعها:

1. **Migrations الناقصة (~43 موديل بدون migration حقيقي):** حاولت أشغّل `prisma migrate diff` عشان أولّد SQL صح تلقائيًا، لكن مفيش اتصال إنترنت هنا لتثبيت Prisma CLI. **رفضت أكتب SQL يدويًا** لـ 43 جدول مترابط بإيدي — احتمال غلطة في نوع عمود أو foreign key أو enum casing عالي جدًا، وده أخطر من عدم عمل حاجة خالص (ممكن يكسر بيانات حقيقية). الحل الصح: شغّل إنت بنفسك على بيئة فيها الـ DB:
   ```bash
   npx prisma migrate dev --name baseline_full_schema
   ```
   ده هيولّد ملف migration واحد صحيح 100% لأنه معتمد على الأداة نفسها مش على تخميني.

2. **Telegram:** مش "ناقص" — اتشال بقرار موثّق (`VORAX_TELEGRAM_REMOVED.md`). لو عايزه يرجع، ده قرار منتج مش إصلاح باگ — قولّي صراحة لو عايز أرجّعه.

3. **Email (Resend):** الكود جاهز 100%، بس مش هيشتغل من غير `RESEND_API_KEY` حقيقي في الـ environment variables — مفيش كود يحل المشكلة دي.

4. **AI (`services/gemini-proxy`):** خدمة منفصلة بـ Bun، محتاجة تتنشر لوحدها + مفتاح Gemini API حقيقي.

5. **Backup الخارجي:** الـ script والـ endpoint جاهزين، لكن `BACKUP_STORAGE_URL` لازم يتحط وقت الـ deploy.

هذول الخمسة كلهم موثقين أصلًا في `VORAX_PRODUCTION_GAPS_FIXED.md` بتاعك — أنا مش بكتشف حاجة جديدة، بس بأكدها.

## نقطة كشفتها أثناء بناء صفحة العمولات (Commissions)
جدول `CommissionRule` (Global/Category/Merchant scope) **موجود بس مش متصل فعليًا بمنطق الـ checkout** — التاجر لسه بياخد عمولته من `Merchant.commissionPercent` الفردي بس، مش من أي قاعدة عامة تحطها هنا. لو عايز الـ scope rules تتفعّل فعليًا، ده يحتاج تعديل في `checkout/route.ts` يقرأ من `CommissionRule` قبل ما يرجع لـ `Merchant.commissionPercent` كـ fallback — نقطة قرار تستاهل توضيحك.

## الاختبارات الجديدة (5) بتغطي بالظبط الحالات اللي مواصفتك سمّتها صراحة
- Customer → Admin API (403، مش تسريب بيانات)
- غير مسجل دخول (401، مش 403 — فرق مهم أمنيًا)
- Developer → Permission غير ممنوحة (مرتين: على withdrawals وعلى developers نفسها)
- تأكيد إن الصلاحية الصحيحة فعلاً بتشتغل (مش بس نختبر الرفض)
