# VORAX — Full 19-Batch Implementation

This build extends the existing VORAX project instead of rebuilding it.

## Architectural invariants
- `PhoneNumber` is the sellable unit.
- `User.balance` is the Tikoun (£) source of truth.
- Merchant ledger is accounting only; it is not a wallet.
- Existing Orders/OrderItems/Reviews/RBAC are reused.
- Ownership is enforced server-side.
- Sensitive actions are logged.
- AI uses constrained backend tools and real data only.
- Withdrawals are manual after approval.

## Implemented platform areas in this source build
- Merchant marketplace approval, ledger, analytics, notifications, reports and public stores.
- Search/discovery with filters and cursor pagination.
- Customer marketplace primitives: wishlist, alerts, recently viewed, reviews, featured, related and recommendations.
- Commission rules and merchant withdrawals.
- Reservation engine with expiry worker and serializable checkout/idempotency hardening.
- AI tool layer and marketplace assistant.
- Telegram linking/webhook primitives.
- Dynamic categories, homepage sections, offers.
- Unified notifications with delivery channels.
- Owner/developer control APIs and analytics.
- Session revocation, security events and Owner 2FA.
- Backup records plus `pg_dump` script.
- Testing/audit scripts and performance-oriented indexes.
- Mobile-first public AI/Owner/notifications screens.
- Modular `lib/*` services and route modules.

## Production activation
The source includes contracts and integrations, but production activation requires:
- a real PostgreSQL `DATABASE_URL`;
- Prisma migration + generated client;
- Telegram bot credentials;
- an email provider if email delivery is enabled;
- external backup storage;
- deployment cron/worker for reservation expiry;
- an actual payment provider if automated payouts are ever introduced.

Never commit those secrets.
