# VORAX + Gemini Proxy integration

VORAX AI is configured to use the bundled `services/gemini-proxy` through its OpenAI-compatible endpoint.

## Setup
1. Install Bun 1.1+ on the server.
2. Copy `.env.example` to `.env`.
3. Set the same random secret in both `VORAX_AI_API_KEY` and `services/gemini-proxy/.env` as `PROXY_API_KEY`.
4. Start the proxy: `npm run ai:proxy:install` then `npm run ai:proxy`.
5. Open `http://localhost:3000/auth/login` on the proxy host and complete Google OAuth.
6. Start VORAX.

VORAX sends `/v1/chat/completions` requests with the existing marketplace tools, so the model can call `searchProducts`, `getProduct`, `getCategories`, `getInventory`, `getMerchant`, `getStoreInfo`, and `getUserOrders`.

## Important
The proxy README states that it uses internal Google endpoints and is intended for personal/internal development, not production. It may carry Google ToS/account risk and can break if internal APIs change. Do not expose the proxy publicly; keep it on the same private server/network as VORAX and protect `/v1/*` with a strong `PROXY_API_KEY`.
