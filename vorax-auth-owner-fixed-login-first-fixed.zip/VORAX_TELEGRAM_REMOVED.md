# VORAX — Telegram removed

Telegram integration has been completely removed from the platform.

- No Telegram bot/webhook.
- No Telegram account linking.
- No Telegram chat bridge.
- No Telegram chat notifications.
- Merchant/customer chat is web-only inside VORAX.
- Wallet top-up requests are handled from the VORAX platform and owner dashboard.
- Website notifications remain enabled; email is optional.
