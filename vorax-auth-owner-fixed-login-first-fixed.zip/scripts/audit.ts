import fs from "fs"; import path from "path";
const required=[
"schema.prisma","lib/permissions.ts","lib/finance.ts","lib/reservations.ts","lib/notifications.ts",
"lib/ai/tools.ts","app/api/orders/checkout/route.ts","app/api/reservations/route.ts",
"app/api/merchant/withdrawals/route.ts","app/api/admin/withdrawals/[id]/route.ts",
"app/api/ai/assistant/route.ts","app/api/notifications/route.ts",
"app/api/admin/analytics/route.ts","app/api/admin/security/2fa/route.ts","scripts/backup.sh"
];
const missing=required.filter(x=>!fs.existsSync(path.join(process.cwd(),x)));
if(missing.length){console.error("Missing:",missing);process.exit(1)}
console.log(`VORAX audit: ${required.length} core integration points present.`);
