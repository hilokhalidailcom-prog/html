#!/usr/bin/env bash
set -euo pipefail

if [[ "${RUN_PRODUCTION_SETUP:-1}" == "1" ]]; then
  npm run production:setup
fi
exec "$@"
