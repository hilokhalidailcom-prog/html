import { dispatchPendingNotifications } from "../lib/notification-delivery";
dispatchPendingNotifications().then(n=>console.log(`Delivered ${n} notifications`)).catch(e=>{console.error(e);process.exit(1)});
