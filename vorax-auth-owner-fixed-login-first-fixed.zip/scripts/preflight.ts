import { validateEnvironment } from '../lib/env';
import { prisma } from '../lib/prisma';

async function main() {
  validateEnvironment();
  await prisma.$queryRaw`SELECT 1`;
  console.log('VORAX preflight: OK');
}

main().catch((error) => {
  console.error('VORAX preflight: FAILED');
  console.error(error instanceof Error ? error.message : error);
  process.exit(1);
}).finally(async () => {
  await prisma.$disconnect();
});
