import { prisma } from "../lib/prisma";
import { createNotification } from "../lib/notifications";
async function main(){
  const alerts=await prisma.priceAlert.findMany({where:{active:true},include:{number:true}});
  for(const a of alerts) if(a.number.price<=a.targetPrice){
    await createNotification({userId:a.userId,title:"انخفض السعر",body:`سعر ${a.number.phone} أصبح ${a.number.price} Tikoun`,type:"PRICE_ALERT",channels:["WEBSITE","EMAIL"]});
    await prisma.priceAlert.update({where:{id:a.id},data:{active:false,triggeredAt:new Date()}});
  }
}
main().catch(e=>{console.error(e);process.exit(1)});
