import { releaseExpiredReservations } from "../lib/reservations";
async function main(){const count=await releaseExpiredReservations();console.log(`Released ${count} expired reservations`);}
main().catch(e=>{console.error(e);process.exit(1)});
