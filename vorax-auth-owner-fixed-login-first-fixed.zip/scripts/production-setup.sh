#!/usr/bin/env bash
set -euo pipefail

: "${DATABASE_URL:?DATABASE_URL is required}"
: "${AUTH_SECRET:?AUTH_SECRET is required}"
: "${NEXT_PUBLIC_APP_URL:?NEXT_PUBLIC_APP_URL is required}"

if [[ "${NODE_ENV:-production}" == "production" && "$NEXT_PUBLIC_APP_URL" != https://* ]]; then
  echo "NEXT_PUBLIC_APP_URL must use HTTPS in production" >&2
  exit 1
fi

echo "[1/5] Generating Prisma client"
npx prisma generate

echo "[2/5] Applying database migrations"
if compgen -G "prisma/migrations/*/migration.sql" >/dev/null; then
  npx prisma migrate deploy
else
  echo "No Prisma migrations are committed. Bootstrapping schema with prisma db push."
  echo "For long-lived production environments, generate and commit an initial migration before the next release."
  npx prisma db push
fi

echo "[3/5] Environment + database preflight"
npm run preflight

echo "[4/5] Static audit"
npm run audit

echo "[5/5] Production setup complete"
echo "Health endpoint: ${NEXT_PUBLIC_APP_URL%/}/api/health"
