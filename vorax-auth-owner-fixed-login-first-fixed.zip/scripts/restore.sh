#!/usr/bin/env bash
set -euo pipefail
: "${DATABASE_URL:?DATABASE_URL is required}"
FILE="${1:?usage: restore.sh backup.dump}"
[ "${CONFIRM_RESTORE:-}" = "YES" ] || { echo "Set CONFIRM_RESTORE=YES to restore"; exit 2; }
pg_restore --clean --if-exists --dbname="$DATABASE_URL" "$FILE"
