#!/usr/bin/env bash
set -euo pipefail
: "${DATABASE_URL:?DATABASE_URL is required}"
OUT="${1:-./backups/vorax-$(date -u +%Y%m%dT%H%M%SZ).dump}"
mkdir -p "$(dirname "$OUT")"
pg_dump "$DATABASE_URL" --format=custom --file="$OUT"
echo "$OUT"

# If BACKUP_STORAGE_URL is a pre-signed/object PUT URL, upload the dump off-host.
# This keeps provider credentials out of the application container.
if [[ -n "${BACKUP_STORAGE_URL:-}" ]]; then
  curl --fail --silent --show-error --upload-file "$OUT" "$BACKUP_STORAGE_URL"
  echo "Off-site backup upload: OK"
fi
