"use client";
import { SessionProvider } from "next-auth/react";
import { CartProvider } from "@/lib/cart-context";
import SocialProofToast from "@/components/SocialProofToast";

export function SessionProviderWrapper({ children }: { children: React.ReactNode }) {
  return (
    <SessionProvider>
      <CartProvider>
        {children}
        <SocialProofToast />
      </CartProvider>
    </SessionProvider>
  );
}
