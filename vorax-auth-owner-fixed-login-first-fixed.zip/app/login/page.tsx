"use client";

import { Suspense, useState } from "react";
import { signIn } from "next-auth/react";
import { useRouter, useSearchParams } from "next/navigation";
import Link from "next/link";
import Logo from "@/components/Logo";

const ERROR_MESSAGES: Record<string, string> = {
  CredentialsSignin: "البريد الإلكتروني أو كلمة المرور غير صحيحة",
  ACCOUNT_DISABLED: "هذا الحساب معطّل، تواصل مع الدعم",
  EMAIL_NOT_VERIFIED: "يجب تفعيل بريدك الإلكتروني أولاً، تحقق من صندوق الوارد",
  TOO_MANY_ATTEMPTS: "محاولات كثيرة جدًا، حاول مرة أخرى بعد قليل",
  INVALID_2FA: "رمز التحقق غير صحيح",
};

export default function LoginPage() {
  return (
    <Suspense fallback={null}>
      <LoginForm />
    </Suspense>
  );
}

function LoginForm() {
  const router = useRouter();
  const params = useSearchParams();
  const verify = params.get("verify");

  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [otp, setOtp] = useState("");
  const [needsOtp, setNeedsOtp] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(verify === "success" ? "تم تفعيل البريد الإلكتروني. يمكنك تسجيل الدخول الآن." : verify === "invalid" ? "رابط تفعيل البريد غير صالح أو منتهي الصلاحية." : verify === "missing" ? "رابط تفعيل البريد غير مكتمل." : "");

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (loading) return;

    setLoading(true);
    setError("");

    try {
      const res = await signIn("credentials", {
        email: email.trim().toLowerCase(),
        password,
        ...(otp ? { otp: otp.trim() } : {}),
        redirect: false,
        callbackUrl: "/dashboard",
      });

      if (res?.error) {
        const rawError = String(res.error);
        // Auth.js v5 may wrap authorize() errors as CallbackRouteError.
        // Keep the UI useful instead of showing a generic server error.
        if (rawError.includes("TWO_FACTOR_REQUIRED")) {
          setNeedsOtp(true);
          setError("أدخل رمز التحقق من تطبيق المصادقة");
          return;
        }
        if (rawError.includes("ACCOUNT_DISABLED")) {
          setError(ERROR_MESSAGES.ACCOUNT_DISABLED);
          return;
        }
        if (rawError.includes("EMAIL_NOT_VERIFIED")) {
          setError(ERROR_MESSAGES.EMAIL_NOT_VERIFIED);
          return;
        }
        if (rawError.includes("TOO_MANY_ATTEMPTS")) {
          setError(ERROR_MESSAGES.TOO_MANY_ATTEMPTS);
          return;
        }
        if (rawError.includes("INVALID_2FA")) {
          setNeedsOtp(true);
          setError(ERROR_MESSAGES.INVALID_2FA);
          return;
        }
        setError(ERROR_MESSAGES[rawError] ?? "البريد الإلكتروني أو كلمة المرور غير صحيحة");
        return;
      }

      router.replace(res?.url || "/dashboard");
      router.refresh();
    } catch {
      setError("تعذر تسجيل الدخول حاليًا. تأكد من إعدادات الخادم وحاول مرة أخرى.");
    } finally {
      setLoading(false);
    }
  }

  return (
    <div dir="rtl" className="flex min-h-screen items-center justify-center bg-neon-bg px-4">
      <div className="w-full max-w-sm rounded-2xl border border-neon-purple/20 bg-neon-card p-8 shadow-[0_0_60px_rgba(14,165,233,0.12)]">
        <div className="mb-4 flex justify-center">
          <Logo size="header" priority />
        </div>
        <p className="mb-6 text-center text-sm text-neon-muted">تسجيل الدخول لحسابك</p>

        {verify === "success" && (
          <p className="mb-4 rounded-lg bg-green-500/10 px-3 py-2 text-sm text-green-400">
            تم تفعيل بريدك الإلكتروني بنجاح، يمكنك الآن تسجيل الدخول
          </p>
        )}
        {verify === "invalid" && (
          <p className="mb-4 rounded-lg bg-red-500/10 px-3 py-2 text-sm text-red-400">
            رابط التفعيل غير صالح أو منتهي الصلاحية
          </p>
        )}

        {process.env.NEXT_PUBLIC_GOOGLE_LOGIN_ENABLED === "true" && (
        <button
          type="button"
          onClick={() => signIn("google", { callbackUrl: "/dashboard" })}
          className="mb-4 flex w-full items-center justify-center gap-2 rounded-lg border border-neon-border bg-white px-4 py-2 font-semibold text-neon-bg transition hover:bg-neon-cardHover"
        >
          <svg width="18" height="18" viewBox="0 0 18 18" aria-hidden="true">
            <path fill="#4285F4" d="M17.64 9.2c0-.64-.06-1.25-.16-1.84H9v3.48h4.84a4.14 4.14 0 0 1-1.8 2.72v2.26h2.91c1.7-1.57 2.69-3.88 2.69-6.62z" />
            <path fill="#34A853" d="M9 18c2.43 0 4.47-.8 5.96-2.18l-2.91-2.26c-.81.54-1.84.86-3.05.86-2.34 0-4.33-1.58-5.04-3.71H.96v2.33A9 9 0 0 0 9 18z" />
            <path fill="#FBBC05" d="M3.96 10.71A5.4 5.4 0 0 1 3.68 9c0-.59.1-1.17.28-1.71V4.96H.96A9 9 0 0 0 0 9c0 1.45.35 2.83.96 4.04l3-2.33z" />
            <path fill="#EA4335" d="M9 3.58c1.32 0 2.51.45 3.44 1.35l2.58-2.58C13.46.89 11.43 0 9 0A9 9 0 0 0 .96 4.96l3 2.33C4.67 5.16 6.66 3.58 9 3.58z" />
          </svg>
          الدخول عبر Google
        </button>
        )}

        <div className="mb-4 flex items-center gap-3">
          <div className="h-px flex-1 bg-neon-cardHover" />
          <span className="text-xs text-neon-muted">أو</span>
          <div className="h-px flex-1 bg-neon-cardHover" />
        </div>

        <form onSubmit={handleSubmit} className="flex flex-col gap-3">
          <input
            type="email"
            required
            placeholder="البريد الإلكتروني"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            className="rounded-lg border border-neon-border bg-neon-cardHover px-4 py-2 text-white outline-none focus:border-neon-purple"
          />
          <input
            type="password"
            required
            placeholder="كلمة المرور"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            className="rounded-lg border border-neon-border bg-neon-cardHover px-4 py-2 text-white outline-none focus:border-neon-purple"
          />
          {needsOtp && (
            <input
              type="text"
              inputMode="numeric"
              required
              autoFocus
              placeholder="رمز التحقق (6 أرقام)"
              value={otp}
              onChange={(e) => setOtp(e.target.value)}
              className="rounded-lg border border-neon-border bg-neon-cardHover px-4 py-2 text-white outline-none focus:border-neon-purple"
            />
          )}
          {error && <p className="text-sm text-red-400">{error}</p>}
          <button
            type="submit"
            disabled={loading}
            className="mt-1 rounded-lg bg-gradient-to-r from-blue-600 to-neon-purpleBright px-4 py-2 font-bold text-white transition hover:brightness-110 disabled:opacity-50"
          >
            {loading ? "..." : "دخول"}
          </button>
        </form>

        <div className="mt-4 flex justify-between text-sm">
          <Link href="/forgot-password" className="text-neon-muted hover:text-neon-purpleBright">
            نسيت كلمة المرور؟
          </Link>
          <Link href="/register" className="text-neon-muted hover:text-neon-purpleBright">
            حساب جديد
          </Link>
        </div>
      </div>
    </div>
  );
}
