"use client";

import { useState } from "react";

export default function ForgotPasswordPage() {
  const [email, setEmail] = useState("");
  const [sent, setSent] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    setError("");
    try {
      const res = await fetch("/api/auth/forgot-password", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email }),
      });
      if (!res.ok) {
        const data = await res.json().catch(() => ({}));
        setError(data.error ?? "حدث خطأ");
        return;
      }
      setSent(true);
    } finally {
      setLoading(false);
    }
  }

  return (
    <div dir="rtl" className="mx-auto mt-20 max-w-sm rounded-2xl border border-neon-purple/20 bg-neon-card p-8">
      <h1 className="mb-2 text-xl font-bold text-neon-purpleBright">نسيت كلمة المرور؟</h1>
      {sent ? (
        <p className="text-sm text-neon-muted">
          إذا كان بريدك مسجلاً، ستصلك رسالة تحتوي على رابط لإعادة تعيين كلمة المرور.
        </p>
      ) : (
        <form onSubmit={handleSubmit} className="mt-4 flex flex-col gap-3">
          <input
            type="email"
            required
            placeholder="بريدك الإلكتروني"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            className="rounded-lg border border-neon-border bg-neon-cardHover px-4 py-2 text-white outline-none focus:border-neon-purple"
          />
          {error && <p className="text-sm text-red-400">{error}</p>}
          <button
            type="submit"
            disabled={loading}
            className="rounded-lg bg-neon-purple px-4 py-2 font-bold text-white disabled:opacity-50"
          >
            {loading ? "..." : "إرسال رابط إعادة التعيين"}
          </button>
        </form>
      )}
    </div>
  );
}
