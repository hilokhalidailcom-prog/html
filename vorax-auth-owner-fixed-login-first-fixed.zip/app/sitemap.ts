import type { MetadataRoute } from "next";
import { prisma } from "@/lib/prisma";
import { SITE_URL } from "@/lib/seo";

// Next.js serves this automatically at /sitemap.xml.
// Revalidates every hour so newly added numbers get indexed without a
// full redeploy.
export const dynamic = "force-dynamic";
export const revalidate = 3600;

export default async function sitemap(): Promise<MetadataRoute.Sitemap> {
  const staticRoutes: MetadataRoute.Sitemap = [
    { url: `${SITE_URL}/`, changeFrequency: "daily", priority: 1 },
    { url: `${SITE_URL}/numbers`, changeFrequency: "hourly", priority: 0.9 },
    { url: `${SITE_URL}/terms`, changeFrequency: "yearly", priority: 0.3 },
    { url: `${SITE_URL}/privacy`, changeFrequency: "yearly", priority: 0.3 },
  ];

  const [countries, numbers] = await Promise.all([
    prisma.country.findMany({ where: { active: true }, select: { code: true } }),
    // Cap at 5000: Google's per-sitemap limit is 50k URLs, but a single
    // flat file this big is worth splitting into a sitemap index later.
    prisma.phoneNumber.findMany({
      where: { status: "AVAILABLE" },
      select: { id: true, createdAt: true },
      orderBy: { createdAt: "desc" },
      take: 5000,
    }),
  ]);

  const countryRoutes: MetadataRoute.Sitemap = countries.map((c) => ({
    url: `${SITE_URL}/country/${c.code}`,
    changeFrequency: "daily",
    priority: 0.7,
  }));

  const numberRoutes: MetadataRoute.Sitemap = numbers.map((n) => ({
    url: `${SITE_URL}/numbers/${n.id}`,
    lastModified: n.createdAt,
    changeFrequency: "daily",
    priority: 0.6,
  }));

  return [...staticRoutes, ...countryRoutes, ...numberRoutes];
}
