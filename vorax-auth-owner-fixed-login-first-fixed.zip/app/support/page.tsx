"use client";

import { FormEvent, useEffect, useState } from "react";
import AppShell from "@/components/AppShell";

type TicketMessage = { id: string; from: string; text: string; at: string };
type Ticket = {
  id: string;
  subject: string;
  status: "OPEN" | "IN_PROGRESS" | "CLOSED";
  createdAt: string;
  messages: TicketMessage[];
};

const STATUS_LABEL: Record<Ticket["status"], string> = {
  OPEN: "مفتوحة",
  IN_PROGRESS: "قيد المعالجة",
  CLOSED: "مغلقة",
};

export default function SupportPage() {
  const [tickets, setTickets] = useState<Ticket[]>([]);
  const [active, setActive] = useState<Ticket | null>(null);
  const [loading, setLoading] = useState(true);
  const [reply, setReply] = useState("");

  const [showNew, setShowNew] = useState(false);
  const [subject, setSubject] = useState("");
  const [message, setMessage] = useState("");
  const [creating, setCreating] = useState(false);

  async function load() {
    setLoading(true);
    const r = await fetch("/api/tickets", { cache: "no-store" });
    if (r.ok) {
      const d = await r.json();
      setTickets(d.tickets ?? []);
      if (active) {
        const refreshed = d.tickets.find((t: Ticket) => t.id === active.id);
        if (refreshed) setActive(refreshed);
      }
    }
    setLoading(false);
  }

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  async function createTicket(e: FormEvent) {
    e.preventDefault();
    if (!subject.trim() || !message.trim()) return;
    setCreating(true);
    try {
      const r = await fetch("/api/tickets", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ subject, message }),
      });
      const d = await r.json();
      if (r.ok) {
        setSubject("");
        setMessage("");
        setShowNew(false);
        await load();
        setActive(d.ticket);
      }
    } finally {
      setCreating(false);
    }
  }

  async function sendReply() {
    if (!active || !reply.trim()) return;
    const text = reply.trim();
    setReply("");
    const r = await fetch(`/api/tickets/${active.id}/messages`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ text }),
    });
    if (r.ok) await load();
  }

  return (
    <AppShell>
      <div className="mb-4 flex items-center justify-between">
        <h1 className="text-xl font-bold text-neon-text">💬 الدعم والمحادثات</h1>
        <button
          onClick={() => setShowNew((s) => !s)}
          className="rounded-xl bg-gradient-to-l from-neon-purple to-neon-purpleBright px-4 py-2 text-sm font-semibold text-white"
        >
          {showNew ? "إغلاق" : "+ محادثة جديدة"}
        </button>
      </div>

      {showNew && (
        <form
          onSubmit={createTicket}
          className="mb-4 space-y-3 rounded-2xl border border-neon-border bg-neon-card p-4"
        >
          <input
            value={subject}
            onChange={(e) => setSubject(e.target.value)}
            placeholder="موضوع المشكلة"
            className="w-full rounded-xl border border-neon-border bg-neon-bg px-4 py-2.5 text-neon-text outline-none focus:border-neon-purple"
          />
          <textarea
            value={message}
            onChange={(e) => setMessage(e.target.value)}
            placeholder="اشرح مشكلتك بالتفصيل..."
            rows={3}
            className="w-full rounded-xl border border-neon-border bg-neon-bg px-4 py-2.5 text-neon-text outline-none focus:border-neon-purple"
          />
          <button
            disabled={creating}
            className="rounded-xl bg-neon-purple px-5 py-2.5 text-sm font-semibold text-white disabled:opacity-50"
          >
            {creating ? "جارِ الإرسال..." : "إرسال"}
          </button>
        </form>
      )}

      <div className="grid gap-4 md:grid-cols-[280px_1fr]">
        <aside className="rounded-2xl border border-neon-border bg-neon-card p-3">
          {loading ? (
            <p className="p-3 text-sm text-neon-muted">جارِ التحميل...</p>
          ) : tickets.length === 0 ? (
            <p className="p-3 text-sm text-neon-muted">لا توجد محادثات دعم بعد.</p>
          ) : (
            tickets.map((t) => (
              <button
                key={t.id}
                onClick={() => setActive(t)}
                className={`mb-2 w-full rounded-xl border p-3 text-right text-sm transition-colors ${
                  active?.id === t.id
                    ? "border-neon-purple bg-neon-purple/10 text-neon-text"
                    : "border-neon-border text-neon-text hover:bg-neon-cardHover"
                }`}
              >
                {t.subject}
                <div className="text-xs text-neon-muted">{STATUS_LABEL[t.status]}</div>
              </button>
            ))
          )}
        </aside>

        <section className="flex min-h-[60vh] flex-col rounded-2xl border border-neon-border bg-neon-card p-4">
          {!active ? (
            <div className="m-auto text-sm text-neon-muted">اختر محادثة أو ابدأ محادثة جديدة</div>
          ) : (
            <>
              <h2 className="border-b border-neon-border pb-3 font-bold text-neon-text">
                {active.subject}
              </h2>
              <div className="flex-1 space-y-2 overflow-auto py-4">
                {active.messages.map((m) => (
                  <div
                    key={m.id}
                    className={`max-w-[80%] rounded-2xl p-3 text-sm ${
                      m.from === "user"
                        ? "mr-auto bg-neon-purple text-white"
                        : "ml-auto bg-neon-cardHover text-neon-text"
                    }`}
                  >
                    {m.text}
                    <div className="mt-1 text-[10px] opacity-60">
                      {new Date(m.at).toLocaleString("ar-EG")}
                    </div>
                  </div>
                ))}
              </div>
              {active.status !== "CLOSED" && (
                <div className="flex gap-2">
                  <input
                    value={reply}
                    onChange={(e) => setReply(e.target.value)}
                    onKeyDown={(e) => {
                      if (e.key === "Enter") sendReply();
                    }}
                    placeholder="اكتب رسالتك..."
                    className="flex-1 rounded-xl border border-neon-border bg-neon-bg px-4 py-2 text-neon-text outline-none focus:border-neon-purple"
                  />
                  <button
                    onClick={sendReply}
                    className="rounded-xl bg-gradient-to-l from-neon-purple to-neon-purpleBright px-5 font-semibold text-white"
                  >
                    إرسال
                  </button>
                </div>
              )}
            </>
          )}
        </section>
      </div>
    </AppShell>
  );
}
