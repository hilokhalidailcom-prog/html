"use client";

import { useEffect, useState } from "react";
import AppShell from "@/components/AppShell";

type Notification = {
  id: string;
  title: string;
  body: string;
  createdAt: string;
  readAt: string | null;
};

export default function NotificationsPage() {
  const [items, setItems] = useState<Notification[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch("/api/notifications")
      .then((r) => r.json())
      .then(setItems)
      .finally(() => setLoading(false));
  }, []);

  async function read(id: string) {
    await fetch(`/api/notifications/${id}/read`, { method: "PATCH" });
    setItems((x) => x.map((n) => (n.id === id ? { ...n, readAt: new Date().toISOString() } : n)));
  }

  return (
    <AppShell>
      <h1 className="mb-6 text-xl font-bold text-neon-text">🔔 الإشعارات</h1>
      {loading ? (
        <p className="text-neon-muted">جارِ التحميل...</p>
      ) : items.length === 0 ? (
        <div className="rounded-2xl border border-neon-border bg-neon-card p-10 text-center text-neon-muted">
          لا توجد إشعارات بعد
        </div>
      ) : (
        <div className="space-y-3">
          {items.map((n) => (
            <button
              onClick={() => read(n.id)}
              key={n.id}
              className={`block w-full rounded-2xl border p-4 text-right transition-colors ${
                n.readAt
                  ? "border-neon-border bg-neon-card/60 opacity-60"
                  : "border-neon-purple/40 bg-neon-purple/10"
              }`}
            >
              <b className="text-neon-text">{n.title}</b>
              <p className="mt-1 text-sm text-neon-muted">{n.body}</p>
              <small className="mt-2 block text-xs text-neon-muted">
                {new Date(n.createdAt).toLocaleString("ar-EG")}
              </small>
            </button>
          ))}
        </div>
      )}
    </AppShell>
  );
}
