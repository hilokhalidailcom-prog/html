"use client";

import { Suspense, useState } from "react";
import { useSearchParams, useRouter } from "next/navigation";

export default function ResetPasswordPage() {
  return (
    <Suspense fallback={null}>
      <ResetPasswordForm />
    </Suspense>
  );
}

function ResetPasswordForm() {
  const params = useSearchParams();
  const router = useRouter();
  const token = params.get("token") ?? "";

  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [done, setDone] = useState(false);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    setError("");
    try {
      const res = await fetch("/api/auth/reset-password", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ token, password }),
      });
      const data = await res.json();
      if (!res.ok) {
        setError(data.error ?? "حدث خطأ");
        return;
      }
      setDone(true);
      setTimeout(() => router.push("/login"), 1500);
    } finally {
      setLoading(false);
    }
  }

  if (!token) {
    return <p dir="rtl" className="mt-20 text-center text-red-400">رابط غير صالح</p>;
  }

  return (
    <div dir="rtl" className="mx-auto mt-20 max-w-sm rounded-2xl border border-neon-purple/20 bg-neon-card p-8">
      <h1 className="mb-2 text-xl font-bold text-neon-purpleBright">تعيين كلمة مرور جديدة</h1>
      {done ? (
        <p className="text-sm text-green-400">تم بنجاح، جاري تحويلك لتسجيل الدخول...</p>
      ) : (
        <form onSubmit={handleSubmit} className="mt-4 flex flex-col gap-3">
          <input
            type="password"
            required
            minLength={8}
            placeholder="كلمة المرور الجديدة"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            className="rounded-lg border border-neon-border bg-neon-cardHover px-4 py-2 text-white outline-none focus:border-neon-purple"
          />
          {error && <p className="text-sm text-red-400">{error}</p>}
          <button
            type="submit"
            disabled={loading}
            className="rounded-lg bg-neon-purple px-4 py-2 font-bold text-white disabled:opacity-50"
          >
            {loading ? "..." : "حفظ كلمة المرور"}
          </button>
        </form>
      )}
    </div>
  );
}
