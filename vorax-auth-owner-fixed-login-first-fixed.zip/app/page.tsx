"use client";
import { Suspense, useEffect, useState } from "react";
import { useSearchParams } from "next/navigation";
import Link from "next/link";
import Logo from "@/components/Logo";
import Icon from "@/components/Icon";
import { formatTikoun } from "@/lib/currency";

type NumberItem = {
  id: string;
  phone: string;
  price: number;
  type: string;
  country: { name: string; flag: string };
  merchant?: { storeName: string; slug: string; verified: boolean } | null;
  rating: number;
  featured: boolean;
};

type CountryStat = {
  id: string;
  code: string;
  name: string;
  flag: string;
  available: number;
  fromPrice: number | null;
};

export default function Home() {
  return (
    <Suspense fallback={null}>
      <HomeContent />
    </Suspense>
  );
}

function HomeContent() {
  const searchParams = useSearchParams();
  const category = searchParams.get("category"); // "whatsapp" | "telegram" | null
  const countryFilter = searchParams.get("country");
  const [q, setQ] = useState("");
  const [items, setItems] = useState<NumberItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [cursor, setCursor] = useState<string | null>(null);
  const [countries, setCountries] = useState<CountryStat[]>([]);

  const load = async (reset = false) => {
    setLoading(true);
    const p = new URLSearchParams();
    if (q) p.set("q", q);
    if (category) p.set("category", category);
    if (countryFilter) p.set("country", countryFilter);
    if (!reset && cursor) p.set("cursor", cursor);
    const r = await fetch(`/api/numbers?${p}`);
    const d = await r.json();
    setItems(reset || !cursor ? d.numbers : [...items, ...d.numbers]);
    setCursor(d.nextCursor);
    setLoading(false);
  };

  useEffect(() => {
    load(true);
    fetch("/api/countries")
      .then((r) => r.json())
      .then((d) => setCountries(d.countries ?? []))
      .catch(() => {});
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [category, countryFilter]);

  return (
    <main dir="rtl" className="min-h-screen bg-neon-bg text-neon-text">
      {/* Header */}
      <header className="sticky top-0 z-30 border-b border-neon-border/80 bg-neon-bg/85 backdrop-blur-xl">
        <div className="mx-auto flex max-w-7xl items-center gap-6 px-5 py-4 md:px-8">
          <Logo size="header" priority />
          <nav className="hidden flex-1 items-center justify-center gap-6 text-sm text-neon-muted lg:flex">
            <Link href="/" className="font-semibold text-white">الرئيسية</Link>
            <Link href="/store" className="hover:text-white">الخدمات</Link>
            <Link href="/store?service=whatsapp" className="hover:text-white">WhatsApp</Link>
            <Link href="/store?service=telegram" className="hover:text-white">Telegram</Link>
            <Link href="/support" className="hover:text-white">الدعم</Link>
          </nav>
          <div className="mr-auto flex items-center gap-2">
            <Link href="/store" aria-label="البحث" className="rounded-xl border border-neon-border bg-neon-surface p-2.5 text-neon-muted hover:text-white"><Icon name="search" size={18}/></Link>
            <Link href="/login" className="rounded-xl border border-neon-border px-4 py-2 text-sm font-bold text-white hover:border-neon-purple/60">تسجيل الدخول</Link>
            <Link href="/register" className="hidden rounded-xl bg-gradient-to-l from-neon-purple to-neon-purpleBright px-4 py-2 text-sm font-bold text-white shadow-[0_8px_30px_rgba(124,58,237,0.22)] sm:block">إنشاء حساب</Link>
          </div>
        </div>
      </header>

      {/* Hero */}
      <section className="relative mx-auto max-w-6xl overflow-hidden px-5 pb-10 pt-14 md:px-10">
        <div className="pointer-events-none absolute -left-24 top-0 h-96 w-96 rounded-full bg-neon-purple/20 blur-[100px]" />
        <div className="relative">
          <p className="mb-3 text-sm font-bold tracking-wide text-neon-purpleBright">
            منصتك المتكاملة للأرقام والخدمات الرقمية
          </p>
          <h2 className="max-w-3xl text-4xl font-black leading-tight text-neon-text md:text-6xl">
            كل خدماتك الرقمية في <span className="text-neon-purpleBright">VORAX</span>
          </h2>
          <p className="mt-4 max-w-xl text-lg text-neon-muted">
            منصة رقمية متكاملة لشراء وإدارة الخدمات والأرقام الرقمية بسهولة وأمان.
          </p>

          <form
            onSubmit={(e) => {
              e.preventDefault();
              setCursor(null);
              load(true);
            }}
            className="mt-8 flex max-w-xl gap-2"
          >
            <input
              value={q}
              onChange={(e) => setQ(e.target.value)}
              placeholder="ابحث برقم، دولة، أو خدمة..."
              className="flex-1 rounded-xl border border-neon-border bg-neon-card px-4 py-3.5 text-neon-text outline-none transition-colors placeholder:text-neon-muted focus:border-neon-purple"
            />
            <button className="rounded-xl bg-gradient-to-l from-neon-purple to-neon-purpleBright px-6 font-bold text-white transition-opacity hover:opacity-90">
              بحث
            </button>
          </form>
        </div>
      </section>

      {/* WhatsApp / Telegram services */}
      <section className="mx-auto max-w-6xl px-5 pb-14 md:px-10">
        <div className="grid gap-5 sm:grid-cols-2">
          <div className="rounded-2xl border border-neon-border bg-neon-card p-6">
            <div className="mb-4 flex items-center gap-3">
              <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-neon-green/15 text-neon-green"><Icon name="whatsapp" size={21}/></span>
              <div>
                <h3 className="font-bold text-neon-text">خدمات WhatsApp</h3>
                <p className="text-xs text-neon-muted">أرقام وخدمات تفعيل WhatsApp</p>
              </div>
            </div>
            <Link
              href="/store?service=whatsapp"
              className="block w-full rounded-xl bg-neon-green/15 py-2.5 text-center text-sm font-bold text-neon-green transition-colors hover:bg-neon-green/25"
            >
              عرض الأرقام ↗
            </Link>
          </div>
          <div className="rounded-2xl border border-neon-border bg-neon-card p-6">
            <div className="mb-4 flex items-center gap-3">
              <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-neon-blue/15 text-neon-blue"><Icon name="telegram" size={21}/></span>
              <div>
                <h3 className="font-bold text-neon-text">خدمات Telegram</h3>
                <p className="text-xs text-neon-muted">أرقام وخدمات تفعيل Telegram</p>
              </div>
            </div>
            <Link
              href="/store?service=telegram"
              className="block w-full rounded-xl bg-neon-blue/15 py-2.5 text-center text-sm font-bold text-neon-blue transition-colors hover:bg-neon-blue/25"
            >
              عرض الأرقام ↗
            </Link>
          </div>
        </div>
      </section>

      {/* Top countries */}
      {countries.length > 0 && (
        <section className="mx-auto max-w-6xl px-5 pb-14 md:px-10">
          <h3 className="mb-5 text-xl font-bold text-neon-text">الدول الأكثر طلبًا</h3>
          <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-6">
            {countries.map((c) => (
              <Link
                key={c.id}
                href={`/?country=${c.code}`}
                className="rounded-2xl border border-neon-border bg-neon-card p-4 text-center transition-colors hover:border-neon-purple/60 hover:bg-neon-cardHover"
              >
                <div className="mb-2 text-2xl">{c.flag}</div>
                <div className="text-sm font-bold text-neon-text">{c.name}</div>
                {c.fromPrice !== null && (
                  <div className="mt-1 text-xs text-neon-purpleBright">
                    من {formatTikoun(c.fromPrice)}
                  </div>
                )}
                <div className="mt-1 text-xs text-neon-muted">{c.available} متاح</div>
              </Link>
            ))}
          </div>
        </section>
      )}

      {/* Listings */}
      <section className="mx-auto max-w-6xl px-5 pb-20 md:px-10">
        <div className="mb-6 flex items-center justify-between">
          <h3 className="text-xl font-bold text-neon-text">أرقام متاحة الآن</h3>
          <span className="text-sm text-neon-muted">{items.length} نتيجة</span>
        </div>

        {loading && items.length === 0 ? (
          <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-3">
            {Array.from({ length: 6 }).map((_, i) => (
              <div key={i} className="h-48 animate-pulse rounded-2xl border border-neon-border bg-neon-card" />
            ))}
          </div>
        ) : items.length === 0 ? (
          <div className="rounded-2xl border border-dashed border-neon-border p-12 text-center">
            <p className="text-neon-muted">ما لقيناش أرقام تطابق البحث ديالك.</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-3">
            {items.map((n) => (
              <article
                key={n.id}
                className="overflow-hidden rounded-2xl border border-neon-border bg-neon-card transition-colors hover:border-neon-purple/60"
              >
                <div className="flex items-center justify-between px-5 pt-4">
                  <span className="flex items-center gap-1.5 text-sm text-neon-muted">
                    <span>{n.country.flag}</span>
                    <span>{n.country.name}</span>
                  </span>
                  {n.featured && (
                    <span className="rounded-full border border-neon-purple/40 px-2.5 py-0.5 text-xs font-bold text-neon-purpleBright">
                      مميز
                    </span>
                  )}
                </div>

                <div className="px-5 py-6 text-center">
                  <div className="text-2xl font-black tracking-wide text-neon-text" dir="ltr">
                    {n.phone}
                  </div>
                </div>

                <div className="h-px bg-neon-border" />

                <div className="flex items-center justify-between px-5 py-4">
                  <span className="text-sm text-neon-muted">{n.type}</span>
                  <strong className="text-lg text-neon-purpleBright">{formatTikoun(n.price)}</strong>
                </div>

                {n.merchant && (
                  <Link
                    className="block px-5 pb-3 text-sm text-neon-muted transition-colors hover:text-neon-purpleBright"
                    href={`/store/${n.merchant.slug}`}
                  >
                    {n.merchant.storeName}
                    {n.merchant.verified ? " ✓" : ""}
                  </Link>
                )}

                <div className="px-5 pb-4 text-sm text-neon-muted">⭐ {n.rating.toFixed(1)}</div>
              </article>
            ))}
          </div>
        )}

        {cursor && (
          <button
            disabled={loading}
            onClick={() => load(false)}
            className="mx-auto mt-10 block rounded-xl border border-neon-border px-6 py-3 font-bold text-neon-text transition-colors hover:border-neon-purple hover:text-neon-purpleBright disabled:opacity-50"
          >
            {loading ? "جارٍ التحميل…" : "تحميل المزيد"}
          </button>
        )}
      </section>
    </main>
  );
}
