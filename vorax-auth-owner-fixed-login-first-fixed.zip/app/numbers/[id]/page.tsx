import { notFound } from "next/navigation";
import Link from "next/link";
import AppShell from "@/components/AppShell";
import AddToCartButton from "@/components/AddToCartButton";
import { prisma } from "@/lib/prisma";
import { formatTikoun } from "@/lib/currency";
import { numberMetadata, numberProductJsonLd } from "@/lib/seo";

export async function generateMetadata({ params }: { params: { id: string } }) {
  const n = await prisma.phoneNumber.findUnique({ where: { id: params.id }, include: { country: true } });
  return n ? numberMetadata(n) : { title: "المنتج غير موجود | VORAX" };
}

export default async function NumberPage({ params }: { params: { id: string } }) {
  const n = await prisma.phoneNumber.findUnique({ where: { id: params.id }, include: { country: true, merchant: true, reviews: { select: { rating: true } } } });
  if (!n) notFound();
  const rating = n.reviews.length ? n.reviews.reduce((s,r)=>s+r.rating,0)/n.reviews.length : 0;
  const jsonLd = numberProductJsonLd(n);
  return <AppShell><div className="mx-auto max-w-6xl"><script type="application/ld+json" dangerouslySetInnerHTML={{__html:JSON.stringify(jsonLd)}} />
    <div className="mb-5 text-sm text-neon-muted"><Link href="/store" className="hover:text-white">المتجر</Link><span className="mx-2">/</span>تفاصيل المنتج</div>
    <div className="grid gap-5 lg:grid-cols-[1.3fr_.7fr]">
      <section className="glass-panel rounded-3xl p-6 md:p-10"><div className="flex items-center justify-between"><span className="rounded-full bg-neon-green/10 px-3 py-1 text-xs font-bold text-neon-green">{n.status === "AVAILABLE" ? "متاح الآن" : "غير متوفر"}</span><span className="text-sm text-neon-muted">{n.country.flag} {n.country.name}</span></div><div className="py-16 text-center"><div dir="ltr" className="text-4xl font-black tracking-wider md:text-6xl">{n.phone}</div><div className="mt-4 text-sm text-neon-muted">{n.type} · ⭐ {rating.toFixed(1)} ({n.reviews.length} تقييم)</div></div><div className="grid gap-3 sm:grid-cols-3"><div className="rounded-2xl bg-neon-bg p-4"><div className="text-xs text-neon-muted">الدولة</div><div className="mt-1 font-bold">{n.country.name}</div></div><div className="rounded-2xl bg-neon-bg p-4"><div className="text-xs text-neon-muted">النوع</div><div className="mt-1 font-bold">{n.type}</div></div><div className="rounded-2xl bg-neon-bg p-4"><div className="text-xs text-neon-muted">التقييم</div><div className="mt-1 font-bold">{rating.toFixed(1)} / 5</div></div></div>{n.description&&<div className="mt-6 rounded-2xl border p-5"><h2 className="font-bold">الوصف</h2><p className="mt-2 leading-7 text-neon-muted">{n.description}</p></div>}</section>
      <aside className="glass-panel h-fit rounded-3xl p-6"><div className="text-sm text-neon-muted">السعر</div><div className="mt-2 text-3xl font-black text-neon-purpleBright">{formatTikoun(n.price)}</div><div className="my-6 h-px bg-neon-border"/><div className="space-y-3 text-sm text-neon-muted"><div className="flex justify-between"><span>الحالة</span><span className="text-neon-green">{n.status === "AVAILABLE" ? "متاح" : "غير متوفر"}</span></div><div className="flex justify-between"><span>التاجر</span><span className="text-white">{n.merchant?.storeName ?? "VORAX"}</span></div></div><div className="mt-7 flex flex-col gap-3">{n.status === "AVAILABLE" ? <><Link href={`/cart?buy=${n.id}`} className="rounded-xl bg-gradient-to-l from-neon-purple to-neon-purpleBright py-3 text-center font-bold text-white">شراء الآن</Link><AddToCartButton numberId={n.id} phone={n.phone} price={n.price} countryFlag={n.country.flag}/></> : <div className="rounded-xl border border-neon-border py-3 text-center font-bold text-neon-muted">غير متوفر</div>}{n.merchant&&<Link href={`/store/${n.merchant.slug}`} className="rounded-xl border py-3 text-center text-sm font-bold hover:border-neon-purple/60">مراسلة التاجر / المتجر</Link>}</div></aside>
    </div>
  </div></AppShell>
}
