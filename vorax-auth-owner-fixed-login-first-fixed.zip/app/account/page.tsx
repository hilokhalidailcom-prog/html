"use client";

import { FormEvent, useEffect, useState } from "react";
import { signOut } from "next-auth/react";
import AppShell from "@/components/AppShell";
import { formatTikoun } from "@/lib/currency";

type Profile = {
  id: string;
  name: string;
  email: string;
  phone: string | null;
  balance: number;
  createdAt: string;
  _count: { orders: number };
};

export default function AccountPage() {
  const [profile, setProfile] = useState<Profile | null>(null);
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [savingProfile, setSavingProfile] = useState(false);
  const [profileMsg, setProfileMsg] = useState("");

  const [currentPassword, setCurrentPassword] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [savingPassword, setSavingPassword] = useState(false);
  const [passwordMsg, setPasswordMsg] = useState("");

  useEffect(() => {
    fetch("/api/account", { cache: "no-store" })
      .then((r) => r.json())
      .then((d) => {
        if (d.user) {
          setProfile(d.user);
          setName(d.user.name ?? "");
          setPhone(d.user.phone ?? "");
        }
      });
  }, []);

  async function saveProfile(e: FormEvent) {
    e.preventDefault();
    setSavingProfile(true);
    setProfileMsg("");
    try {
      const res = await fetch("/api/account", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name, phone: phone || undefined }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "تعذر الحفظ");
      setProfileMsg("✅ تم تحديث بياناتك");
    } catch (err) {
      setProfileMsg(err instanceof Error ? err.message : "حدث خطأ");
    } finally {
      setSavingProfile(false);
    }
  }

  async function savePassword(e: FormEvent) {
    e.preventDefault();
    setSavingPassword(true);
    setPasswordMsg("");
    try {
      const res = await fetch("/api/account/change-password", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ currentPassword, newPassword }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "تعذر تغيير كلمة المرور");
      setPasswordMsg("✅ تم تغيير كلمة المرور بنجاح");
      setCurrentPassword("");
      setNewPassword("");
    } catch (err) {
      setPasswordMsg(err instanceof Error ? err.message : "حدث خطأ");
    } finally {
      setSavingPassword(false);
    }
  }

  return (
    <AppShell>
      <h1 className="mb-6 text-xl font-bold text-neon-text">حسابي</h1>

      {profile && (
        <div className="mb-6 rounded-2xl border border-neon-border bg-neon-card p-5">
          <div className="flex flex-wrap items-center gap-4">
            <div className="flex h-14 w-14 items-center justify-center rounded-full bg-gradient-to-l from-neon-purple to-neon-purpleBright text-xl font-bold text-white">
              {profile.name?.charAt(0) ?? "?"}
            </div>
            <div>
              <p className="font-bold text-neon-text">{profile.name}</p>
              <p className="text-sm text-neon-muted" dir="ltr">
                {profile.email}
              </p>
            </div>
            <div className="mr-auto flex gap-6 text-center">
              <div>
                <p className="text-xs text-neon-muted">الرصيد</p>
                <p className="font-bold text-neon-purpleBright">{formatTikoun(profile.balance)}</p>
              </div>
              <div>
                <p className="text-xs text-neon-muted">الطلبات</p>
                <p className="font-bold text-neon-text">{profile._count.orders}</p>
              </div>
              <div>
                <p className="text-xs text-neon-muted">تاريخ التسجيل</p>
                <p className="font-bold text-neon-text">
                  {new Date(profile.createdAt).toLocaleDateString("ar-EG")}
                </p>
              </div>
            </div>
          </div>
        </div>
      )}

      <div className="grid gap-5 md:grid-cols-2">
        <form onSubmit={saveProfile} className="rounded-2xl border border-neon-border bg-neon-card p-5">
          <h2 className="mb-4 font-bold text-neon-text">تعديل الحساب</h2>
          <label className="mb-2 block text-sm text-neon-muted">الاسم</label>
          <input
            value={name}
            onChange={(e) => setName(e.target.value)}
            className="mb-4 w-full rounded-xl border border-neon-border bg-neon-bg p-3 text-neon-text outline-none focus:border-neon-purple"
          />
          <label className="mb-2 block text-sm text-neon-muted">رقم الهاتف</label>
          <input
            value={phone}
            onChange={(e) => setPhone(e.target.value)}
            dir="ltr"
            className="mb-4 w-full rounded-xl border border-neon-border bg-neon-bg p-3 text-neon-text outline-none focus:border-neon-purple"
          />
          {profileMsg && <p className="mb-4 text-sm text-neon-purpleBright">{profileMsg}</p>}
          <button
            disabled={savingProfile}
            className="w-full rounded-xl bg-gradient-to-l from-neon-purple to-neon-purpleBright py-3 font-bold text-white disabled:opacity-50"
          >
            {savingProfile ? "جارٍ الحفظ..." : "حفظ التعديلات"}
          </button>
        </form>

        <form onSubmit={savePassword} className="rounded-2xl border border-neon-border bg-neon-card p-5">
          <h2 className="mb-4 font-bold text-neon-text">تغيير كلمة المرور</h2>
          <label className="mb-2 block text-sm text-neon-muted">كلمة المرور الحالية</label>
          <input
            type="password"
            value={currentPassword}
            onChange={(e) => setCurrentPassword(e.target.value)}
            className="mb-4 w-full rounded-xl border border-neon-border bg-neon-bg p-3 text-neon-text outline-none focus:border-neon-purple"
          />
          <label className="mb-2 block text-sm text-neon-muted">كلمة المرور الجديدة</label>
          <input
            type="password"
            value={newPassword}
            onChange={(e) => setNewPassword(e.target.value)}
            className="mb-4 w-full rounded-xl border border-neon-border bg-neon-bg p-3 text-neon-text outline-none focus:border-neon-purple"
          />
          {passwordMsg && <p className="mb-4 text-sm text-neon-purpleBright">{passwordMsg}</p>}
          <button
            disabled={savingPassword}
            className="w-full rounded-xl border border-neon-border py-3 font-bold text-neon-text disabled:opacity-50"
          >
            {savingPassword ? "جارٍ التغيير..." : "تغيير كلمة المرور"}
          </button>
        </form>
      </div>

      <button
        onClick={() => signOut({ callbackUrl: "/login" })}
        className="mt-5 w-full rounded-xl border border-neon-danger/40 py-3 font-bold text-neon-danger sm:w-auto sm:px-8"
      >
        تسجيل خروج
      </button>
    </AppShell>
  );
}
