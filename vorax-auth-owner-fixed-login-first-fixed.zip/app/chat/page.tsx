"use client";

import { useEffect, useState } from "react";
import AppShell from "@/components/AppShell";

type Chat = {
  id: string;
  status: string;
  merchant: { id: string; storeName: string };
  lastMessageAt: string;
};
type Message = { id: string; senderRole: string; content: string; createdAt: string };

export default function ChatPage() {
  const [chats, setChats] = useState<Chat[]>([]);
  const [active, setActive] = useState<Chat | null>(null);
  const [messages, setMessages] = useState<Message[]>([]);
  const [text, setText] = useState("");

  async function load() {
    const r = await fetch("/api/chat");
    if (r.ok) {
      const d = await r.json();
      setChats(d.chats);
    }
  }
  async function open(c: Chat) {
    setActive(c);
    const r = await fetch(`/api/chat/${c.id}/messages`);
    if (r.ok) {
      const d = await r.json();
      setMessages(d.messages);
    }
  }
  async function send() {
    if (!active || !text.trim()) return;
    const content = text.trim();
    setText("");
    const r = await fetch(`/api/chat/${active.id}/messages`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ content }),
    });
    if (r.ok) {
      const d = await r.json();
      setMessages((m) => [...m, d.message]);
    }
  }

  useEffect(() => {
    load();
  }, []);
  useEffect(() => {
    if (!active) return;
    const t = setInterval(() => open(active), 4000);
    return () => clearInterval(t);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [active?.id]);

  return (
    <AppShell>
      <h1 className="mb-4 text-xl font-bold text-neon-text">💬 الدعم والمحادثات</h1>
      <div className="grid gap-4 md:grid-cols-[280px_1fr]">
        <aside className="rounded-2xl border border-neon-border bg-neon-card p-3">
          {chats.length === 0 && (
            <p className="p-3 text-sm text-neon-muted">لا توجد محادثات بعد.</p>
          )}
          {chats.map((c) => (
            <button
              key={c.id}
              onClick={() => open(c)}
              className={`mb-2 w-full rounded-xl border p-3 text-right text-sm transition-colors ${
                active?.id === c.id
                  ? "border-neon-purple bg-neon-purple/10 text-neon-text"
                  : "border-neon-border text-neon-text hover:bg-neon-cardHover"
              }`}
            >
              {c.merchant.storeName}
              <div className="text-xs text-neon-muted">{c.status}</div>
            </button>
          ))}
        </aside>

        <section className="flex min-h-[65vh] flex-col rounded-2xl border border-neon-border bg-neon-card p-4">
          <h2 className="border-b border-neon-border pb-3 font-bold text-neon-text">
            {active ? active.merchant.storeName : "اختر محادثة"}
          </h2>
          <div className="flex-1 space-y-2 overflow-auto py-4">
            {messages.map((m) => (
              <div
                key={m.id}
                className={`max-w-[80%] rounded-2xl p-3 text-sm ${
                  m.senderRole === "CUSTOMER"
                    ? "mr-auto bg-neon-purple text-white"
                    : "ml-auto bg-neon-cardHover text-neon-text"
                }`}
              >
                {m.content}
                <div className="mt-1 text-[10px] opacity-60">
                  {new Date(m.createdAt).toLocaleString("ar-EG")}
                </div>
              </div>
            ))}
          </div>
          {active && (
            <div className="flex gap-2">
              <input
                value={text}
                onChange={(e) => setText(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === "Enter") send();
                }}
                placeholder="اكتب رسالتك..."
                className="flex-1 rounded-xl border border-neon-border bg-neon-bg px-4 py-2 text-neon-text outline-none focus:border-neon-purple"
              />
              <button
                onClick={send}
                className="rounded-xl bg-gradient-to-l from-neon-purple to-neon-purpleBright px-5 font-semibold text-white"
              >
                إرسال
              </button>
            </div>
          )}
        </section>
      </div>
    </AppShell>
  );
}
