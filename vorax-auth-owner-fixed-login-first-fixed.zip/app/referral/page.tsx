"use client";

import { useEffect, useState } from "react";
import { formatTikoun } from "@/lib/currency";

interface ReferralData {
  code: string;
  shareUrl: string;
  rewardPerReferral: number;
  totalReferred: number;
  totalRewarded: number;
  totalEarned: number;
}

export default function ReferralPage() {
  const [data, setData] = useState<ReferralData | null>(null);
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    fetch("/api/referral")
      .then((r) => r.json())
      .then(setData);
  }, []);

  async function copyLink() {
    if (!data) return;
    await navigator.clipboard.writeText(data.shareUrl).catch(() => {});
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  }

  return (
    <div dir="rtl" className="mx-auto max-w-lg p-8">
      <h1 className="mb-2 text-2xl font-bold text-neon-purpleBright">وين صحابك، اربح تيكون 🎁</h1>

      {!data ? (
        <p className="text-neon-muted">جارِ التحميل...</p>
      ) : (
        <>
          <p className="mb-6 text-sm text-neon-muted">
            شارك الرابط ديالك — نتا وصاحبك تاخذو{" "}
            <strong className="text-neon-purpleBright">{formatTikoun(data.rewardPerReferral)}</strong> لكل
            واحد بمجرد ما يدير صاحبك أول طلب.
          </p>

          <div className="mb-6 flex items-center gap-2 rounded-xl border border-neon-purple/20 bg-neon-card p-4">
            <code className="flex-1 truncate text-sm text-neon-muted">{data.shareUrl}</code>
            <button
              onClick={copyLink}
              className="shrink-0 rounded-lg bg-gradient-to-r from-blue-600 to-neon-purpleBright px-3 py-1.5 text-sm font-bold text-white"
            >
              {copied ? "تم النسخ ✓" : "نسخ"}
            </button>
          </div>

          <div className="grid grid-cols-3 gap-3 text-center">
            <div className="rounded-xl border border-neon-border bg-neon-card p-4">
              <p className="text-lg font-bold text-white">{data.totalReferred}</p>
              <p className="text-xs text-neon-muted">دعوات</p>
            </div>
            <div className="rounded-xl border border-neon-border bg-neon-card p-4">
              <p className="text-lg font-bold text-white">{data.totalRewarded}</p>
              <p className="text-xs text-neon-muted">مكافأة</p>
            </div>
            <div className="rounded-xl border border-neon-border bg-neon-card p-4">
              <p className="text-lg font-bold text-neon-purpleBright">{formatTikoun(data.totalEarned)}</p>
              <p className="text-xs text-neon-muted">أرباح</p>
            </div>
          </div>
        </>
      )}
    </div>
  );
}
