import type { Metadata } from "next";
import { SITE_NAME, SITE_URL } from "@/lib/seo";

export const metadata: Metadata = {
  title: `سياسة الخصوصية | ${SITE_NAME}`,
  description: `كيفاش ${SITE_NAME} كيجمع ويستعمل بياناتك الشخصية.`,
  alternates: { canonical: `${SITE_URL}/privacy` },
};

// ⚠️ نموذج عام — راجعه مع محامي، خصوصاً قبل تفعيل بوابة دفع (تتطلب تفاصيل
// عن معالجة بيانات البطاقات البنكية غير مذكورة هنا).
export default function PrivacyPage() {
  return (
    <div dir="rtl" className="min-h-screen bg-neon-bg px-4 py-12 text-neon-text">
      <div className="mx-auto max-w-2xl">
        <h1 className="mb-2 text-2xl font-bold text-neon-purpleBright">سياسة الخصوصية</h1>
        <p className="mb-8 text-sm text-neon-muted">آخر تحديث: [التاريخ]</p>

        <section className="mb-6 space-y-2">
          <h2 className="text-lg font-semibold text-white">1. البيانات اللي كنجمعو</h2>
          <ul className="list-inside list-disc space-y-1">
            <li>معلومات الحساب: الاسم، البريد الإلكتروني، رقم الهاتف</li>
            <li>معلومات الطلبات: الأرقام المشتراة، المبالغ، تاريخ الشراء</li>
            <li>معطيات تقنية: عنوان IP، وقت ومحاولات تسجيل الدخول (لأغراض الأمان فقط)</li>
          </ul>
        </section>

        <section className="mb-6 space-y-2">
          <h2 className="text-lg font-semibold text-white">2. كيفاش كنستعملو البيانات</h2>
          <p>
            كنستعملو بياناتك باش نديرو ونتبعو الطلبات، نأمّنو الحساب ديالك (كشف محاولات
            دخول مشبوهة)، نتواصلو معاك بخصوص الطلبات والدعم، ونحسّنو الخدمة (بدون بيع أو
            مشاركة بياناتك مع أطراف خارجية لأغراض تسويقية).
          </p>
        </section>

        <section className="mb-6 space-y-2">
          <h2 className="text-lg font-semibold text-white">3. الاحتفاظ بالبيانات</h2>
          <p>
            كنحتفظو بمعطيات الحساب والطلبات طول ما الحساب فعّال، ومدة إضافية بعد الحذف
            لأغراض محاسبية أو قانونية إذا اقتضى الأمر.
          </p>
        </section>

        <section className="mb-6 space-y-2">
          <h2 className="text-lg font-semibold text-white">4. حقوقك</h2>
          <p>
            عندك الحق فـ الوصول لبياناتك، تصحيحها، أو طلب حذف الحساب ديالك عبر التواصل معنا
            على [البريد الإلكتروني].
          </p>
        </section>

        <section className="space-y-2">
          <h2 className="text-lg font-semibold text-white">5. الأمان</h2>
          <p>
            كلمات السر مخزّنة مشفّرة (bcrypt)، وكنطبقو حماية ضد الطلبات المزوّرة (CSRF)
            ومحاولات الدخول المتكررة. رغم ذلك، ما كاين حل 100% آمن، وكنشجعوك تستعمل كلمة
            سر قوية وما تشاركهاش.
          </p>
        </section>
      </div>
    </div>
  );
}
