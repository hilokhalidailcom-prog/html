"use client";

import Link from "next/link";
import { Suspense, useEffect, useMemo, useState } from "react";
import { useSearchParams } from "next/navigation";
import AppShell from "@/components/AppShell";
import Icon from "@/components/Icon";
import { formatTikoun } from "@/lib/currency";

type Item = { id:string; phone:string; price:number; type:string; featured:boolean; country:{name:string;flag:string;code:string}; merchant?:{storeName:string;slug:string;verified:boolean}|null; rating:number };

type Country = { id:string; code:string; name:string; flag:string; available:number; fromPrice:number|null };

export default function StorePage(){
  return <Suspense fallback={<AppShell><div className="mx-auto max-w-7xl"><div className="h-48 animate-pulse rounded-3xl border bg-neon-card" /></div></AppShell>}><StoreContent /></Suspense>;
}

function StoreContent(){
  const params = useSearchParams();
  const service = params.get("service") || "";
  const [q,setQ]=useState(""); const [country,setCountry]=useState(""); const [type,setType]=useState(""); const [sort,setSort]=useState("newest"); const [min,setMin]=useState(""); const [max,setMax]=useState(""); const [featured,setFeatured]=useState(false);
  const [items,setItems]=useState<Item[]>([]); const [countries,setCountries]=useState<Country[]>([]); const [cursor,setCursor]=useState<string|null>(null); const [loading,setLoading]=useState(true); const [error,setError]=useState("");
  const category = service === "whatsapp" || service === "telegram" ? service : "";
  const title = category === "whatsapp" ? "خدمات WhatsApp" : category === "telegram" ? "خدمات Telegram" : "متجر VORAX";

  async function load(reset=true){
    setLoading(true); setError("");
    try { const p=new URLSearchParams(); if(q)p.set("q",q); if(category)p.set("category",category); if(country)p.set("country",country); if(type)p.set("type",type); if(sort)p.set("sort",sort); if(min)p.set("minPrice",min); if(max)p.set("maxPrice",max); if(!reset&&cursor)p.set("cursor",cursor);
      const r=await fetch(`/api/numbers?${p}`); if(!r.ok) throw new Error("تعذر تحميل المنتجات"); const d=await r.json(); const next=d.numbers||[]; setItems(reset?next:[...items,...next]); setCursor(d.nextCursor||null);
    } catch(e){ setError(e instanceof Error?e.message:"حدث خطأ"); } finally { setLoading(false); }
  }
  useEffect(()=>{ fetch("/api/countries").then(r=>r.json()).then(d=>setCountries(d.countries||[])).catch(()=>{}); },[]);
  useEffect(()=>{ load(true); // eslint-disable-next-line react-hooks/exhaustive-deps
  },[category]);
  const types=useMemo(()=>["NORMAL","VIP","REPEATED","EASY","INTERNATIONAL","VIRTUAL"],[ ]);

  return <AppShell><div className="mx-auto max-w-7xl">
    <section className="premium-gradient glass-panel overflow-hidden rounded-3xl p-6 md:p-8">
      <div className="flex flex-col gap-5 lg:flex-row lg:items-end lg:justify-between"><div><span className="text-sm font-semibold text-neon-purpleBright">VORAX MARKETPLACE</span><h1 className="mt-2 text-3xl font-black md:text-5xl">{title}</h1><p className="mt-3 max-w-2xl text-sm leading-7 text-neon-muted">ابحث، قارن واشترِ الأرقام والخدمات الرقمية من واجهة واحدة سريعة وواضحة.</p></div><Link href="/cart" className="inline-flex items-center gap-2 rounded-xl border border-neon-border bg-neon-surface px-4 py-2.5 text-sm font-bold hover:border-neon-purple/60"><Icon name="store" size={17}/> السلة</Link></div>
      <form onSubmit={e=>{e.preventDefault();setCursor(null);load(true)}} className="mt-7 flex flex-col gap-3 md:flex-row"><div className="flex flex-1 items-center gap-2 rounded-xl border border-neon-border bg-neon-bg/60 px-4"><Icon name="search" size={18}/><input value={q} onChange={e=>setQ(e.target.value)} placeholder="ابحث عن رقم أو خدمة..." className="w-full bg-transparent py-3.5 text-sm outline-none placeholder:text-neon-muted"/></div><button className="rounded-xl bg-gradient-to-l from-neon-purple to-neon-purpleBright px-7 py-3.5 font-bold">بحث</button></form>
    </section>

    <section className="mt-5 grid gap-3 rounded-2xl border border-neon-border bg-neon-surface/70 p-4 md:grid-cols-6">
      <select value={country} onChange={e=>setCountry(e.target.value)} className="rounded-xl border bg-neon-card px-3 py-2.5 text-sm"><option value="">كل الدول</option>{countries.map(c=><option key={c.code} value={c.code}>{c.flag} {c.name}</option>)}</select>
      <select value={type} onChange={e=>setType(e.target.value)} className="rounded-xl border bg-neon-card px-3 py-2.5 text-sm"><option value="">كل الأنواع</option>{types.map(t=><option key={t} value={t}>{t}</option>)}</select>
      <input value={min} onChange={e=>setMin(e.target.value)} inputMode="numeric" placeholder="أقل سعر" className="rounded-xl border bg-neon-card px-3 py-2.5 text-sm"/>
      <input value={max} onChange={e=>setMax(e.target.value)} inputMode="numeric" placeholder="أعلى سعر" className="rounded-xl border bg-neon-card px-3 py-2.5 text-sm"/>
      <select value={sort} onChange={e=>setSort(e.target.value)} className="rounded-xl border bg-neon-card px-3 py-2.5 text-sm"><option value="newest">الأحدث</option><option value="cheapest">الأقل سعرًا</option><option value="expensive">الأعلى سعرًا</option><option value="featured">المميز</option><option value="rating">الأعلى تقييمًا</option></select>
      <label className="flex cursor-pointer items-center gap-2 rounded-xl border bg-neon-card px-3 py-2.5 text-sm"><input type="checkbox" checked={featured} onChange={e=>setFeatured(e.target.checked)} className="accent-purple-500"/> المميز فقط</label>
      <button onClick={()=>{setCursor(null);load(true)}} className="md:col-span-6 rounded-xl border border-neon-purple/40 py-2.5 text-sm font-bold text-neon-purpleBright hover:bg-neon-purple/10">تطبيق الفلاتر</button>
    </section>

    <div className="mb-4 mt-8 flex items-center justify-between"><h2 className="text-xl font-bold">الخدمات المتاحة</h2><span className="text-sm text-neon-muted">{items.length} نتيجة</span></div>
    {error ? <div className="rounded-2xl border border-neon-danger/30 bg-neon-danger/10 p-8 text-center text-neon-danger">{error}</div> : loading && items.length===0 ? <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">{Array.from({length:6}).map((_,i)=><div key={i} className="h-52 animate-pulse rounded-2xl border bg-neon-card"/>)}</div> : items.length===0 ? <div className="rounded-2xl border border-dashed p-12 text-center text-neon-muted">لا توجد نتائج مطابقة للفلاتر الحالية.</div> : <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">{items.filter(i=>!featured||i.featured).map(n=><article key={n.id} className="group rounded-2xl border bg-neon-surface p-5 transition hover:-translate-y-0.5 hover:border-neon-purple/60 hover:bg-neon-cardHover"><div className="flex items-center justify-between"><span className="text-xs text-neon-muted">{n.country.flag} {n.country.name}</span>{n.featured&&<span className="rounded-full bg-neon-purple/10 px-2 py-1 text-[11px] font-bold text-neon-purpleBright">مميز</span>}</div><Link href={`/numbers/${n.id}`} className="mt-6 block text-center"><div dir="ltr" className="text-2xl font-black tracking-wide">{n.phone}</div><div className="mt-2 text-xs text-neon-muted">{n.type} · ⭐ {n.rating.toFixed(1)}</div></Link><div className="mt-5 flex items-end justify-between"><div><div className="text-xs text-neon-muted">السعر</div><div className="mt-1 text-lg font-black text-neon-purpleBright">{formatTikoun(n.price)}</div></div><Link href={`/numbers/${n.id}`} className="rounded-xl bg-white px-4 py-2 text-sm font-bold text-black transition group-hover:bg-neon-purpleBright">التفاصيل</Link></div>{n.merchant&&<Link href={`/store/${n.merchant.slug}`} className="mt-4 block border-t pt-3 text-xs text-neon-muted">{n.merchant.storeName}{n.merchant.verified?" · موثق":""}</Link>}</article>)}</div>}
    {cursor&&<button disabled={loading} onClick={()=>load(false)} className="mx-auto mt-8 block rounded-xl border px-6 py-3 text-sm font-bold hover:border-neon-purple disabled:opacity-50">{loading?"جارٍ التحميل…":"تحميل المزيد"}</button>}
  </div></AppShell>
}
