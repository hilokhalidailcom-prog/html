"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { useCart } from "@/lib/cart-context";
import { formatTikoun } from "@/lib/currency";
import InsufficientBalanceModal from "@/components/InsufficientBalanceModal";

export default function CartPage() {
  const { items, removeItem, total, clear } = useCart();
  const router = useRouter();

  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [modalOpen, setModalOpen] = useState(false);

  // Checkout form fields — pre-fill from the user's profile if you have it in session.
  const [customerName, setCustomerName] = useState("");
  const [customerPhone, setCustomerPhone] = useState("");
  const [customerEmail, setCustomerEmail] = useState("");

  // Promo code
  const [promoInput, setPromoInput] = useState("");
  const [promoChecking, setPromoChecking] = useState(false);
  const [promoError, setPromoError] = useState("");
  const [appliedPromo, setAppliedPromo] = useState<{ code: string; discount: number } | null>(null);

  const finalTotal = Math.max(0, total - (appliedPromo?.discount ?? 0));

  async function applyPromo() {
    if (!promoInput.trim()) return;
    setPromoChecking(true);
    setPromoError("");
    try {
      const res = await fetch("/api/promo/validate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ code: promoInput.trim(), subtotal: total }),
      });
      const data = await res.json();
      if (!res.ok || !data.valid) {
        setPromoError(data.error ?? "الكود غير صحيح");
        setAppliedPromo(null);
        return;
      }
      setAppliedPromo({ code: promoInput.trim().toUpperCase(), discount: data.discount });
    } finally {
      setPromoChecking(false);
    }
  }

  function removePromo() {
    setAppliedPromo(null);
    setPromoInput("");
    setPromoError("");
  }

  async function handleCheckout() {
    setLoading(true);
    setError("");
    try {
      const res = await fetch("/api/orders/checkout", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          numberIds: items.map((i) => i.numberId),
          customerName,
          customerPhone,
          customerEmail,
          promoCode: appliedPromo?.code,
        }),
      });
      const data = await res.json();

      if (res.status === 402 && data.error === "INSUFFICIENT_BALANCE") {
        setModalOpen(true);
        return;
      }
      if (!res.ok) {
        setError(data.error ?? "حدث خطأ");
        return;
      }

      clear();
      router.push(`/dashboard?order=${data.order.id}`);
    } finally {
      setLoading(false);
    }
  }

  if (items.length === 0) {
    return (
      <div dir="rtl" className="mx-auto max-w-lg p-8 text-center">
        <p className="text-neon-muted">السلة فارغة</p>
      </div>
    );
  }

  return (
    <div dir="rtl" className="mx-auto max-w-lg p-8">
      <h1 className="mb-6 text-2xl font-bold text-neon-purpleBright">السلة</h1>

      <div className="flex flex-col gap-2">
        {items.map((item) => (
          <div
            key={item.numberId}
            className="flex items-center justify-between rounded-xl border border-neon-border bg-neon-card px-4 py-3"
          >
            <div>
              <p className="font-mono text-white">
                {item.countryFlag} {item.phone}
              </p>
              <p className="text-sm text-neon-purpleBright">{formatTikoun(item.price)}</p>
            </div>
            <button
              onClick={() => removeItem(item.numberId)}
              className="text-sm text-neon-muted hover:text-red-400"
            >
              حذف
            </button>
          </div>
        ))}
      </div>

      <div className="mt-6 border-t border-neon-border pt-4">
        <div className="mb-3 flex gap-2">
          <input
            placeholder="كود الخصم (اختياري)"
            value={promoInput}
            disabled={!!appliedPromo}
            onChange={(e) => setPromoInput(e.target.value)}
            className="flex-1 rounded-lg border border-neon-border bg-neon-cardHover px-4 py-2 text-white outline-none focus:border-neon-purple disabled:opacity-60"
          />
          {appliedPromo ? (
            <button
              onClick={removePromo}
              className="rounded-lg border border-neon-border px-4 py-2 text-sm text-neon-muted hover:border-red-400 hover:text-red-400"
            >
              إلغاء
            </button>
          ) : (
            <button
              onClick={applyPromo}
              disabled={promoChecking || !promoInput.trim()}
              className="rounded-lg border border-neon-purple/40 px-4 py-2 text-sm font-bold text-neon-purpleBright disabled:opacity-50"
            >
              {promoChecking ? "..." : "تطبيق"}
            </button>
          )}
        </div>
        {promoError && <p className="mb-3 text-sm text-red-400">{promoError}</p>}
        {appliedPromo && (
          <p className="mb-3 text-sm text-green-400">
            ✓ تم تطبيق الكود {appliedPromo.code} — خصم {formatTikoun(appliedPromo.discount)}
          </p>
        )}

        <div className="flex items-center justify-between text-sm text-neon-muted">
          <span>المجموع الفرعي</span>
          <span>{formatTikoun(total)}</span>
        </div>
        {appliedPromo && appliedPromo.discount > 0 && (
          <div className="mt-1 flex items-center justify-between text-sm text-green-400">
            <span>الخصم</span>
            <span>- {formatTikoun(appliedPromo.discount)}</span>
          </div>
        )}
        <div className="mt-2 flex items-center justify-between border-t border-neon-border pt-2">
          <span className="text-neon-muted">المجموع النهائي</span>
          <span className="text-xl font-bold text-neon-purpleBright">{formatTikoun(finalTotal)}</span>
        </div>
      </div>

      <div className="mt-6 flex flex-col gap-3">
        <input
          required
          placeholder="الاسم الكامل"
          value={customerName}
          onChange={(e) => setCustomerName(e.target.value)}
          className="rounded-lg border border-neon-border bg-neon-cardHover px-4 py-2 text-white outline-none focus:border-neon-purple"
        />
        <input
          required
          placeholder="رقم الهاتف"
          value={customerPhone}
          onChange={(e) => setCustomerPhone(e.target.value)}
          className="rounded-lg border border-neon-border bg-neon-cardHover px-4 py-2 text-white outline-none focus:border-neon-purple"
        />
        <input
          type="email"
          required
          placeholder="البريد الإلكتروني"
          value={customerEmail}
          onChange={(e) => setCustomerEmail(e.target.value)}
          className="rounded-lg border border-neon-border bg-neon-cardHover px-4 py-2 text-white outline-none focus:border-neon-purple"
        />
        {error && <p className="text-sm text-red-400">{error}</p>}
        <button
          onClick={handleCheckout}
          disabled={loading || !customerName || !customerPhone || !customerEmail}
          className="rounded-lg bg-gradient-to-r from-blue-600 to-neon-purpleBright px-4 py-3 font-bold text-white transition hover:brightness-110 disabled:opacity-50"
        >
          {loading ? "..." : "اشتري الآن"}
        </button>
      </div>

      <InsufficientBalanceModal
        open={modalOpen}
        onClose={() => setModalOpen(false)}
        neededAmount={total}
      />
    </div>
  );
}
