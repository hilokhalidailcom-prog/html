"use client";

import { useEffect, useMemo, useState } from "react";
import AppShell from "@/components/AppShell";
import { formatTikoun } from "@/lib/currency";

type Order = {
  id: string;
  total: number;
  status: "PENDING" | "PROCESSING" | "COMPLETED" | "CANCELLED";
  createdAt: string;
  items: {
    id: string;
    price: number;
    number: { phone: string; country: { name: string; flag: string } };
  }[];
};

const STATUS_LABEL: Record<Order["status"], string> = {
  PENDING: "قيد المعالجة",
  PROCESSING: "قيد المعالجة",
  COMPLETED: "مكتمل",
  CANCELLED: "ملغي",
};

const STATUS_COLOR: Record<Order["status"], string> = {
  PENDING: "text-neon-warning bg-neon-warning/10",
  PROCESSING: "text-neon-warning bg-neon-warning/10",
  COMPLETED: "text-neon-green bg-neon-green/10",
  CANCELLED: "text-neon-danger bg-neon-danger/10",
};

export default function OrdersPage() {
  const [orders, setOrders] = useState<Order[]>([]);
  const [loading, setLoading] = useState(true);
  const [query, setQuery] = useState("");
  const [status, setStatus] = useState<"ALL" | Order["status"]>("ALL");

  useEffect(() => {
    fetch("/api/orders", { cache: "no-store" })
      .then((r) => r.json())
      .then((data) => setOrders(data.orders ?? []))
      .finally(() => setLoading(false));
  }, []);

  const filtered = useMemo(() => {
    return orders.filter((o) => {
      if (status !== "ALL" && o.status !== status) return false;
      if (!query) return true;
      const q = query.trim();
      return (
        o.id.includes(q) ||
        o.items.some((it) => it.number.phone.includes(q))
      );
    });
  }, [orders, query, status]);

  return (
    <AppShell>
      <h1 className="mb-6 text-xl font-bold text-neon-text">طلباتي</h1>

      <div className="mb-4 flex flex-col gap-3 sm:flex-row sm:items-center">
        <input
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="ابحث برقم الطلب أو الرقم..."
          className="w-full rounded-xl border border-neon-border bg-neon-card px-4 py-2 text-sm text-neon-text placeholder:text-neon-muted focus:border-neon-purple focus:outline-none sm:max-w-xs"
        />
        <div className="flex flex-wrap gap-2">
          {(["ALL", "COMPLETED", "PROCESSING", "CANCELLED"] as const).map((s) => (
            <button
              key={s}
              onClick={() => setStatus(s)}
              className={`rounded-full px-3 py-1.5 text-xs transition-colors ${
                status === s
                  ? "bg-neon-purple text-white"
                  : "bg-neon-card text-neon-muted hover:text-neon-text"
              }`}
            >
              {s === "ALL" ? "الكل" : STATUS_LABEL[s]}
            </button>
          ))}
        </div>
      </div>

      {loading ? (
        <p className="text-neon-muted">جارِ التحميل...</p>
      ) : filtered.length === 0 ? (
        <div className="rounded-2xl border border-neon-border bg-neon-card p-10 text-center text-neon-muted">
          لا توجد طلبات مطابقة
        </div>
      ) : (
        <div className="space-y-3">
          {filtered.map((order) => (
            <div
              key={order.id}
              className="rounded-2xl border border-neon-border bg-neon-card p-4 transition-colors hover:bg-neon-cardHover"
            >
              <div className="mb-2 flex flex-wrap items-center justify-between gap-2">
                <span className="text-xs text-neon-muted">#{order.id.slice(-8)}</span>
                <span
                  className={`rounded-full px-2.5 py-1 text-xs font-medium ${STATUS_COLOR[order.status]}`}
                >
                  {STATUS_LABEL[order.status]}
                </span>
              </div>
              <div className="mb-2 flex flex-wrap gap-2">
                {order.items.map((it) => (
                  <span
                    key={it.id}
                    className="rounded-lg bg-neon-bg px-2 py-1 text-xs text-neon-text"
                    dir="ltr"
                  >
                    {it.number.phone} · {it.number.country.name}
                  </span>
                ))}
              </div>
              <div className="flex items-center justify-between text-sm">
                <span className="text-neon-muted">
                  {new Date(order.createdAt).toLocaleDateString("ar-EG")}
                </span>
                <span className="font-semibold text-neon-purpleBright">
                  {formatTikoun(order.total)}
                </span>
              </div>
            </div>
          ))}
        </div>
      )}
    </AppShell>
  );
}
