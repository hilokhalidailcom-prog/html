"use client";

import { useEffect, useState } from "react";
import { formatTikoun } from "@/lib/currency";

interface UserRow {
  id: string;
  name: string;
  email: string;
  phone: string | null;
  role: string;
  status: string;
  balance: number;
  createdAt: string;
}

export default function AdminUsersPage() {
  const [users, setUsers] = useState<UserRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [q, setQ] = useState("");

  useEffect(() => {
    (async () => {
      const res = await fetch("/api/admin/users");
      const data = await res.json();
      if (!res.ok) setError((data as any).error ?? "تعذر تحميل المستخدمين");
      else setUsers(data);
      setLoading(false);
    })();
  }, []);

  const filtered = users.filter(
    (u) =>
      !q ||
      u.name.toLowerCase().includes(q.toLowerCase()) ||
      u.email.toLowerCase().includes(q.toLowerCase())
  );

  return (
    <div dir="rtl" className="mx-auto max-w-4xl p-8">
      <h1 className="mb-6 text-2xl font-bold text-neon-purpleBright">👥 المستخدمون</h1>
      <input
        placeholder="بحث بالاسم أو البريد"
        value={q}
        onChange={(e) => setQ(e.target.value)}
        className="mb-4 w-full max-w-sm rounded-lg border border-neon-border bg-neon-cardHover px-3 py-2 text-white outline-none focus:border-neon-purple"
      />

      {loading && <p className="text-neon-muted">جارِ التحميل...</p>}
      {error && <p className="text-red-400">{error}</p>}

      <div className="overflow-x-auto rounded-xl border border-neon-border">
        <table className="w-full text-sm">
          <thead className="bg-neon-card text-neon-muted">
            <tr>
              <th className="p-3 text-right">الاسم</th>
              <th className="p-3 text-right">البريد</th>
              <th className="p-3 text-right">الدور</th>
              <th className="p-3 text-right">الحالة</th>
              <th className="p-3 text-right">الرصيد</th>
              <th className="p-3 text-right">تاريخ التسجيل</th>
            </tr>
          </thead>
          <tbody>
            {filtered.map((u) => (
              <tr key={u.id} className="border-t border-neon-border">
                <td className="p-3 text-white">{u.name}</td>
                <td className="p-3 text-neon-muted">{u.email}</td>
                <td className="p-3 text-neon-muted">{u.role}</td>
                <td className="p-3 text-neon-muted">{u.status}</td>
                <td className="p-3 font-bold text-neon-purpleBright">{formatTikoun(u.balance)}</td>
                <td className="p-3 text-neon-muted">
                  {new Date(u.createdAt).toLocaleDateString("ar-MA")}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <p className="mt-3 text-xs text-neon-muted">
        عرض فقط — لا يوجد حاليًا API لتعليق/حظر مستخدم من هنا.
      </p>
    </div>
  );
}
