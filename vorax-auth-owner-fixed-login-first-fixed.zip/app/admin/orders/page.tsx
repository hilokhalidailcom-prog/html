"use client";

import { useEffect, useState } from "react";
import { formatTikoun } from "@/lib/currency";

interface OrderRow {
  id: string;
  status: "PENDING" | "PROCESSING" | "COMPLETED" | "CANCELLED";
  total: number;
  createdAt: string;
  user: { id: string; name: string; email: string };
  items: { number: { phone: string }; merchant: { storeName: string } | null }[];
}

const NEXT_STATUS: Record<OrderRow["status"], OrderRow["status"][]> = {
  PENDING: ["PROCESSING", "CANCELLED"],
  PROCESSING: ["COMPLETED", "CANCELLED"],
  COMPLETED: [],
  CANCELLED: [],
};

export default function AdminOrdersPage() {
  const [orders, setOrders] = useState<OrderRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [busyId, setBusyId] = useState<string | null>(null);

  async function load() {
    setLoading(true);
    const res = await fetch("/api/admin/orders");
    const data = await res.json();
    if (!res.ok) setError((data as any).error ?? "تعذر تحميل الطلبات");
    else setOrders(data);
    setLoading(false);
  }

  useEffect(() => {
    load();
  }, []);

  async function updateStatus(id: string, status: OrderRow["status"]) {
    setBusyId(id);
    try {
      const res = await fetch(`/api/admin/orders/${id}/status`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ status }),
      });
      if (res.ok) await load();
    } finally {
      setBusyId(null);
    }
  }

  return (
    <div dir="rtl" className="mx-auto max-w-5xl p-8">
      <h1 className="mb-6 text-2xl font-bold text-neon-purpleBright">🧾 كل الطلبات</h1>

      {loading && <p className="text-neon-muted">جارِ التحميل...</p>}
      {error && <p className="text-red-400">{error}</p>}

      <div className="flex flex-col gap-3">
        {orders.map((o) => (
          <div key={o.id} className="rounded-xl border border-neon-border bg-neon-card p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="font-bold text-white">
                  {o.user.name} · {formatTikoun(o.total)}
                </p>
                <p className="text-xs text-neon-muted">
                  {o.items.map((i) => `${i.number.phone}${i.merchant ? ` (${i.merchant.storeName})` : ""}`).join("، ")}
                </p>
                <p className="text-xs text-neon-muted">{new Date(o.createdAt).toLocaleString("ar-MA")}</p>
              </div>
              <div className="flex items-center gap-2">
                <span className="rounded-full bg-neon-cardHover px-3 py-1 text-xs text-neon-muted">
                  {o.status}
                </span>
                {NEXT_STATUS[o.status].map((next) => (
                  <button
                    key={next}
                    disabled={busyId === o.id}
                    onClick={() => updateStatus(o.id, next)}
                    className="rounded-lg bg-neon-purple px-3 py-1 text-xs font-bold text-white disabled:opacity-50"
                  >
                    → {next}
                  </button>
                ))}
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
