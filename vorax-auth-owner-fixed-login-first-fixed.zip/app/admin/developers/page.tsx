"use client";

import { useEffect, useState } from "react";

// Duplicated on purpose — do NOT import MERCHANT_PERMISSIONS from
// "@/lib/permissions" here. That file imports "@/lib/prisma" at module
// scope, and this is a "use client" component: importing it would pull
// the Prisma client into the browser bundle and break the build. Keep
// this list in sync with lib/permissions.ts by hand (or, better, add a
// small `GET /api/admin/developers/permissions` endpoint later that
// returns this list from the server instead of duplicating it).
const MERCHANT_PERMISSIONS = [
  "merchant.view",
  "merchant.create",
  "merchant.edit",
  "merchant.suspend",
  "merchant.products",
  "merchant.orders",
  "merchant.withdrawals",
  "merchant.approve",
  "merchant.commissions",
  "orders.view",
  "orders.manage",
  "ledger.view",
  "withdrawals.view",
  "withdrawals.approve",
  "reports.manage",
  "analytics.view",
  "notifications.manage",
  "developer.manage",
  "customer.view",
  "product.review",
  "withdrawals.manage",
  "platform.settings",
  "platform.analytics",
  "security.manage",
  "backup.manage",
  "ai.manage",
  "dynamic.manage",
  "notifications.view",
  "reports.view",
] as const;

interface DeveloperRow {
  id: string;
  name: string;
  email: string;
  status: string;
  permissions: string[];
}

export default function AdminDevelopersPage() {
  const [developers, setDevelopers] = useState<DeveloperRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [savingId, setSavingId] = useState<string | null>(null);
  const [draft, setDraft] = useState<Record<string, string[]>>({});

  async function load() {
    setLoading(true);
    setError("");
    const res = await fetch("/api/admin/developers");
    const data = await res.json();
    if (!res.ok) {
      setError((data as any).error ?? "تعذر تحميل قائمة المطورين");
      setDevelopers([]);
    } else {
      setDevelopers(data);
      setDraft(Object.fromEntries(data.map((d: DeveloperRow) => [d.id, d.permissions ?? []])));
    }
    setLoading(false);
  }

  useEffect(() => {
    load();
  }, []);

  function togglePermission(devId: string, perm: string) {
    setDraft((prev) => {
      const current = prev[devId] ?? [];
      const next = current.includes(perm) ? current.filter((p) => p !== perm) : [...current, perm];
      return { ...prev, [devId]: next };
    });
  }

  async function save(devId: string) {
    setSavingId(devId);
    try {
      const res = await fetch("/api/admin/developers", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ userId: devId, permissions: draft[devId] ?? [] }),
      });
      if (res.ok) await load();
    } finally {
      setSavingId(null);
    }
  }

  return (
    <div dir="rtl" className="mx-auto max-w-4xl p-8">
      <h1 className="mb-6 text-2xl font-bold text-neon-purpleBright">👨‍💻 صلاحيات المطورين</h1>

      {loading && <p className="text-neon-muted">جارِ التحميل...</p>}
      {error && <p className="text-red-400">{error}</p>}
      {!loading && !error && developers.length === 0 && (
        <p className="text-neon-muted">لا يوجد مستخدمون بدور DEVELOPER بعد.</p>
      )}

      <div className="flex flex-col gap-4">
        {developers.map((dev) => (
          <div key={dev.id} className="rounded-xl border border-neon-border bg-neon-card p-5">
            <div className="mb-3 flex items-center justify-between">
              <div>
                <p className="font-bold text-white">{dev.name}</p>
                <p className="text-xs text-neon-muted">{dev.email}</p>
              </div>
              <button
                disabled={savingId === dev.id}
                onClick={() => save(dev.id)}
                className="rounded-lg bg-neon-purple px-4 py-1.5 text-sm font-bold text-white disabled:opacity-50"
              >
                {savingId === dev.id ? "..." : "حفظ"}
              </button>
            </div>
            <div className="flex flex-wrap gap-2">
              {MERCHANT_PERMISSIONS.map((perm) => {
                const active = (draft[dev.id] ?? []).includes(perm);
                return (
                  <button
                    key={perm}
                    onClick={() => togglePermission(dev.id, perm)}
                    className={`rounded-full px-3 py-1 text-xs ${
                      active
                        ? "bg-neon-purple text-white"
                        : "bg-neon-cardHover text-neon-muted hover:bg-neon-cardHover"
                    }`}
                  >
                    {perm}
                  </button>
                );
              })}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
