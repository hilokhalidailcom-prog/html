"use client";

import { useEffect, useState } from "react";
import { formatTikoun } from "@/lib/currency";

interface WithdrawalRow {
  id: string;
  amount: number;
  status: "PENDING" | "APPROVED" | "REJECTED";
  note: string | null;
  rejectionReason: string | null;
  createdAt: string;
  merchant: { storeName: string; slug: string };
  user: { name: string; email: string };
}

export default function AdminWithdrawalsPage() {
  const [rows, setRows] = useState<WithdrawalRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [busyId, setBusyId] = useState<string | null>(null);
  const [statusFilter, setStatusFilter] = useState("PENDING");

  async function load() {
    setLoading(true);
    setError("");
    const res = await fetch(`/api/admin/withdrawals?status=${statusFilter}`);
    const data = await res.json();
    if (!res.ok) {
      setError((data as any).error ?? "تعذر التحميل");
      setRows([]);
    } else {
      setRows(data);
    }
    setLoading(false);
  }

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [statusFilter]);

  async function act(id: string, action: "APPROVE" | "REJECT") {
    setBusyId(id);
    try {
      const res = await fetch(`/api/admin/withdrawals/${id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action }),
      });
      const data = await res.json();
      if (!res.ok) {
        alert(data.error ?? "خطأ");
        return;
      }
      await load();
    } finally {
      setBusyId(null);
    }
  }

  return (
    <div dir="rtl" className="mx-auto max-w-4xl p-8">
      <h1 className="mb-6 text-2xl font-bold text-neon-purpleBright">💸 طلبات السحب</h1>

      <div className="mb-4 flex gap-2 text-sm">
        {["PENDING", "APPROVED", "REJECTED"].map((s) => (
          <button
            key={s}
            onClick={() => setStatusFilter(s)}
            className={`rounded-full px-3 py-1 ${
              statusFilter === s ? "bg-neon-purple text-white" : "bg-neon-cardHover text-neon-muted hover:bg-neon-cardHover"
            }`}
          >
            {s}
          </button>
        ))}
      </div>

      {loading && <p className="text-neon-muted">جارِ التحميل...</p>}
      {error && <p className="text-red-400">{error}</p>}
      {!loading && !error && rows.length === 0 && <p className="text-neon-muted">لا توجد طلبات.</p>}

      <div className="flex flex-col gap-3">
        {rows.map((w) => (
          <div key={w.id} className="rounded-xl border border-neon-border bg-neon-card p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="font-bold text-white">
                  {w.merchant.storeName} · {formatTikoun(w.amount)}
                </p>
                <p className="text-xs text-neon-muted">{w.user.email}</p>
                {w.note && <p className="mt-1 text-xs text-neon-muted">{w.note}</p>}
              </div>
              {w.status === "PENDING" && (
                <div className="flex gap-2">
                  <button
                    disabled={busyId === w.id}
                    onClick={() => act(w.id, "APPROVE")}
                    className="rounded-lg bg-emerald-600 px-3 py-1 text-sm font-bold text-white disabled:opacity-50"
                  >
                    موافقة
                  </button>
                  <button
                    disabled={busyId === w.id}
                    onClick={() => act(w.id, "REJECT")}
                    className="rounded-lg bg-red-900/60 px-3 py-1 text-sm text-red-300 disabled:opacity-50"
                  >
                    رفض
                  </button>
                </div>
              )}
            </div>
          </div>
        ))}
      </div>
      <p className="mt-4 text-xs text-neon-muted">
        الموافقة تسجّل الحركة في السجل المحاسبي فقط — التحويل الفعلي للفلوس يتم يدويًا خارج المنصة.
      </p>
    </div>
  );
}
