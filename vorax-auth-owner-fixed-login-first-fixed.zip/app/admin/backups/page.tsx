"use client";

import { useEffect, useState } from "react";

interface BackupRow {
  id: string;
  status: string;
  createdAt: string;
}

export default function AdminBackupsPage() {
  const [rows, setRows] = useState<BackupRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [requesting, setRequesting] = useState(false);
  const [note, setNote] = useState("");

  async function load() {
    setLoading(true);
    const res = await fetch("/api/admin/backups");
    const data = await res.json();
    if (!res.ok) setError((data as any).error ?? "تعذر التحميل");
    else setRows(data);
    setLoading(false);
  }

  useEffect(() => {
    load();
  }, []);

  async function requestBackup() {
    setRequesting(true);
    setNote("");
    try {
      const res = await fetch("/api/admin/backups", { method: "POST" });
      const data = await res.json();
      if (res.ok) {
        setNote(data.instructions ?? "تم تسجيل الطلب.");
        await load();
      } else {
        setNote(data.error ?? "خطأ");
      }
    } finally {
      setRequesting(false);
    }
  }

  return (
    <div dir="rtl" className="mx-auto max-w-2xl p-8">
      <h1 className="mb-2 text-2xl font-bold text-neon-purpleBright">💾 النسخ الاحتياطي</h1>
      <p className="mb-6 text-sm text-neon-muted">Owner فقط.</p>

      <button
        disabled={requesting}
        onClick={requestBackup}
        className="mb-4 rounded-lg bg-neon-purple px-4 py-2 text-sm font-bold text-white disabled:opacity-50"
      >
        {requesting ? "..." : "طلب نسخة احتياطية جديدة"}
      </button>
      {note && <p className="mb-4 rounded-lg bg-neon-card p-3 text-xs text-neon-muted">{note}</p>}

      {loading && <p className="text-neon-muted">جارِ التحميل...</p>}
      {error && <p className="text-red-400">{error}</p>}

      <div className="flex flex-col gap-2">
        {rows.map((b) => (
          <div
            key={b.id}
            className="flex items-center justify-between rounded-lg border border-neon-border bg-neon-card p-3 text-sm"
          >
            <span className="text-neon-muted">{new Date(b.createdAt).toLocaleString("ar-MA")}</span>
            <span className="rounded-full bg-neon-cardHover px-2 py-1 text-xs text-neon-muted">{b.status}</span>
          </div>
        ))}
      </div>
      <p className="mt-4 text-xs text-neon-muted">
        هذا السجل تتبّعي فقط — تنفيذ النسخ الفعلي (`pg_dump` + رفعه لتخزين خارجي) بيتم من جدولة على السيرفر، مش من هنا.
      </p>
    </div>
  );
}
