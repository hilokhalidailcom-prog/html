"use client";

import { useEffect, useState } from "react";

interface MerchantRow {
  id: string;
  storeName: string;
  slug: string;
  status: "PENDING" | "ACTIVE" | "SUSPENDED" | "CLOSED";
  verified: boolean;
  commissionPercent: number;
  country: string | null;
  createdAt: string;
  user: { id: string; name: string; email: string; status: string };
}

const STATUSES = ["PENDING", "ACTIVE", "SUSPENDED", "CLOSED"] as const;

const STATUS_LABEL: Record<string, string> = {
  PENDING: "🟡 قيد المراجعة",
  ACTIVE: "🟢 نشط",
  SUSPENDED: "🔴 معلّق",
  CLOSED: "⚫ مغلق",
};

export default function AdminMerchantsPage() {
  const [merchants, setMerchants] = useState<MerchantRow[]>([]);
  const [busyId, setBusyId] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [forbidden, setForbidden] = useState(false);

  const [userEmail, setUserEmail] = useState("");
  const [storeName, setStoreName] = useState("");
  const [slug, setSlug] = useState("");
  const [country, setCountry] = useState("");
  const [commissionPercent, setCommissionPercent] = useState("10");
  const [creating, setCreating] = useState(false);
  const [error, setError] = useState("");

  async function load() {
    setLoading(true);
    const res = await fetch("/api/admin/merchants");
    if (res.status === 403) {
      setForbidden(true);
      setLoading(false);
      return;
    }
    const data = await res.json();
    setMerchants(data.merchants ?? []);
    setLoading(false);
  }

  useEffect(() => {
    load();
  }, []);

  async function handleCreate(e: React.FormEvent) {
    e.preventDefault();
    setCreating(true);
    setError("");
    try {
      const res = await fetch("/api/admin/merchants", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          userEmail,
          storeName,
          slug,
          country: country || undefined,
          commissionPercent: Number(commissionPercent) || 10,
        }),
      });
      const data = await res.json();
      if (!res.ok) {
        setError(data.error ?? "حدث خطأ");
        return;
      }
      setUserEmail("");
      setStoreName("");
      setSlug("");
      setCountry("");
      setCommissionPercent("10");
      await load();
    } finally {
      setCreating(false);
    }
  }

  async function patchMerchant(id: string, data: Record<string, unknown>) {
    setBusyId(id);
    try {
      const res = await fetch(`/api/admin/merchants/${id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });
      if (!res.ok) {
        const body = await res.json().catch(() => ({}));
        alert(body.error ?? "فشل التعديل");
        return;
      }
      await load();
    } finally {
      setBusyId(null);
    }
  }

  async function archive(id: string) {
    if (!confirm("متأكد أنك تريد أرشفة (إغلاق) هذا المتجر؟")) return;
    setBusyId(id);
    try {
      const res = await fetch(`/api/admin/merchants/${id}`, { method: "DELETE" });
      if (!res.ok) {
        const body = await res.json().catch(() => ({}));
        alert(body.error ?? "فشل الإغلاق");
        return;
      }
      await load();
    } finally {
      setBusyId(null);
    }
  }

  if (forbidden) {
    return (
      <div dir="rtl" className="mx-auto max-w-2xl p-8 text-center text-red-400">
        ❌ لا تملك الصلاحية الكافية لعرض هذه الصفحة (تحتاج صلاحية merchant.view).
      </div>
    );
  }

  return (
    <div dir="rtl" className="mx-auto max-w-5xl p-8">
      <h1 className="mb-6 text-2xl font-bold text-neon-purpleBright">🏪 إدارة التجار</h1>

      <form
        onSubmit={handleCreate}
        className="mb-8 grid grid-cols-2 gap-3 rounded-xl border border-neon-border bg-neon-card p-5 sm:grid-cols-6"
      >
        <input
          required
          type="email"
          placeholder="بريد المستخدم"
          value={userEmail}
          onChange={(e) => setUserEmail(e.target.value)}
          className="col-span-2 rounded-lg border border-neon-border bg-neon-cardHover px-3 py-2 text-white outline-none focus:border-neon-purple"
        />
        <input
          required
          placeholder="اسم المتجر"
          value={storeName}
          onChange={(e) => setStoreName(e.target.value)}
          className="col-span-2 rounded-lg border border-neon-border bg-neon-cardHover px-3 py-2 text-white outline-none focus:border-neon-purple"
        />
        <input
          required
          placeholder="الرابط (slug) — أحرف صغيرة وأرقام وشرطات"
          value={slug}
          onChange={(e) => setSlug(e.target.value)}
          className="col-span-2 rounded-lg border border-neon-border bg-neon-cardHover px-3 py-2 text-white outline-none focus:border-neon-purple"
        />
        <input
          placeholder="الدولة (اختياري)"
          value={country}
          onChange={(e) => setCountry(e.target.value)}
          className="rounded-lg border border-neon-border bg-neon-cardHover px-3 py-2 text-white outline-none focus:border-neon-purple"
        />
        <input
          type="number"
          min={0}
          max={100}
          placeholder="عمولة %"
          value={commissionPercent}
          onChange={(e) => setCommissionPercent(e.target.value)}
          className="rounded-lg border border-neon-border bg-neon-cardHover px-3 py-2 text-white outline-none focus:border-neon-purple"
        />
        <button
          type="submit"
          disabled={creating}
          className="col-span-2 rounded-lg bg-gradient-to-r from-blue-600 to-neon-purpleBright px-4 py-2 font-bold text-white disabled:opacity-50 sm:col-span-2"
        >
          {creating ? "..." : "➕ إنشاء تاجر"}
        </button>
        {error && <p className="col-span-full text-sm text-red-400">{error}</p>}
      </form>

      {loading ? (
        <p className="text-neon-muted">جاري التحميل...</p>
      ) : merchants.length === 0 ? (
        <p className="text-neon-muted">لا يوجد تجار بعد.</p>
      ) : (
        <div className="flex flex-col gap-2">
          {merchants.map((m) => (
            <div
              key={m.id}
              className="flex flex-wrap items-center justify-between gap-3 rounded-xl border border-neon-border bg-neon-card p-4"
            >
              <div>
                <p className="font-semibold text-white">
                  🏪 {m.storeName} {m.verified && <span className="text-neon-purpleBright">✓</span>}
                </p>
                <p className="text-xs text-neon-muted">
                  {m.user.email} · /{m.slug} · عمولة {m.commissionPercent}% {m.country ? `· ${m.country}` : ""}
                </p>
              </div>
              <div className="flex flex-wrap items-center gap-2">
                <select
                  value={m.status}
                  disabled={busyId === m.id}
                  onChange={(e) => patchMerchant(m.id, { status: e.target.value })}
                  className="rounded-lg border border-neon-border bg-neon-cardHover px-2 py-1 text-sm text-white outline-none"
                >
                  {STATUSES.map((s) => (
                    <option key={s} value={s}>
                      {STATUS_LABEL[s]}
                    </option>
                  ))}
                </select>
                <button
                  disabled={busyId === m.id}
                  onClick={() => patchMerchant(m.id, { verified: !m.verified })}
                  className="rounded-lg border border-neon-purple/40 px-3 py-1 text-sm text-neon-purpleBright disabled:opacity-50"
                >
                  {m.verified ? "إلغاء التوثيق" : "✓ توثيق"}
                </button>
                <button
                  disabled={busyId === m.id}
                  onClick={() => archive(m.id)}
                  className="rounded-lg border border-red-500/40 px-3 py-1 text-sm text-red-400 disabled:opacity-50"
                >
                  أرشفة
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
