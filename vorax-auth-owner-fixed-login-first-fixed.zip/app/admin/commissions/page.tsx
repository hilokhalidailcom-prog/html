"use client";

import { useEffect, useState } from "react";

interface CommissionRule {
  id: string;
  scope: "GLOBAL" | "CATEGORY" | "MERCHANT";
  percent: number;
  active: boolean;
  category: { name: string } | null;
  merchant: { storeName: string } | null;
}

export default function AdminCommissionsPage() {
  const [rules, setRules] = useState<CommissionRule[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  const [scope, setScope] = useState<CommissionRule["scope"]>("GLOBAL");
  const [percent, setPercent] = useState("10");
  const [categoryId, setCategoryId] = useState("");
  const [merchantId, setMerchantId] = useState("");
  const [creating, setCreating] = useState(false);

  async function load() {
    setLoading(true);
    const res = await fetch("/api/admin/commissions");
    const data = await res.json();
    if (!res.ok) setError((data as any).error ?? "تعذر التحميل");
    else setRules(data);
    setLoading(false);
  }

  useEffect(() => {
    load();
  }, []);

  async function handleCreate(e: React.FormEvent) {
    e.preventDefault();
    setCreating(true);
    try {
      const res = await fetch("/api/admin/commissions", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          scope,
          percent: Number(percent),
          categoryId: scope === "CATEGORY" ? categoryId || undefined : undefined,
          merchantId: scope === "MERCHANT" ? merchantId || undefined : undefined,
        }),
      });
      if (res.ok) {
        setPercent("10");
        setCategoryId("");
        setMerchantId("");
        await load();
      }
    } finally {
      setCreating(false);
    }
  }

  return (
    <div dir="rtl" className="mx-auto max-w-3xl p-8">
      <h1 className="mb-6 text-2xl font-bold text-neon-purpleBright">💼 قواعد العمولة</h1>

      <form
        onSubmit={handleCreate}
        className="mb-6 flex flex-wrap items-end gap-3 rounded-xl border border-neon-border bg-neon-card p-4"
      >
        <div className="flex flex-col gap-1">
          <label className="text-xs text-neon-muted">النطاق</label>
          <select
            value={scope}
            onChange={(e) => setScope(e.target.value as CommissionRule["scope"])}
            className="rounded-lg border border-neon-border bg-neon-cardHover px-3 py-2 text-sm text-white"
          >
            <option value="GLOBAL">عام (كل المنصة)</option>
            <option value="CATEGORY">تصنيف معيّن</option>
            <option value="MERCHANT">تاجر معيّن</option>
          </select>
        </div>
        <div className="flex flex-col gap-1">
          <label className="text-xs text-neon-muted">النسبة %</label>
          <input
            type="number"
            min={0}
            max={100}
            value={percent}
            onChange={(e) => setPercent(e.target.value)}
            className="w-24 rounded-lg border border-neon-border bg-neon-cardHover px-3 py-2 text-sm text-white"
          />
        </div>
        {scope === "CATEGORY" && (
          <div className="flex flex-col gap-1">
            <label className="text-xs text-neon-muted">معرّف التصنيف</label>
            <input
              value={categoryId}
              onChange={(e) => setCategoryId(e.target.value)}
              className="rounded-lg border border-neon-border bg-neon-cardHover px-3 py-2 text-sm text-white"
            />
          </div>
        )}
        {scope === "MERCHANT" && (
          <div className="flex flex-col gap-1">
            <label className="text-xs text-neon-muted">معرّف التاجر</label>
            <input
              value={merchantId}
              onChange={(e) => setMerchantId(e.target.value)}
              className="rounded-lg border border-neon-border bg-neon-cardHover px-3 py-2 text-sm text-white"
            />
          </div>
        )}
        <button
          disabled={creating}
          className="rounded-lg bg-emerald-600 px-4 py-2 text-sm font-bold text-white disabled:opacity-50"
        >
          {creating ? "..." : "إضافة قاعدة"}
        </button>
      </form>

      {loading && <p className="text-neon-muted">جارِ التحميل...</p>}
      {error && <p className="text-red-400">{error}</p>}

      <ul className="flex flex-col gap-2">
        {rules.map((r) => (
          <li
            key={r.id}
            className="flex items-center justify-between rounded-lg border border-neon-border bg-neon-card p-3 text-sm"
          >
            <span className="text-neon-text">
              {r.scope}
              {r.category ? ` — ${r.category.name}` : ""}
              {r.merchant ? ` — ${r.merchant.storeName}` : ""}
            </span>
            <span className="font-bold text-neon-purpleBright">{r.percent}%</span>
          </li>
        ))}
      </ul>
      <p className="mt-3 text-xs text-neon-muted">
        عمولة كل تاجر الفردية (`Merchant.commissionPercent`) لسه هي المستخدمة فعليًا وقت البيع — قواعد الـ scope دي إطار عام، مش مطبّق تلقائيًا في الـ checkout بعد.
      </p>
    </div>
  );
}
