"use client";

import { useEffect, useState } from "react";

type Tab = "categories" | "types" | "merchant-categories" | "filters" | "homepage" | "offers";

const TABS: { key: Tab; label: string; endpoint: string }[] = [
  { key: "categories", label: "تصنيفات المنتجات", endpoint: "/api/admin/dynamic/categories" },
  { key: "types", label: "أنواع المنتجات", endpoint: "/api/admin/dynamic/types" },
  { key: "merchant-categories", label: "تصنيفات التجار", endpoint: "/api/admin/dynamic/merchant-categories" },
  { key: "filters", label: "الفلاتر", endpoint: "/api/admin/dynamic/filters" },
  { key: "homepage", label: "أقسام الصفحة الرئيسية", endpoint: "/api/admin/dynamic/homepage" },
  { key: "offers", label: "العروض", endpoint: "/api/admin/dynamic/offers" },
];

// Each of these resources has its own required-field shape — kept as a
// small per-tab form-field list rather than one generic form, since e.g.
// Offers need discountType/amount/dates that Categories don't have.
const FIELDS: Record<Tab, { key: string; label: string; type: "text" | "number" | "date" }[]> = {
  categories: [
    { key: "name", label: "الاسم", type: "text" },
    { key: "slug", label: "الرابط (slug)", type: "text" },
  ],
  types: [
    { key: "name", label: "الاسم", type: "text" },
    { key: "slug", label: "الرابط (slug)", type: "text" },
  ],
  "merchant-categories": [
    { key: "name", label: "الاسم", type: "text" },
    { key: "slug", label: "الرابط (slug)", type: "text" },
  ],
  filters: [
    { key: "name", label: "الاسم", type: "text" },
    { key: "slug", label: "الرابط (slug)", type: "text" },
    { key: "field", label: "الحقل (field)", type: "text" },
  ],
  homepage: [
    { key: "title", label: "العنوان", type: "text" },
    { key: "slug", label: "الرابط (slug)", type: "text" },
    { key: "kind", label: "النوع (kind)", type: "text" },
  ],
  offers: [
    { key: "title", label: "العنوان", type: "text" },
    { key: "amount", label: "القيمة", type: "number" },
    { key: "startsAt", label: "تاريخ البدء", type: "date" },
  ],
};

export default function AdminDynamicPage() {
  const [tab, setTab] = useState<Tab>("categories");
  const [items, setItems] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [form, setForm] = useState<Record<string, string>>({});
  const [creating, setCreating] = useState(false);

  const activeTab = TABS.find((t) => t.key === tab)!;

  async function load() {
    setLoading(true);
    setError("");
    const res = await fetch(activeTab.endpoint);
    const data = await res.json().catch(() => []);
    if (!res.ok) {
      setError((data as any).error ?? "تعذر التحميل");
      setItems([]);
    } else {
      setItems(Array.isArray(data) ? data : []);
    }
    setLoading(false);
  }

  useEffect(() => {
    setForm({});
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [tab]);

  async function handleCreate(e: React.FormEvent) {
    e.preventDefault();
    setCreating(true);
    try {
      const body: Record<string, any> = { ...form };
      if (tab === "offers") {
        body.amount = Number(form.amount || 0);
        body.discountType = "FIXED"; // simple default; extend to a select if PERCENT is needed
      }
      const res = await fetch(activeTab.endpoint, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body),
      });
      if (res.ok) {
        setForm({});
        await load();
      }
    } finally {
      setCreating(false);
    }
  }

  return (
    <div dir="rtl" className="mx-auto max-w-4xl p-8">
      <h1 className="mb-6 text-2xl font-bold text-neon-purpleBright">🧩 المنصة الديناميكية</h1>

      <div className="mb-6 flex flex-wrap gap-2 text-sm">
        {TABS.map((t) => (
          <button
            key={t.key}
            onClick={() => setTab(t.key)}
            className={`rounded-full px-3 py-1 ${
              tab === t.key ? "bg-neon-purple text-white" : "bg-neon-cardHover text-neon-muted hover:bg-neon-cardHover"
            }`}
          >
            {t.label}
          </button>
        ))}
      </div>

      <form
        onSubmit={handleCreate}
        className="mb-6 flex flex-wrap items-end gap-3 rounded-xl border border-neon-border bg-neon-card p-4"
      >
        {FIELDS[tab].map((f) => (
          <div key={f.key} className="flex flex-col gap-1">
            <label className="text-xs text-neon-muted">{f.label}</label>
            <input
              type={f.type}
              required
              value={form[f.key] ?? ""}
              onChange={(e) => setForm((p) => ({ ...p, [f.key]: e.target.value }))}
              className="rounded-lg border border-neon-border bg-neon-cardHover px-3 py-2 text-sm text-white outline-none focus:border-neon-purple"
            />
          </div>
        ))}
        <button
          type="submit"
          disabled={creating}
          className="rounded-lg bg-emerald-600 px-4 py-2 text-sm font-bold text-white disabled:opacity-50"
        >
          {creating ? "..." : "إضافة"}
        </button>
      </form>

      {loading && <p className="text-neon-muted">جارِ التحميل...</p>}
      {error && <p className="text-red-400">{error}</p>}
      {!loading && !error && items.length === 0 && <p className="text-neon-muted">لا توجد عناصر بعد.</p>}

      <ul className="flex flex-col gap-2">
        {items.map((item) => (
          <li key={item.id} className="rounded-lg border border-neon-border bg-neon-card p-3 text-sm text-neon-text">
            {item.name ?? item.title} {item.slug ? <span className="text-neon-muted">— {item.slug}</span> : null}
          </li>
        ))}
      </ul>
    </div>
  );
}
