"use client";

import { useEffect, useState } from "react";
import { formatTikoun } from "@/lib/currency";

interface TopUp {
  id: string;
  amount: number;
  note: string | null;
  createdAt: string;
  user: { id: string; name: string; email: string; balance: number };
}

export default function AdminTopUpsPage() {
  const [topUps, setTopUps] = useState<TopUp[]>([]);
  const [busyId, setBusyId] = useState<string | null>(null);

  async function load() {
    const res = await fetch("/api/admin/topups");
    const data = await res.json();
    setTopUps(data.topUps ?? []);
  }

  useEffect(() => {
    load();
  }, []);

  async function resolve(id: string, action: "confirm" | "reject") {
    setBusyId(id);
    try {
      await fetch(`/api/admin/topups/${id}/confirm`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action }),
      });
      await load();
    } finally {
      setBusyId(null);
    }
  }

  return (
    <div dir="rtl" className="mx-auto max-w-2xl p-8">
      <h1 className="mb-6 text-2xl font-bold text-neon-purpleBright">طلبات شحن الرصيد</h1>
      {topUps.length === 0 && <p className="text-neon-muted">لا توجد طلبات معلّقة 🎉</p>}
      <div className="flex flex-col gap-3">
        {topUps.map((t) => (
          <div key={t.id} className="rounded-xl border border-neon-border bg-neon-card p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="font-semibold text-white">{t.user.name}</p>
                <p className="text-xs text-neon-muted">{t.user.email}</p>
                <p className="mt-1 text-sm text-neon-muted">
                  المبلغ المطلوب: <span className="font-bold text-neon-purpleBright">{formatTikoun(t.amount)}</span>
                </p>
                <p className="text-xs text-neon-muted">الرصيد الحالي: {formatTikoun(t.user.balance)}</p>
                {t.note && <p className="mt-1 text-xs text-neon-muted">ملاحظة: {t.note}</p>}
              </div>
              <div className="flex flex-col gap-2">
                <button
                  disabled={busyId === t.id}
                  onClick={() => resolve(t.id, "confirm")}
                  className="rounded-lg bg-neon-purple px-4 py-2 text-sm font-bold text-white disabled:opacity-50"
                >
                  تأكيد الشحن
                </button>
                <button
                  disabled={busyId === t.id}
                  onClick={() => resolve(t.id, "reject")}
                  className="rounded-lg border border-red-500/40 px-4 py-2 text-sm font-bold text-red-400 disabled:opacity-50"
                >
                  رفض
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
