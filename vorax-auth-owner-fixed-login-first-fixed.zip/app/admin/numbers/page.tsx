"use client";

import { useEffect, useState } from "react";
import { formatTikoun } from "@/lib/currency";

interface Country {
  id: string;
  name: string;
  code: string;
  flag: string;
}

interface PhoneNumberRow {
  id: string;
  phone: string;
  type: string;
  price: number;
  status: string;
  featured: boolean;
  country: Country;
}

const TYPES = ["NORMAL", "VIP", "REPEATED", "EASY", "INTERNATIONAL", "VIRTUAL"] as const;
const STATUSES = ["AVAILABLE", "RESERVED", "SOLD", "HIDDEN"] as const;

export default function AdminNumbersPage() {
  const [numbers, setNumbers] = useState<PhoneNumberRow[]>([]);
  const [countries, setCountries] = useState<Country[]>([]);
  const [busyId, setBusyId] = useState<string | null>(null);

  const [phone, setPhone] = useState("");
  const [countryId, setCountryId] = useState("");
  const [type, setType] = useState<typeof TYPES[number]>("NORMAL");
  const [price, setPrice] = useState("");
  const [featured, setFeatured] = useState(false);
  const [creating, setCreating] = useState(false);
  const [error, setError] = useState("");

  async function load() {
    const [numRes, countryRes] = await Promise.all([
      fetch("/api/admin/numbers"),
      fetch("/api/admin/countries"),
    ]);
    const numData = await numRes.json();
    const countryData = await countryRes.json();
    setNumbers(numData.numbers ?? []);
    setCountries(countryData.countries ?? []);
    if (!countryId && countryData.countries?.[0]) setCountryId(countryData.countries[0].id);
  }

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  async function handleCreate(e: React.FormEvent) {
    e.preventDefault();
    setCreating(true);
    setError("");
    try {
      const res = await fetch("/api/admin/numbers", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          phone,
          countryId,
          type,
          price: Number(price),
          featured,
        }),
      });
      const data = await res.json();
      if (!res.ok) {
        setError(data.error ?? "حدث خطأ");
        return;
      }
      setPhone("");
      setPrice("");
      setFeatured(false);
      await load();
    } finally {
      setCreating(false);
    }
  }

  async function updateStatus(id: string, status: string) {
    setBusyId(id);
    try {
      await fetch(`/api/admin/numbers/${id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ status }),
      });
      await load();
    } finally {
      setBusyId(null);
    }
  }

  async function remove(id: string) {
    setBusyId(id);
    try {
      await fetch(`/api/admin/numbers/${id}`, { method: "DELETE" });
      await load();
    } finally {
      setBusyId(null);
    }
  }

  return (
    <div dir="rtl" className="mx-auto max-w-4xl p-8">
      <h1 className="mb-6 text-2xl font-bold text-neon-purpleBright">إدارة الأرقام</h1>

      <form
        onSubmit={handleCreate}
        className="mb-8 grid grid-cols-2 gap-3 rounded-xl border border-neon-border bg-neon-card p-5 sm:grid-cols-6"
      >
        <input
          required
          placeholder="الرقم"
          value={phone}
          onChange={(e) => setPhone(e.target.value)}
          className="col-span-2 rounded-lg border border-neon-border bg-neon-cardHover px-3 py-2 text-white outline-none focus:border-neon-purple"
        />
        <select
          value={countryId}
          onChange={(e) => setCountryId(e.target.value)}
          className="rounded-lg border border-neon-border bg-neon-cardHover px-3 py-2 text-white outline-none focus:border-neon-purple"
        >
          {countries.map((c) => (
            <option key={c.id} value={c.id}>
              {c.flag} {c.name}
            </option>
          ))}
        </select>
        <select
          value={type}
          onChange={(e) => setType(e.target.value as typeof TYPES[number])}
          className="rounded-lg border border-neon-border bg-neon-cardHover px-3 py-2 text-white outline-none focus:border-neon-purple"
        >
          {TYPES.map((t) => (
            <option key={t} value={t}>
              {t}
            </option>
          ))}
        </select>
        <input
          required
          type="number"
          min={1}
          placeholder="السعر (تيكون)"
          value={price}
          onChange={(e) => setPrice(e.target.value)}
          className="rounded-lg border border-neon-border bg-neon-cardHover px-3 py-2 text-white outline-none focus:border-neon-purple"
        />
        <label className="flex items-center gap-2 text-sm text-neon-muted">
          <input type="checkbox" checked={featured} onChange={(e) => setFeatured(e.target.checked)} />
          مميز
        </label>
        <button
          type="submit"
          disabled={creating}
          className="col-span-2 rounded-lg bg-gradient-to-r from-blue-600 to-neon-purpleBright px-4 py-2 font-bold text-white disabled:opacity-50 sm:col-span-1"
        >
          {creating ? "..." : "إضافة"}
        </button>
        {error && <p className="col-span-full text-sm text-red-400">{error}</p>}
      </form>

      <div className="flex flex-col gap-2">
        {numbers.map((n) => (
          <div
            key={n.id}
            className="flex flex-wrap items-center justify-between gap-3 rounded-xl border border-neon-border bg-neon-card p-4"
          >
            <div>
              <p className="font-semibold text-white">
                {n.country.flag} {n.phone}{" "}
                {n.featured && <span className="text-neon-purpleBright">★</span>}
              </p>
              <p className="text-xs text-neon-muted">
                {n.type} · {formatTikoun(n.price)}
              </p>
            </div>
            <div className="flex items-center gap-2">
              <select
                value={n.status}
                disabled={busyId === n.id}
                onChange={(e) => updateStatus(n.id, e.target.value)}
                className="rounded-lg border border-neon-border bg-neon-cardHover px-2 py-1 text-sm text-white outline-none"
              >
                {STATUSES.map((s) => (
                  <option key={s} value={s}>
                    {s}
                  </option>
                ))}
              </select>
              <button
                disabled={busyId === n.id}
                onClick={() => remove(n.id)}
                className="rounded-lg border border-red-500/40 px-3 py-1 text-sm text-red-400 disabled:opacity-50"
              >
                حذف
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
