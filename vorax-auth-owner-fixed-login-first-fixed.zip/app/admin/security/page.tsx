"use client";

import { useEffect, useState } from "react";

export default function AdminSecurityPage() {
  const [enabled, setEnabled] = useState<boolean | null>(null);
  const [secret, setSecret] = useState("");
  const [otpauth, setOtpauth] = useState("");
  const [otp, setOtp] = useState("");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  const [revokeUserId, setRevokeUserId] = useState("");
  const [revokeMsg, setRevokeMsg] = useState("");

  async function loadStatus() {
    const res = await fetch("/api/admin/security/2fa");
    const data = await res.json();
    if (res.ok) setEnabled(Boolean(data.twoFactorEnabled));
  }

  useEffect(() => {
    loadStatus();
  }, []);

  async function startSetup() {
    setBusy(true);
    setError("");
    try {
      const res = await fetch("/api/admin/security/2fa", { method: "POST" });
      const data = await res.json();
      if (!res.ok) {
        setError(data.error ?? "تعذر بدء الإعداد");
        return;
      }
      setSecret(data.secret);
      setOtpauth(data.otpauth);
    } finally {
      setBusy(false);
    }
  }

  async function confirmEnable() {
    setBusy(true);
    setError("");
    try {
      const res = await fetch("/api/admin/security/2fa", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ otp, enabled: true }),
      });
      const data = await res.json();
      if (!res.ok) {
        setError(data.error === "INVALID_2FA" ? "الرمز غير صحيح" : data.error ?? "خطأ");
        return;
      }
      setSecret("");
      setOtpauth("");
      setOtp("");
      await loadStatus();
    } finally {
      setBusy(false);
    }
  }

  async function disable2FA() {
    setBusy(true);
    setError("");
    try {
      const res = await fetch("/api/admin/security/2fa", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ otp, enabled: false }),
      });
      const data = await res.json();
      if (!res.ok) {
        setError(data.error === "INVALID_2FA" ? "الرمز غير صحيح" : data.error ?? "خطأ");
        return;
      }
      setOtp("");
      await loadStatus();
    } finally {
      setBusy(false);
    }
  }

  async function revokeSessions(e: React.FormEvent) {
    e.preventDefault();
    setRevokeMsg("");
    const res = await fetch("/api/admin/security/sessions/revoke-all", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ userId: revokeUserId }),
    });
    const data = await res.json();
    setRevokeMsg(res.ok ? "تم إبطال كل جلسات هذا المستخدم." : data.error ?? "خطأ");
  }

  return (
    <div dir="rtl" className="mx-auto max-w-2xl p-8">
      <h1 className="mb-6 text-2xl font-bold text-neon-purpleBright">🛡️ الأمان</h1>

      <section className="mb-8 rounded-xl border border-neon-border bg-neon-card p-5">
        <h2 className="mb-3 font-semibold text-white">التحقق بخطوتين (2FA) — Owner فقط</h2>
        {enabled === null ? (
          <p className="text-neon-muted">جارِ التحميل...</p>
        ) : enabled ? (
          <div>
            <p className="mb-3 text-sm text-emerald-400">مفعّل ✅</p>
            <div className="flex items-end gap-2">
              <input
                placeholder="رمز التحقق لإلغاء التفعيل"
                value={otp}
                onChange={(e) => setOtp(e.target.value)}
                className="rounded-lg border border-neon-border bg-neon-cardHover px-3 py-2 text-sm text-white outline-none focus:border-neon-purple"
              />
              <button
                disabled={busy || !otp}
                onClick={disable2FA}
                className="rounded-lg bg-red-900/60 px-4 py-2 text-sm text-red-300 disabled:opacity-50"
              >
                إلغاء التفعيل
              </button>
            </div>
          </div>
        ) : secret ? (
          <div className="flex flex-col gap-3">
            <p className="text-sm text-neon-muted">
              أضف هذا السر إلى تطبيق المصادقة (Google Authenticator أو مشابه):
            </p>
            <code className="break-all rounded-lg bg-neon-cardHover p-3 text-xs text-neon-purpleBright">{secret}</code>
            <p className="break-all text-xs text-neon-muted">{otpauth}</p>
            <div className="flex items-end gap-2">
              <input
                placeholder="رمز التحقق من التطبيق"
                value={otp}
                onChange={(e) => setOtp(e.target.value)}
                className="rounded-lg border border-neon-border bg-neon-cardHover px-3 py-2 text-sm text-white outline-none focus:border-neon-purple"
              />
              <button
                disabled={busy || !otp}
                onClick={confirmEnable}
                className="rounded-lg bg-emerald-600 px-4 py-2 text-sm font-bold text-white disabled:opacity-50"
              >
                تأكيد وتفعيل
              </button>
            </div>
          </div>
        ) : (
          <button
            disabled={busy}
            onClick={startSetup}
            className="rounded-lg bg-neon-purple px-4 py-2 text-sm font-bold text-white disabled:opacity-50"
          >
            بدء الإعداد
          </button>
        )}
        {error && <p className="mt-2 text-sm text-red-400">{error}</p>}
      </section>

      <section className="rounded-xl border border-neon-border bg-neon-card p-5">
        <h2 className="mb-3 font-semibold text-white">إبطال كل جلسات مستخدم</h2>
        <form onSubmit={revokeSessions} className="flex items-end gap-2">
          <input
            required
            placeholder="معرّف المستخدم (userId)"
            value={revokeUserId}
            onChange={(e) => setRevokeUserId(e.target.value)}
            className="flex-1 rounded-lg border border-neon-border bg-neon-cardHover px-3 py-2 text-sm text-white outline-none focus:border-neon-purple"
          />
          <button className="rounded-lg bg-red-900/60 px-4 py-2 text-sm text-red-300">إبطال الجلسات</button>
        </form>
        {revokeMsg && <p className="mt-2 text-sm text-neon-muted">{revokeMsg}</p>}
        <p className="mt-2 text-xs text-neon-muted">
          لا يوجد بعد بحث/قائمة مستخدمين هنا — انسخ الـ userId من صفحة المستخدمين.
        </p>
      </section>
    </div>
  );
}
