"use client";

import { useEffect, useState } from "react";
import { formatTikoun } from "@/lib/currency";

interface Analytics {
  sales: number;
  customers: number;
  merchants: number;
  developers: number;
  products: number;
  ordersActivity: number;
  aiActivity: number;
}

export default function AdminAnalyticsPage() {
  const [data, setData] = useState<Analytics | null>(null);
  const [error, setError] = useState("");

  useEffect(() => {
    (async () => {
      const res = await fetch("/api/admin/analytics");
      const d = await res.json();
      if (!res.ok) setError((d as any).error ?? "تعذر التحميل");
      else setData(d);
    })();
  }, []);

  return (
    <div dir="rtl" className="mx-auto max-w-3xl p-8">
      <h1 className="mb-6 text-2xl font-bold text-neon-purpleBright">📊 تحليلات المنصة</h1>
      {error && <p className="text-red-400">{error}</p>}
      {!data && !error && <p className="text-neon-muted">جارِ التحميل...</p>}
      {data && (
        <div className="grid grid-cols-2 gap-4 sm:grid-cols-3">
          <Stat label="إجمالي المبيعات" value={formatTikoun(data.sales)} />
          <Stat label="العملاء" value={String(data.customers)} />
          <Stat label="التجار" value={String(data.merchants)} />
          <Stat label="المطورون" value={String(data.developers)} />
          <Stat label="المنتجات" value={String(data.products)} />
          <Stat label="نشاط الطلبات" value={String(data.ordersActivity)} />
          <Stat label="نشاط الذكاء الاصطناعي" value={String(data.aiActivity)} />
        </div>
      )}
      <p className="mt-6 text-xs text-neon-muted">
        هذه تحليلات المنصة الكاملة — منفصلة عن تحليلات كل تاجر في لوحته الخاصة.
      </p>
    </div>
  );
}

function Stat({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-xl border border-neon-border bg-neon-card p-4">
      <p className="text-xs text-neon-muted">{label}</p>
      <p className="mt-1 text-xl font-bold text-white">{value}</p>
    </div>
  );
}
