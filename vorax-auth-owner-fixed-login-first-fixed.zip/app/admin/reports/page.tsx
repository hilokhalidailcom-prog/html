"use client";

import { useEffect, useState } from "react";

interface ReportRow {
  id: string;
  reason: string;
  status: "OPEN" | "REVIEWING" | "RESOLVED" | "REJECTED";
  resolutionNote: string | null;
  createdAt: string;
  number: { id: string; phone: string; status: string };
  reportedBy: { name: string; email: string };
}

const ACTIONS: { status: ReportRow["status"]; label: string }[] = [
  { status: "REVIEWING", label: "قيد المراجعة" },
  { status: "RESOLVED", label: "حل + تعليق المنتج" },
  { status: "REJECTED", label: "رفض البلاغ" },
];

export default function AdminReportsPage() {
  const [reports, setReports] = useState<ReportRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [busyId, setBusyId] = useState<string | null>(null);

  async function load() {
    setLoading(true);
    const res = await fetch("/api/admin/reports");
    const data = await res.json();
    if (!res.ok) setError((data as any).error ?? "تعذر تحميل البلاغات");
    else setReports(data);
    setLoading(false);
  }

  useEffect(() => {
    load();
  }, []);

  async function act(id: string, status: ReportRow["status"]) {
    setBusyId(id);
    try {
      const res = await fetch(`/api/admin/reports/${id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ status, suspendProduct: status === "RESOLVED" }),
      });
      if (res.ok) await load();
    } finally {
      setBusyId(null);
    }
  }

  return (
    <div dir="rtl" className="mx-auto max-w-4xl p-8">
      <h1 className="mb-6 text-2xl font-bold text-neon-purpleBright">🚩 بلاغات المنتجات</h1>

      {loading && <p className="text-neon-muted">جارِ التحميل...</p>}
      {error && <p className="text-red-400">{error}</p>}
      {!loading && !error && reports.length === 0 && (
        <p className="text-neon-muted">لا توجد بلاغات.</p>
      )}

      <div className="flex flex-col gap-3">
        {reports.map((r) => (
          <div key={r.id} className="rounded-xl border border-neon-border bg-neon-card p-4">
            <p className="font-bold text-white">{r.number.phone}</p>
            <p className="mt-1 text-sm text-neon-muted">{r.reason}</p>
            <p className="mt-1 text-xs text-neon-muted">
              بلّغ عنه: {r.reportedBy.name} · {new Date(r.createdAt).toLocaleDateString("ar-MA")}
            </p>
            <div className="mt-3 flex items-center gap-2">
              <span className="rounded-full bg-neon-cardHover px-3 py-1 text-xs text-neon-muted">
                {r.status}
              </span>
              {r.status === "OPEN" || r.status === "REVIEWING"
                ? ACTIONS.filter((a) => a.status !== r.status).map((a) => (
                    <button
                      key={a.status}
                      disabled={busyId === r.id}
                      onClick={() => act(r.id, a.status)}
                      className="rounded-lg bg-neon-purple px-3 py-1 text-xs font-bold text-white disabled:opacity-50"
                    >
                      {a.label}
                    </button>
                  ))
                : null}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
