"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { formatTikoun } from "@/lib/currency";

interface Stats {
  todaySalesTotal: number;
  todayOrderCount: number;
  totalWalletBalance: number;
  pendingTopUps: number;
  openTickets: number;
  topCountries: { name: string; count: number }[];
  recentOrders: {
    id: string;
    total: number;
    status: string;
    createdAt: string;
    customerName: string;
    items: { number: { phone: string; country: { name: string } } }[];
  }[];
}

const NAV = [
  { href: "/admin/merchants", label: "التجار" },
  { href: "/admin/numbers", label: "الأرقام" },
  { href: "/admin/orders", label: "الطلبات" },
  { href: "/admin/withdrawals", label: "السحوبات" },
  { href: "/admin/commissions", label: "العمولات" },
  { href: "/admin/reports", label: "البلاغات" },
  { href: "/admin/users", label: "المستخدمون" },
  { href: "/admin/developers", label: "المطورون" },
  { href: "/admin/dynamic", label: "المنصة الديناميكية" },
  { href: "/admin/analytics", label: "التحليلات" },
  { href: "/admin/security", label: "الأمان" },
  { href: "/admin/backups", label: "النسخ الاحتياطي" },
  { href: "/admin/topups", label: "طلبات الشحن" },
];

export default function AdminDashboardPage() {
  const [stats, setStats] = useState<Stats | null>(null);

  useEffect(() => {
    fetch("/api/admin/stats")
      .then((r) => r.json())
      .then(setStats);
  }, []);

  return (
    <div dir="rtl" className="mx-auto max-w-4xl p-8">
      <div className="mb-6 flex items-center justify-between">
        <h1 className="text-2xl font-bold text-neon-purpleBright">لوحة التحكم</h1>
      </div>

      <nav className="mb-8 flex flex-wrap gap-2 text-sm">
        {NAV.map((n) => (
          <Link
            key={n.href}
            href={n.href}
            className="rounded-full bg-neon-cardHover px-3 py-1 text-neon-muted hover:bg-neon-cardHover hover:text-neon-purpleBright"
          >
            {n.label}
          </Link>
        ))}
      </nav>

      {!stats ? (
        <p className="text-neon-muted">جارِ التحميل...</p>
      ) : (
        <>
          <div className="mb-8 grid grid-cols-2 gap-4 sm:grid-cols-4">
            <StatCard label="مبيعات اليوم" value={formatTikoun(stats.todaySalesTotal)} />
            <StatCard label="طلبات اليوم" value={String(stats.todayOrderCount)} />
            <StatCard label="رصيد تيكون الكلي بالمنصة" value={formatTikoun(stats.totalWalletBalance)} />
            <StatCard
              label="بانتظار المعالجة"
              value={`${stats.pendingTopUps} شحن · ${stats.openTickets} تذكرة`}
              alert={stats.pendingTopUps + stats.openTickets > 0}
            />
          </div>

          <div className="mb-8 rounded-xl border border-neon-border bg-neon-card p-5">
            <h2 className="mb-3 font-semibold text-white">أكثر الدول مطلوبة</h2>
            {stats.topCountries.length === 0 ? (
              <p className="text-sm text-neon-muted">لا توجد مبيعات بعد</p>
            ) : (
              <ul className="flex flex-col gap-2">
                {stats.topCountries.map((c) => (
                  <li key={c.name} className="flex items-center justify-between text-sm">
                    <span className="text-neon-muted">{c.name}</span>
                    <span className="font-bold text-neon-purpleBright">{c.count}</span>
                  </li>
                ))}
              </ul>
            )}
          </div>

          <div className="rounded-xl border border-neon-border bg-neon-card p-5">
            <h2 className="mb-3 font-semibold text-white">آخر الطلبات</h2>
            <div className="flex flex-col divide-y divide-neon-border">
              {stats.recentOrders.map((o) => (
                <div key={o.id} className="flex items-center justify-between py-2 text-sm">
                  <div>
                    <p className="text-neon-text">{o.customerName}</p>
                    <p className="text-xs text-neon-muted">
                      {o.items.map((i) => i.number.phone).join("، ")}
                    </p>
                  </div>
                  <span className="font-bold text-neon-purpleBright">{formatTikoun(o.total)}</span>
                </div>
              ))}
            </div>
          </div>
        </>
      )}
    </div>
  );
}

function StatCard({ label, value, alert }: { label: string; value: string; alert?: boolean }) {
  return (
    <div
      className={`rounded-xl border p-4 ${
        alert ? "border-neon-purple/40 bg-neon-purple/5" : "border-neon-border bg-neon-card"
      }`}
    >
      <p className="text-xs text-neon-muted">{label}</p>
      <p className="mt-1 text-lg font-bold text-white">{value}</p>
    </div>
  );
}
