"use client";

import { FormEvent, useEffect, useState } from "react";
import AppShell from "@/components/AppShell";
import { formatTikoun } from "@/lib/currency";

type TopUp = {
  id: string;
  amount: number;
  status: "PENDING" | "CONFIRMED" | "REJECTED";
  note: string | null;
  createdAt: string;
  resolvedAt?: string | null;
};

const statusText: Record<TopUp["status"], string> = {
  PENDING: "قيد المراجعة",
  CONFIRMED: "تم الشحن",
  REJECTED: "مرفوض",
};

export default function WalletPage() {
  const [balance, setBalance] = useState(0);
  const [topUps, setTopUps] = useState<TopUp[]>([]);
  const [amount, setAmount] = useState("");
  const [note, setNote] = useState("");
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [message, setMessage] = useState("");

  async function load() {
    setLoading(true);
    try {
      const res = await fetch("/api/wallet/topup-request", { cache: "no-store" });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "تعذر تحميل المحفظة");
      setBalance(data.balance ?? 0);
      setTopUps(data.topUps ?? []);
    } catch (e) {
      setMessage(e instanceof Error ? e.message : "حدث خطأ");
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => { load(); }, []);

  async function submit(e: FormEvent) {
    e.preventDefault();
    setMessage("");
    const value = Number(amount);
    if (!Number.isInteger(value) || value <= 0) {
      setMessage("اكتب مبلغًا صحيحًا بالأرقام.");
      return;
    }

    setSubmitting(true);
    try {
      const res = await fetch("/api/wallet/topup-request", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ amount: value, note: note.trim() || undefined }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "تعذر إنشاء الطلب");
      setAmount("");
      setNote("");
      setMessage("✅ تم إرسال طلب الشحن للمالك بنجاح. سيظهر لك الرصيد بعد الاعتماد.");
      await load();
    } catch (e) {
      setMessage(e instanceof Error ? e.message : "حدث خطأ");
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <AppShell>
      <div className="mx-auto max-w-4xl">
        <div className="mb-8">
          <p className="text-sm text-neon-purpleBright">VORAX WALLET</p>
          <h1 className="text-3xl font-black text-neon-text">المحفظة وشحن الرصيد</h1>
        </div>

        <section className="mb-6 rounded-2xl border border-neon-purple/30 bg-neon-purple/10 p-6">
          <p className="text-sm text-neon-muted">رصيدك الحالي</p>
          <p className="mt-2 text-4xl font-black text-neon-purpleBright">{formatTikoun(balance)}</p>
        </section>

        <section className="grid gap-6 md:grid-cols-2">
          <form onSubmit={submit} className="rounded-2xl border border-neon-border bg-neon-card p-6">
            <h2 className="mb-2 text-xl font-bold">💳 طلب شحن جديد</h2>
            <p className="mb-5 text-sm text-neon-muted">أنشئ الطلب من داخل المنصة، وبعد مراجعة المالك سيتم إضافة الرصيد تلقائيًا إلى محفظتك.</p>

            <label className="mb-2 block text-sm">المبلغ</label>
            <input
              inputMode="numeric"
              min="1"
              step="1"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              placeholder="مثال: 100"
              className="mb-4 w-full rounded-xl border border-neon-border bg-neon-bg p-3 outline-none focus:border-neon-purple"
            />

            <label className="mb-2 block text-sm">ملاحظة للمالك (اختياري)</label>
            <textarea
              value={note}
              onChange={(e) => setNote(e.target.value)}
              placeholder="اكتب أي معلومة تساعد المالك على مطابقة عملية الدفع"
              rows={4}
              className="mb-4 w-full rounded-xl border border-neon-border bg-neon-bg p-3 outline-none focus:border-neon-purple"
            />

            {message && <p className="mb-4 rounded-xl bg-neon-bg p-3 text-sm text-neon-purpleBright">{message}</p>}

            <button
              disabled={submitting}
              className="w-full rounded-xl bg-neon-purple px-5 py-3 font-bold text-white disabled:opacity-50"
            >
              {submitting ? "جارٍ إرسال الطلب…" : "إرسال طلب الشحن"}
            </button>
          </form>

          <section className="rounded-2xl border border-neon-border bg-neon-card p-6">
            <div className="mb-5 flex items-center justify-between">
              <h2 className="text-xl font-bold">📋 سجل الشحن</h2>
              <button onClick={load} className="text-sm text-neon-purpleBright">تحديث</button>
            </div>

            {loading ? (
              <p className="text-neon-muted">جارٍ التحميل…</p>
            ) : topUps.length === 0 ? (
              <p className="text-neon-muted">لا توجد طلبات شحن حتى الآن.</p>
            ) : (
              <div className="space-y-3">
                {topUps.map((t) => (
                  <div key={t.id} className="rounded-xl border border-neon-border bg-neon-bg p-4">
                    <div className="flex items-center justify-between gap-3">
                      <strong>{formatTikoun(t.amount)}</strong>
                      <span className={t.status === "CONFIRMED" ? "text-emerald-400" : t.status === "REJECTED" ? "text-red-400" : "text-amber-400"}>
                        {statusText[t.status]}
                      </span>
                    </div>
                    <p className="mt-2 text-xs text-neon-muted">{new Date(t.createdAt).toLocaleString("ar-MA")}</p>
                    {t.note && <p className="mt-2 text-sm text-neon-muted">{t.note}</p>}
                  </div>
                ))}
              </div>
            )}
          </section>
        </section>
      </div>
    </AppShell>
  );
}
