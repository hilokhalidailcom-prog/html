import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { publicNumberWhere } from "@/lib/marketplace";

const SIZE=24;
export async function GET(req:Request){
  const u=new URL(req.url); const q=u.searchParams.get("q")?.trim()||""; const country=u.searchParams.get("country"); const type=u.searchParams.get("type"); const category=u.searchParams.get("category"); const min=u.searchParams.get("minPrice"); const max=u.searchParams.get("maxPrice"); const rating=u.searchParams.get("rating"); const sort=u.searchParams.get("sort")||"newest"; const cursor=u.searchParams.get("cursor");
  const where:any=publicNumberWhere({
    ...(country?{country:{code:country}}:{}), ...(type?{type}:{}), ...(category?{category:{slug:category}}:{}),
    ...(min||max?{price:{...(min?{gte:Number(min)}:{}),...(max?{lte:Number(max)}:{})}}:{}),
    ...(q?{OR:[{phone:{contains:q}},{description:{contains:q,mode:"insensitive"}}]}:{}),
  });
  let orderBy:any; if(sort==="cheapest")orderBy={price:"asc"}; else if(sort==="expensive")orderBy={price:"desc"}; else if(sort==="featured")orderBy=[{featured:"desc"},{createdAt:"desc"}]; else orderBy=[{createdAt:"desc"},{id:"desc"}];
  const rows=await prisma.phoneNumber.findMany({where,include:{country:true,category:true,merchant:{select:{id:true,storeName:true,slug:true,verified:true}},reviews:{select:{rating:true}}},orderBy,take:SIZE+1,...(cursor?{cursor:{id:cursor},skip:1}:{})});
  let result=rows;
  if(rating){const minRating=Number(rating);result=result.filter(n=>{const a=n.reviews.length?n.reviews.reduce((s,r)=>s+r.rating,0)/n.reviews.length:0;return a>=minRating;});}
  if(sort==="rating")result.sort((a,b)=>((b.reviews.reduce((s,r)=>s+r.rating,0)/(b.reviews.length||1))-(a.reviews.reduce((s,r)=>s+r.rating,0)/(a.reviews.length||1))));
  const hasMore=result.length>SIZE; const page=result.slice(0,SIZE); return NextResponse.json({numbers:page.map(({reviews,...n})=>({...n,rating:reviews.length?reviews.reduce((s,r)=>s+r.rating,0)/reviews.length:0})),nextCursor:hasMore?page[page.length-1]?.id:null});
}
