import { NextResponse } from "next/server";
import { z } from "zod";
import { auth } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { reportError } from "@/lib/errorReporting";

const ReviewSchema = z.object({
  orderItemId: z.string(),
  rating: z.number().int().min(1).max(5),
  comment: z.string().max(500).optional(),
});

// GET /api/numbers/:id/reviews — public list + average, used on the
// product page and to feed the "موثوق" trust badge.
export async function GET(_req: Request, { params }: { params: { id: string } }) {
  const reviews = await prisma.review.findMany({
    where: { numberId: params.id },
    orderBy: { createdAt: "desc" },
    select: {
      id: true,
      rating: true,
      comment: true,
      createdAt: true,
      user: { select: { name: true } },
    },
  });

  const count = reviews.length;
  const average = count ? reviews.reduce((s, r) => s + r.rating, 0) / count : 0;

  return NextResponse.json({ reviews, average, count });
}

// POST /api/numbers/:id/reviews — only the buyer of that exact order item
// can review it, and only once (Review.orderItemId is unique).
export async function POST(req: Request, { params }: { params: { id: string } }) {
  const session = await auth();
  if (!session?.user) {
    return NextResponse.json({ error: "يجب تسجيل الدخول أولاً" }, { status: 401 });
  }
  const userId = (session.user as any).id as string;

  const body = await req.json().catch(() => null);
  const parsed = ReviewSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json({ error: parsed.error.issues[0].message }, { status: 400 });
  }
  const { orderItemId, rating, comment } = parsed.data;

  try {
    const orderItem = await prisma.orderItem.findUnique({
      where: { id: orderItemId },
      include: { order: true },
    });

    if (
      !orderItem ||
      orderItem.numberId !== params.id ||
      orderItem.order.userId !== userId ||
      orderItem.order.status !== "COMPLETED"
    ) {
      return NextResponse.json(
        { error: "ما قدرتيش تقيّم رقم ما شريتيهش أو ما كملاش الطلب بعد" },
        { status: 403 }
      );
    }

    const review = await prisma.review.create({
      data: { userId, numberId: params.id, orderItemId, rating, comment },
    });

    return NextResponse.json({ review }, { status: 201 });
  } catch (err: any) {
    if (err?.code === "P2002") {
      return NextResponse.json({ error: "سبق وقيّمتي هاذ الرقم" }, { status: 409 });
    }
    console.error("review create error:", err);
    reportError("reviews.create", err);
    return NextResponse.json({ error: "حدث خطأ، حاول مرة أخرى" }, { status: 500 });
  }
}
