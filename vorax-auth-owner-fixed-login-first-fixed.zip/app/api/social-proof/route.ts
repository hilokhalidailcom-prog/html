import { NextResponse } from "next/server";
import { getRecentPurchases } from "@/lib/stats";

export const dynamic = "force-dynamic";

export async function GET() {
  const purchases = await getRecentPurchases(10);
  return NextResponse.json({ purchases });
}
