import{NextResponse}from"next/server";import{releaseExpiredReservations}from"@/lib/reservations";
export const dynamic = "force-dynamic";
export async function GET(req:Request){const secret=process.env.CRON_SECRET;if(secret&&req.headers.get("authorization")!==`Bearer ${secret}`)return NextResponse.json({error:"Forbidden"},{status:403});const released=await releaseExpiredReservations();return NextResponse.json({released})}
