import { NextResponse } from "next/server";
import { z } from "zod";
import { Prisma } from "@prisma/client";
import { auth } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { reportError } from "@/lib/errorReporting";
import { validatePromoCode } from "@/lib/promo";
import { rewardReferralIfPending } from "@/lib/referral";
import { createNotification } from "@/lib/notifications";
import { recordBalanceTransaction } from "@/lib/finance";
import { releaseExpiredReservations } from "@/lib/reservations";
import { revalidateTag } from "next/cache";

const CheckoutSchema = z.object({
  numberIds: z.array(z.string()).min(1).max(50),
  customerName: z.string().min(2),
  customerPhone: z.string().min(6),
  customerEmail: z.string().email(),
  note: z.string().optional(),
  promoCode: z.string().optional(),
  reservationIds: z.array(z.string()).optional(),
});

export async function POST(req: Request) {
  const session = await auth();
  if (!session?.user) return NextResponse.json({ error: "يجب تسجيل الدخول أولاً" }, { status: 401 });
  const body = await req.json().catch(() => null);
  const parsed = CheckoutSchema.safeParse(body);
  if (!parsed.success) return NextResponse.json({ error: parsed.error.issues[0].message }, { status: 400 });
  const userId = (session.user as any).id as string;
  const idem = req.headers.get("Idempotency-Key")?.trim();

  try {
    await releaseExpiredReservations();
    const order = await prisma.$transaction(async (tx) => {
      if (idem) {
        const existing = await tx.idempotencyKey.findUnique({ where: { userId_key: { userId, key: idem } } });
        if (existing?.orderId) {
          const old = await tx.order.findUnique({ where: { id: existing.orderId }, include: { items: true } });
          if (old) return old;
        }
      }

      const reservations = await tx.reservation.findMany({
        where: { userId, numberId: { in: parsed.data.numberIds }, releasedAt: null, expiresAt: { gt: new Date() } },
      });
      const reservedIds = new Set(reservations.map(r => r.numberId));
      const numbers = await tx.phoneNumber.findMany({
        where: {
          id: { in: parsed.data.numberIds },
          approvalStatus: "APPROVED",
          OR: [{ status: "AVAILABLE" }, { status: "RESERVED", reservations: { some: { userId, releasedAt: null, expiresAt: { gt: new Date() } } } }],
        },
        include: { merchant: true },
      });
      if (numbers.length !== parsed.data.numberIds.length) throw new Error("SOME_NUMBERS_UNAVAILABLE");
      for (const n of numbers) if (n.status === "RESERVED" && !reservedIds.has(n.id)) throw new Error("RESERVATION_OWNER_MISMATCH");

      const subtotal = numbers.reduce((sum, n) => sum + n.price, 0);
      let discount = 0; let promoCodeId: string | null = null;
      if (parsed.data.promoCode) {
        const result = await validatePromoCode(parsed.data.promoCode, subtotal);
        if (!result.ok) throw new Error(`PROMO_${result.error}`);
        discount = result.discount; promoCodeId = result.promoCodeId;
      }
      const total = Math.max(0, subtotal - discount);
      const user = await tx.user.findUniqueOrThrow({ where: { id: userId } });
      if (user.balance < total) throw new Error("INSUFFICIENT_BALANCE");

      await tx.user.update({ where: { id: userId }, data: { balance: { decrement: total } } });
      await tx.balanceTransaction.create({ data: { userId, amount: -total, type: "ORDER_PAYMENT", description: "Order payment" } });

      await tx.phoneNumber.updateMany({
        where: { id: { in: parsed.data.numberIds }, status: { in: ["AVAILABLE", "RESERVED"] } },
        data: { status: "SOLD" },
      });
      await tx.reservation.updateMany({ where: { userId, numberId: { in: parsed.data.numberIds }, releasedAt: null }, data: { releasedAt: new Date() } });
      if (promoCodeId) await tx.promoCode.update({ where: { id: promoCodeId }, data: { usedCount: { increment: 1 } } });

      const created = await tx.order.create({
        data: {
          userId, total, discount, promoCodeId, status: "PROCESSING", paymentMethod: "WALLET",
          customerName: parsed.data.customerName, customerPhone: parsed.data.customerPhone,
          customerEmail: parsed.data.customerEmail, note: parsed.data.note,
          items: { create: numbers.map(n => {
            const pct = n.merchant?.commissionPercent ?? null;
            const merchantAmount = n.merchantId ? Math.floor(n.price * (100 - (pct ?? 0)) / 100) : null;
            return { numberId:n.id,price:n.price,merchantId:n.merchantId,merchantCommissionPercent:pct,merchantAmount,fulfillmentStatus:"PENDING" };
          })},
        }, include:{items:true},
      });
      if (idem) await tx.idempotencyKey.create({data:{userId,key:idem,orderId:created.id,response:{orderId:created.id}}});
      return created;
    }, { isolationLevel: Prisma.TransactionIsolationLevel.Serializable, maxWait: 10000, timeout: 15000 });

    // Build merchant ledger entries and notifications after payment.
    for (const item of order.items) {
      if (item.merchantId && item.merchantAmount != null) {
        await prisma.ledgerEntry.create({
          data:{merchantId:item.merchantId,orderItemId:item.id,type:"SALE",grossAmount:item.price,commissionAmount:item.price-item.merchantAmount,netAmount:item.merchantAmount,availableAt:null},
        }).catch(()=>{});
        const merchant=await prisma.merchant.findUnique({where:{id:item.merchantId},select:{userId:true}});
        if(merchant) await createNotification({userId:merchant.userId,title:"طلب جديد",body:`تم شراء رقم من متجرك بقيمة ${item.price} Tikoun`,type:"ORDER_CREATED",channels:["WEBSITE","EMAIL"]}).catch(()=>{});
      }
    }
    await rewardReferralIfPending(userId).catch((err) => reportError("referral.reward", err));
    revalidateTag("trust-stats"); revalidateTag("recent-purchases"); revalidateTag("numbers");
    return NextResponse.json({ order }, { status: 201 });
  } catch (err) {
    const message = err instanceof Error ? err.message : "UNKNOWN";
    if (message === "INSUFFICIENT_BALANCE") return NextResponse.json({error:"INSUFFICIENT_BALANCE",message:"أوووبس، ما عندكش رصيد كافي 😅",topUpUrl:"/wallet"},{status:402});
    if (message.startsWith("PROMO_")) return NextResponse.json({error:message.slice(6)},{status:400});
    if (message.includes("UNAVAILABLE") || message.includes("RESERVATION")) return NextResponse.json({error:"بعض الأرقام لم تعد متوفرة أو الحجز غير صالح"},{status:409});
    if ((err as any)?.code === "P2034") return NextResponse.json({error:"CONCURRENT_CHECKOUT_RETRY"},{status:409});
    reportError("checkout",err); return NextResponse.json({error:"حدث خطأ، حاول مرة أخرى"},{status:500});
  }
}
