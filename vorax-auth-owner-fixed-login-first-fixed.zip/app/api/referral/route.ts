import { NextResponse } from "next/server";
import { auth } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { getOrCreateReferralCode, REFERRAL_REWARD } from "@/lib/referral";

export async function GET() {
  const session = await auth();
  if (!session?.user) {
    return NextResponse.json({ error: "يجب تسجيل الدخول أولاً" }, { status: 401 });
  }
  const userId = (session.user as any).id as string;

  const referralCode = await getOrCreateReferralCode(userId);
  const uses = await prisma.referralUse.findMany({
    where: { referrerId: userId },
    select: { status: true, rewardAmount: true, createdAt: true },
    orderBy: { createdAt: "desc" },
  });

  const rewarded = uses.filter((u) => u.status === "REWARDED");
  const appUrl = process.env.NEXT_PUBLIC_APP_URL ?? "http://localhost:3000";

  return NextResponse.json({
    code: referralCode.code,
    shareUrl: `${appUrl}/register?ref=${referralCode.code}`,
    rewardPerReferral: REFERRAL_REWARD,
    totalReferred: uses.length,
    totalRewarded: rewarded.length,
    totalEarned: rewarded.reduce((s, u) => s + u.rewardAmount, 0),
  });
}
