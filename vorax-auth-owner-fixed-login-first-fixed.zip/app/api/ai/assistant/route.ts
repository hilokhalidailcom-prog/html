import { NextResponse } from "next/server";
import { auth } from "@/lib/auth";
import { marketplaceAssistant } from "@/lib/ai/assistant";
import { prisma } from "@/lib/prisma";
import { z } from "zod";

const Schema = z.object({
  message: z.string().min(1).max(2000),
  conversationId: z.string().optional(),
});

export async function POST(req: Request) {
  const session = await auth();
  const user = session?.user as any;
  const parsed = Schema.safeParse(await req.json().catch(() => null));
  if (!parsed.success) return NextResponse.json({ error: "Invalid message" }, { status: 400 });

  let conversation = parsed.data.conversationId && user?.id
    ? await prisma.aIConversation.findFirst({ where: { id: parsed.data.conversationId, userId: user.id } })
    : null;

  if (user?.id && !conversation) conversation = await prisma.aIConversation.create({ data: { userId: user.id } });

  try {
    const result = await marketplaceAssistant(parsed.data.message, user?.id, conversation?.id);

    if (conversation) {
      await prisma.aIMessage.create({
        data: { conversationId: conversation.id, role: "user", content: parsed.data.message },
      });
      for (const event of result.toolEvents ?? []) {
        await prisma.aIMessage.create({
          data: { conversationId: conversation.id, role: "tool", toolName: event.name, content: event.content.slice(0, 12000) },
        });
      }
      await prisma.aIMessage.create({
        data: { conversationId: conversation.id, role: "assistant", content: result.answer },
      });
    }

    return NextResponse.json({ ...result, conversationId: conversation?.id });
  } catch (error) {
    console.error("VORAX AI error", error);
    return NextResponse.json(
      { error: "AI_UNAVAILABLE", message: "تعذر تشغيل VORAX AI حاليًا. تحقق من إعداد مزود الذكاء الاصطناعي." },
      { status: 503 },
    );
  }
}
