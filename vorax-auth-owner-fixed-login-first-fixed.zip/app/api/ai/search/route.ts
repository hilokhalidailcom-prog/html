import { NextResponse } from "next/server";
import { auth } from "@/lib/auth";
import { marketplaceAssistant } from "@/lib/ai/assistant";

export async function POST(req: Request) {
  const body = await req.json().catch(() => null);
  if (!body?.message) return NextResponse.json({ error: "message required" }, { status: 400 });
  const session = await auth();
  const user = session?.user as any;
  try {
    return NextResponse.json(await marketplaceAssistant(String(body.message), user?.id));
  } catch {
    return NextResponse.json({ error: "AI_UNAVAILABLE" }, { status: 503 });
  }
}
