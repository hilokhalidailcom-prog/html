import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";

export async function GET() {
  const countries = await prisma.country.findMany({
    where: { active: true },
    include: {
      _count: { select: { numbers: { where: { status: "AVAILABLE" } } } },
      numbers: {
        where: { status: "AVAILABLE" },
        orderBy: { price: "asc" },
        take: 1,
        select: { price: true },
      },
    },
  });

  const result = countries
    .map((c) => ({
      id: c.id,
      code: c.code,
      name: c.name,
      flag: c.flag,
      available: c._count.numbers,
      fromPrice: c.numbers[0]?.price ?? null,
    }))
    .filter((c) => c.available > 0)
    .sort((a, b) => b.available - a.available)
    .slice(0, 6);

  return NextResponse.json({ countries: result });
}
