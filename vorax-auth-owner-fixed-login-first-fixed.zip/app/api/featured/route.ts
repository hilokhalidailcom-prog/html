import { NextResponse } from "next/server"; import { prisma } from "@/lib/prisma"; import { publicNumberWhere } from "@/lib/marketplace";
export const dynamic = "force-dynamic";
export async function GET(){const numbers=await prisma.phoneNumber.findMany({where:publicNumberWhere({featured:true}),include:{country:true,merchant:{select:{storeName:true,slug:true,verified:true}}},orderBy:{updatedAt:"desc"},take:30});return NextResponse.json({numbers});}
