import { NextResponse } from "next/server";
import { z } from "zod";
import { validatePromoCode } from "@/lib/promo";

const Schema = z.object({ code: z.string().min(1), subtotal: z.number().int().nonnegative() });

export async function POST(req: Request) {
  const body = await req.json().catch(() => null);
  const parsed = Schema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json({ error: "بيانات غير صحيحة" }, { status: 400 });
  }

  const result = await validatePromoCode(parsed.data.code, parsed.data.subtotal);
  if (!result.ok) {
    return NextResponse.json({ valid: false, error: result.error }, { status: 400 });
  }
  return NextResponse.json({ valid: true, discount: result.discount });
}
