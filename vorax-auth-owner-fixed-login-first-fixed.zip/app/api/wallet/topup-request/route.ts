import { NextResponse } from "next/server";
import { z } from "zod";
import { auth } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { checkRateLimit, getClientIp } from "@/lib/rateLimit";

const TopUpSchema = z.object({
  amount: z.number().int().positive().max(1_000_000),
  note: z.string().optional(),
});

// POST: user creates a top-up request from the VORAX platform.
// The owner reviews the payment and confirms/rejects it from /admin/topups.
export async function POST(req: Request) {
  const session = await auth();
  if (!session?.user) {
    return NextResponse.json({ error: "يجب تسجيل الدخول أولاً" }, { status: 401 });
  }

  const ip = getClientIp(req);
  const limit = checkRateLimit(`topup:${ip}`, 10, 60 * 60_000);
  if (!limit.allowed) {
    return NextResponse.json({ error: "محاولات كثيرة، حاول لاحقًا" }, { status: 429 });
  }

  const body = await req.json().catch(() => null);
  const parsed = TopUpSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json({ error: parsed.error.issues[0].message }, { status: 400 });
  }

  const userId = (session.user as any).id as string;
  const topUp = await prisma.topUpRequest.create({
    data: { userId, amount: parsed.data.amount, note: parsed.data.note, status: "PENDING" },
  });

  return NextResponse.json({ topUp }, { status: 201 });
}

export async function GET() {
  const session = await auth();
  if (!session?.user) {
    return NextResponse.json({ error: "يجب تسجيل الدخول أولاً" }, { status: 401 });
  }
  const userId = (session.user as any).id as string;
  const [user, topUps] = await Promise.all([
    prisma.user.findUnique({ where: { id: userId }, select: { balance: true } }),
    prisma.topUpRequest.findMany({
      where: { userId },
      orderBy: { createdAt: "desc" },
    }),
  ]);
  return NextResponse.json({ balance: user?.balance ?? 0, topUps });
}
