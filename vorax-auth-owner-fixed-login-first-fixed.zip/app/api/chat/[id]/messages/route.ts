import { NextResponse } from "next/server";
import { z } from "zod";
import { auth } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { canAccessChat, appendChatMessage } from "@/lib/chat";

const Schema = z.object({ content: z.string().trim().min(1).max(4000) });

export async function GET(_req: Request, { params }: { params: { id: string } }) {
  const session = await auth();
  const userId = (session?.user as any)?.id;
  if (!userId) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  const chat = await canAccessChat(userId, params.id);
  if (!chat) return NextResponse.json({ error: "المحادثة غير موجودة" }, { status: 404 });
  const messages = await prisma.merchantChatMessage.findMany({ where: { chatId: params.id }, orderBy: { createdAt: "asc" }, take: 200 });
  await prisma.merchantChatMessage.updateMany({ where: { chatId: params.id, senderUserId: { not: userId }, readAt: null }, data: { readAt: new Date() } });
  return NextResponse.json({ chat, messages });
}

export async function POST(req: Request, { params }: { params: { id: string } }) {
  const session = await auth();
  const userId = (session?.user as any)?.id;
  if (!userId) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  const chat = await canAccessChat(userId, params.id);
  if (!chat || chat.status === "CLOSED") return NextResponse.json({ error: "المحادثة مغلقة أو غير موجودة" }, { status: 403 });
  const parsed = Schema.safeParse(await req.json().catch(() => null));
  if (!parsed.success) return NextResponse.json({ error: "الرسالة غير صالحة" }, { status: 400 });
  const senderRole = chat.customerId === userId ? "CUSTOMER" : "MERCHANT";
  const message = await appendChatMessage(params.id, userId, parsed.data.content, senderRole);
  return NextResponse.json({ message }, { status: 201 });
}
