import { NextResponse } from "next/server";
import { z } from "zod";
import { auth } from "@/lib/auth";
import { prisma } from "@/lib/prisma";

const CreateSchema = z.object({ merchantId: z.string().min(1), orderId: z.string().optional(), numberId: z.string().optional() });

export async function GET() {
  const session = await auth();
  const userId = (session?.user as any)?.id;
  if (!userId) return NextResponse.json({ error: "يجب تسجيل الدخول" }, { status: 401 });
  const merchant = await prisma.merchant.findUnique({ where: { userId }, select: { id: true } });
  const where = merchant ? { OR: [{ customerId: userId }, { merchantId: merchant.id }] } : { customerId: userId };
  const chats = await prisma.merchantChat.findMany({
    where,
    include: { merchant: { select: { id: true, storeName: true, logoUrl: true } }, customer: { select: { id: true, name: true } } },
    orderBy: { lastMessageAt: "desc" },
  });
  return NextResponse.json({ chats });
}

export async function POST(req: Request) {
  const session = await auth();
  const userId = (session?.user as any)?.id;
  if (!userId) return NextResponse.json({ error: "يجب تسجيل الدخول" }, { status: 401 });
  const parsed = CreateSchema.safeParse(await req.json().catch(() => null));
  if (!parsed.success) return NextResponse.json({ error: "بيانات غير صالحة" }, { status: 400 });
  const merchant = await prisma.merchant.findUnique({ where: { id: parsed.data.merchantId, status: "ACTIVE" } });
  if (!merchant) return NextResponse.json({ error: "المتجر غير متاح" }, { status: 404 });
  if (merchant.userId === userId) return NextResponse.json({ error: "لا يمكنك فتح محادثة مع متجرك" }, { status: 400 });

  if (parsed.data.orderId) {
    const order = await prisma.order.findFirst({ where: { id: parsed.data.orderId, userId }, include: { items: { select: { merchantId: true, numberId: true } } } });
    if (!order || !order.items.some((i) => i.merchantId === merchant.id && (!parsed.data.numberId || i.numberId === parsed.data.numberId))) {
      return NextResponse.json({ error: "الطلب لا ينتمي لهذا المتجر" }, { status: 403 });
    }
  }

  const existing = await prisma.merchantChat.findFirst({ where: { customerId: userId, merchantId: merchant.id, orderId: parsed.data.orderId ?? null, numberId: parsed.data.numberId ?? null, status: "OPEN" } });
  const chat = existing ?? await prisma.merchantChat.create({ data: { customerId: userId, merchantId: merchant.id, orderId: parsed.data.orderId, numberId: parsed.data.numberId } });
  return NextResponse.json({ chat }, { status: existing ? 200 : 201 });
}
