import { NextResponse } from "next/server";
import bcrypt from "bcryptjs";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { checkRateLimit, getClientIp } from "@/lib/rateLimit";
import { generateToken, VERIFICATION_TTL_MS } from "@/lib/tokens";
import { sendEmail, verificationEmail } from "@/lib/email";
import { applyReferralCode } from "@/lib/referral";

const RegisterSchema = z.object({
  name: z.string().min(2, "الاسم قصير جدًا"),
  email: z.string().email("البريد الإلكتروني غير صحيح"),
  phone: z.string().optional(),
  password: z.string().min(8, "كلمة المرور يجب أن تكون 8 أحرف على الأقل"),
  referralCode: z.string().optional(),
});

export async function POST(req: Request) {
  const ip = getClientIp(req);

  // 5 registrations per hour per IP — stops scripted mass account creation.
  const limit = checkRateLimit(`register:${ip}`, 5, 60 * 60_000);
  if (!limit.allowed) {
    return NextResponse.json(
      { error: "محاولات كثيرة جدًا، حاول مرة أخرى بعد قليل" },
      { status: 429, headers: { "Retry-After": String(limit.retryAfterSeconds) } }
    );
  }

  const body = await req.json().catch(() => null);
  const parsed = RegisterSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json({ error: parsed.error.issues[0].message }, { status: 400 });
  }
  const { name, email, phone, password, referralCode } = parsed.data;

  const existing = await prisma.user.findUnique({ where: { email: email.toLowerCase() } });
  if (existing) {
    return NextResponse.json({ error: "البريد الإلكتروني مستخدم بالفعل" }, { status: 409 });
  }

  // 12 salt rounds — real, one-way hashing. The plaintext password is never stored.
  const passwordHash = await bcrypt.hash(password, 12);
  const { token, expires } = generateToken(VERIFICATION_TTL_MS);

  const user = await prisma.user.create({
    data: {
      name,
      email: email.toLowerCase(),
      phone,
      passwordHash,
      role: "USER",
      status: "ACTIVE",
      balance: 0,
      verificationToken: token,
      verificationExpires: expires,
    },
    select: { id: true, name: true, email: true, balance: true },
  });

  if (referralCode) {
    await applyReferralCode(user.id, referralCode).catch(() => {}); // never block signup
  }

  const appUrl = process.env.NEXT_PUBLIC_APP_URL ?? "http://localhost:3000";
  const link = `${appUrl}/api/auth/verify-email?token=${token}`;
  await sendEmail({
    to: user.email,
    subject: "أكّد بريدك الإلكتروني - VORAX",
    html: verificationEmail(link),
  });

  return NextResponse.json(
    { user, message: "تم إنشاء الحساب، تحقق من بريدك الإلكتروني لتفعيله" },
    { status: 201 }
  );
}
