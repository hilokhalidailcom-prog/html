import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";

export async function GET(req: Request) {
  const url = new URL(req.url);
  const token = url.searchParams.get("token");
  const appUrl = process.env.NEXT_PUBLIC_APP_URL ?? "http://localhost:3000";

  if (!token) {
    return NextResponse.redirect(`${appUrl}/login?verify=missing`);
  }

  const user = await prisma.user.findUnique({ where: { verificationToken: token } });

  if (!user || !user.verificationExpires || user.verificationExpires < new Date()) {
    return NextResponse.redirect(`${appUrl}/login?verify=invalid`);
  }

  await prisma.user.update({
    where: { id: user.id },
    data: { emailVerified: new Date(), verificationToken: null, verificationExpires: null },
  });

  return NextResponse.redirect(`${appUrl}/login?verify=success`);
}
