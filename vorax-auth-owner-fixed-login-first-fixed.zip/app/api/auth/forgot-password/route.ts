import { NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { generateToken, RESET_TTL_MS } from "@/lib/tokens";
import { sendEmail, resetPasswordEmail } from "@/lib/email";
import { checkRateLimit, getClientIp } from "@/lib/rateLimit";

const Schema = z.object({ email: z.string().email() });

export async function POST(req: Request) {
  const ip = getClientIp(req);
  const limit = checkRateLimit(`forgot:${ip}`, 5, 60 * 60_000);
  if (!limit.allowed) {
    return NextResponse.json({ error: "محاولات كثيرة، حاول لاحقًا" }, { status: 429 });
  }

  const body = await req.json().catch(() => null);
  const parsed = Schema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json({ error: "بريد إلكتروني غير صحيح" }, { status: 400 });
  }

  const email = parsed.data.email.toLowerCase();
  const user = await prisma.user.findUnique({ where: { email } });

  // Always return the same success response whether or not the email
  // exists — prevents attackers from using this endpoint to enumerate
  // registered accounts.
  if (user) {
    const { token, expires } = generateToken(RESET_TTL_MS);
    await prisma.user.update({
      where: { id: user.id },
      data: { resetToken: token, resetExpires: expires },
    });

    const appUrl = process.env.NEXT_PUBLIC_APP_URL ?? "http://localhost:3000";
    const link = `${appUrl}/reset-password?token=${token}`;
    await sendEmail({
      to: user.email,
      subject: "إعادة تعيين كلمة المرور - VORAX",
      html: resetPasswordEmail(link),
    });
  }

  return NextResponse.json({
    message: "إذا كان البريد الإلكتروني مسجلاً، ستصلك رسالة لإعادة تعيين كلمة المرور",
  });
}
