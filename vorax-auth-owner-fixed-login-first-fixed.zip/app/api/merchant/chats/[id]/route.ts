import { NextResponse } from "next/server";
import { auth } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { getOwnMerchant } from "@/lib/permissions";

export async function PATCH(req: Request, { params }: { params: { id: string } }) {
  const session = await auth();
  const userId = (session?.user as any)?.id;
  if (!userId) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  const merchant = await getOwnMerchant(userId);
  if (!merchant) return NextResponse.json({ error: "لا يوجد متجر" }, { status: 404 });
  const body = await req.json().catch(() => null);
  const status = body?.status === "CLOSED" ? "CLOSED" : body?.status === "OPEN" ? "OPEN" : null;
  if (!status) return NextResponse.json({ error: "status غير صالح" }, { status: 400 });
  const chat = await prisma.merchantChat.updateMany({ where: { id: params.id, merchantId: merchant.id }, data: { status } });
  if (!chat.count) return NextResponse.json({ error: "المحادثة غير موجودة" }, { status: 404 });
  return NextResponse.json({ ok: true });
}
