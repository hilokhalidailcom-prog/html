import { NextResponse } from "next/server";
import { auth } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { getOwnMerchant } from "@/lib/permissions";

export async function GET() {
  const session = await auth();
  const userId = (session?.user as any)?.id;
  if (!userId) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  const merchant = await getOwnMerchant(userId);
  if (!merchant) return NextResponse.json({ error: "لا يوجد متجر" }, { status: 404 });
  const chats = await prisma.merchantChat.findMany({
    where: { merchantId: merchant.id },
    include: { customer: { select: { id: true, name: true, phone: true } }, order: { select: { id: true, status: true } } },
    orderBy: { lastMessageAt: "desc" },
  });
  return NextResponse.json({ chats });
}
