import { NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { auth } from "@/lib/auth";
import { getOwnMerchant, logActivity } from "@/lib/permissions";

// Coarse "is this a MERCHANT-role account" gate already enforced by
// middleware for /api/merchant/*. This route additionally scopes every
// query to `userId = session.user.id` — a merchant can never read or
// write another merchant's store this way, no matter what id they try to
// pass, because we never accept an id from the request at all.

export async function GET() {
  const session = await auth();
  const userId = (session?.user as any)?.id;
  if (!userId) return NextResponse.json({ error: "غير مسجل الدخول" }, { status: 401 });

  const merchant = await getOwnMerchant(userId);
  if (!merchant) {
    return NextResponse.json({ error: "لا يوجد متجر مرتبط بحسابك" }, { status: 404 });
  }

  return NextResponse.json({ merchant });
}

// Self-editable fields only. storeName changes and commissionPercent/
// status/verified are deliberately excluded — those need an owner or a
// developer holding the right permission (spec §41: "بعض التعديلات
// يمكن أن تحتاج موافقة الإدارة").
const SelfUpdateSchema = z.object({
  description: z.string().max(1000).nullable().optional(),
  logoUrl: z.string().url().nullable().optional(),
  contactInfo: z.string().max(200).nullable().optional(),
});

export async function PATCH(req: Request) {
  const session = await auth();
  const userId = (session?.user as any)?.id;
  if (!userId) return NextResponse.json({ error: "غير مسجل الدخول" }, { status: 401 });

  const existing = await getOwnMerchant(userId);
  if (!existing) {
    return NextResponse.json({ error: "لا يوجد متجر مرتبط بحسابك" }, { status: 404 });
  }

  const body = await req.json().catch(() => null);
  const parsed = SelfUpdateSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json({ error: parsed.error.issues[0].message }, { status: 400 });
  }

  const merchant = await prisma.merchant.update({
    where: { userId }, // scoped by session, never by a client-supplied id
    data: parsed.data,
  });

  await logActivity({
    actorId: userId,
    actorRole: "MERCHANT" as any,
    action: "merchant.self_update",
    targetType: "Merchant",
    targetId: merchant.id,
    meta: parsed.data,
  });

  return NextResponse.json({ merchant });
}
