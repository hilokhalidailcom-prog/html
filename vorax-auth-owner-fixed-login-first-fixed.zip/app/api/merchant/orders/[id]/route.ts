import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { auth } from "@/lib/auth";
import { getOwnMerchant } from "@/lib/permissions";

function maskPhone(phone: string): string {
  if (phone.length <= 4) return phone;
  return `${"*".repeat(phone.length - 4)}${phone.slice(-4)}`;
}

// :id here is an OrderItem id, not an Order id — a merchant opens "their"
// line from the list, never the whole order (which may include other
// merchants' items). Scoped by merchantId, same 404-for-both-cases pattern
// as /api/merchant/products/[id].
export async function GET(_req: Request, { params }: { params: { id: string } }) {
  const session = await auth();
  const userId = (session?.user as any)?.id;
  if (!userId) return NextResponse.json({ error: "غير مسجل الدخول" }, { status: 401 });

  const merchant = await getOwnMerchant(userId);
  if (!merchant) {
    return NextResponse.json({ error: "لا يوجد متجر مرتبط بحسابك" }, { status: 404 });
  }

  const item = await prisma.orderItem.findFirst({
    where: { id: params.id, merchantId: merchant.id },
    include: {
      number: { select: { phone: true, type: true, countryId: true } },
      order: {
        select: { id: true, status: true, createdAt: true, customerName: true, customerPhone: true, note: true },
      },
    },
  });
  if (!item) {
    return NextResponse.json({ error: "الطلب غير موجود" }, { status: 404 });
  }

  return NextResponse.json({
    order: {
      orderItemId: item.id,
      orderId: item.orderId,
      product: { phone: item.number.phone, type: item.number.type },
      customer: { name: item.order.customerName, phone: maskPhone(item.order.customerPhone) },
      note: item.order.note,
      amount: item.price,
      commissionPercent: item.merchantCommissionPercent,
      merchantAmount: item.merchantAmount,
      status: item.order.status,
      date: item.order.createdAt,
    },
  });
}
