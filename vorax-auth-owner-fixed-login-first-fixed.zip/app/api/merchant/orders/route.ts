import { NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { auth } from "@/lib/auth";
import { getOwnMerchant } from "@/lib/permissions";

// MERCHANT-role gate already enforced by middleware for /api/merchant/*.
// Scoped by `merchantId = OrderItem.merchantId = <caller's own merchant>`
// — an order can contain items from several different merchants (a
// customer can buy numbers from different stores in one checkout), so we
// list OrderItems, not whole Orders, and each merchant only ever sees
// their own line items even from a shared order.

const ListQuerySchema = z.object({
  status: z.enum(["PENDING", "PROCESSING", "COMPLETED", "CANCELLED"]).optional(),
  page: z.coerce.number().int().min(1).default(1),
  pageSize: z.coerce.number().int().min(1).max(100).default(20),
});

// Mask a phone number down to the last 4 digits — a merchant needs enough
// to recognize repeat customers or reference a support ticket, not the
// full contact number (spec §4: "لا تكشف بيانات العميل غير الضرورية").
function maskPhone(phone: string): string {
  if (phone.length <= 4) return phone;
  return `${"*".repeat(phone.length - 4)}${phone.slice(-4)}`;
}

export async function GET(req: Request) {
  const session = await auth();
  const userId = (session?.user as any)?.id;
  if (!userId) return NextResponse.json({ error: "غير مسجل الدخول" }, { status: 401 });

  const merchant = await getOwnMerchant(userId);
  if (!merchant) {
    return NextResponse.json({ error: "لا يوجد متجر مرتبط بحسابك" }, { status: 404 });
  }

  const url = new URL(req.url);
  const parsed = ListQuerySchema.safeParse(Object.fromEntries(url.searchParams));
  if (!parsed.success) {
    return NextResponse.json({ error: parsed.error.issues[0].message }, { status: 400 });
  }
  const { status, page, pageSize } = parsed.data;

  const where = {
    merchantId: merchant.id,
    ...(status ? { order: { status } } : {}),
  };

  const [items, total] = await Promise.all([
    prisma.orderItem.findMany({
      where,
      include: {
        number: { select: { phone: true, type: true } },
        order: { select: { id: true, status: true, createdAt: true, customerName: true, customerPhone: true } },
      },
      orderBy: { order: { createdAt: "desc" } },
      skip: (page - 1) * pageSize,
      take: pageSize,
    }),
    prisma.orderItem.count({ where }),
  ]);

  const orders = items.map((item) => ({
    orderItemId: item.id,
    orderId: item.orderId,
    product: { phone: item.number.phone, type: item.number.type },
    customer: {
      name: item.order.customerName,
      phone: maskPhone(item.order.customerPhone),
    },
    amount: item.price,
    commissionPercent: item.merchantCommissionPercent,
    merchantAmount: item.merchantAmount,
    status: item.order.status,
    date: item.order.createdAt,
  }));

  return NextResponse.json({ orders, total, page, pageSize });
}
