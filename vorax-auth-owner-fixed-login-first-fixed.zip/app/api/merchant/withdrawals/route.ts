import { NextResponse } from "next/server";
import { auth } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { getOwnMerchant, logActivity } from "@/lib/permissions";
import { merchantLedgerSummary } from "@/lib/finance";
import { z } from "zod";

const Schema=z.object({amount:z.number().int().positive(),note:z.string().max(500).optional()});
export async function GET(){const s=await auth();if(!s?.user)return NextResponse.json({error:"Unauthorized"},{status:401});const m=await getOwnMerchant((s.user as any).id);if(!m)return NextResponse.json({error:"Merchant not found"},{status:404});return NextResponse.json(await prisma.withdrawalRequest.findMany({where:{merchantId:m.id},orderBy:{createdAt:"desc"}}))}
export async function POST(req:Request){const s=await auth();if(!s?.user)return NextResponse.json({error:"Unauthorized"},{status:401});const m=await getOwnMerchant((s.user as any).id);if(!m)return NextResponse.json({error:"Merchant not found"},{status:404});const p=Schema.safeParse(await req.json().catch(()=>null));if(!p.success)return NextResponse.json({error:p.error.issues[0].message},{status:400});const sum=await merchantLedgerSummary(m.id);if(p.data.amount>sum.available)return NextResponse.json({error:"INSUFFICIENT_AVAILABLE_BALANCE"},{status:409});const w=await prisma.withdrawalRequest.create({data:{merchantId:m.id,userId:(s.user as any).id,amount:p.data.amount,note:p.data.note}});await logActivity({actorId:(s.user as any).id,actorRole:"MERCHANT",action:"withdrawal.request",targetType:"WithdrawalRequest",targetId:w.id,meta:{amount:w.amount}});return NextResponse.json(w,{status:201})}
