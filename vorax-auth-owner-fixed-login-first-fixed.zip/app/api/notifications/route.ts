import{NextResponse}from"next/server";import{auth}from"@/lib/auth";import{prisma}from"@/lib/prisma";
export async function GET(){const s=await auth();if(!s?.user)return NextResponse.json({error:"Unauthorized"},{status:401});return NextResponse.json(await prisma.notification.findMany({where:{userId:(s.user as any).id},include:{deliveries:true},orderBy:{createdAt:"desc"},take:100}))}
