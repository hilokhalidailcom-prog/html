import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";

export const dynamic = "force-dynamic";

// Auth + admin-role check already enforced by middleware for /api/admin/*.
export async function GET() {
  const countries = await prisma.country.findMany({ orderBy: { name: "asc" } });
  return NextResponse.json({ countries });
}
