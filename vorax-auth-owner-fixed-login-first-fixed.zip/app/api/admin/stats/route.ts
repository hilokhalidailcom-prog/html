import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";

export const dynamic = "force-dynamic";

// Auth + admin-role check already enforced by middleware for /api/admin/*.
export async function GET() {
  const startOfDay = new Date();
  startOfDay.setHours(0, 0, 0, 0);

  const [todayOrders, totalBalanceAgg, pendingTopUps, openTickets, recentOrders] =
    await Promise.all([
      prisma.order.findMany({
        where: { createdAt: { gte: startOfDay }, status: { in: ["PROCESSING", "COMPLETED"] } },
        select: { total: true },
      }),
      prisma.user.aggregate({ _sum: { balance: true } }),
      prisma.topUpRequest.count({ where: { status: "PENDING" } }),
      prisma.supportTicket.count({ where: { status: { in: ["OPEN", "IN_PROGRESS"] } } }),
      prisma.order.findMany({
        where: { status: { in: ["PROCESSING", "COMPLETED"] } },
        orderBy: { createdAt: "desc" },
        take: 8,
        select: {
          id: true,
          total: true,
          status: true,
          createdAt: true,
          customerName: true,
          items: { select: { number: { select: { phone: true, country: { select: { name: true } } } } } },
        },
      }),
    ]);

  // groupBy on numberId isn't directly useful (one row per number) —
  // instead pull country per number sold and tally in JS. Simpler and
  // fast enough at this data volume; move to a real SQL groupBy on
  // countryId via a raw query if the catalog grows into the tens of
  // thousands of orders.
  const soldNumbers = await prisma.orderItem.findMany({
    where: { order: { status: { in: ["PROCESSING", "COMPLETED"] } } },
    select: { number: { select: { country: { select: { name: true } } } } },
  });
  const countryTally = new Map<string, number>();
  for (const item of soldNumbers) {
    const name = item.number.country.name;
    countryTally.set(name, (countryTally.get(name) ?? 0) + 1);
  }
  const topCountries = [...countryTally.entries()]
    .sort((a, b) => b[1] - a[1])
    .slice(0, 5)
    .map(([name, count]) => ({ name, count }));

  return NextResponse.json({
    todaySalesTotal: todayOrders.reduce((s, o) => s + o.total, 0),
    todayOrderCount: todayOrders.length,
    totalWalletBalance: totalBalanceAgg._sum.balance ?? 0,
    pendingTopUps,
    openTickets,
    topCountries,
    recentOrders,
  });
}
