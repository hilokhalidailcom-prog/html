import { NextResponse } from "next/server";
import { z } from "zod";
import { revalidateTag } from "next/cache";
import { prisma } from "@/lib/prisma";

// Auth + admin-role check already enforced by middleware for /api/admin/*.

// GET /api/admin/numbers — every number regardless of status, for the
// admin table (unlike /api/numbers which only shows AVAILABLE ones).
export async function GET() {
  const numbers = await prisma.phoneNumber.findMany({
    include: { country: true },
    orderBy: { createdAt: "desc" },
    take: 500,
  });
  return NextResponse.json({ numbers });
}

const CreateSchema = z.object({
  phone: z.string().min(4),
  countryId: z.string(),
  type: z.enum(["NORMAL", "VIP", "REPEATED", "EASY", "INTERNATIONAL", "VIRTUAL"]),
  price: z.number().int().positive(),
  description: z.string().optional(),
  featured: z.boolean().optional(),
});

export async function POST(req: Request) {
  const body = await req.json().catch(() => null);
  const parsed = CreateSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json({ error: parsed.error.issues[0].message }, { status: 400 });
  }

  const number = await prisma.phoneNumber.create({ data: parsed.data, include: { country: true } });
  revalidateTag("numbers"); // invalidate the cached public listing so it shows up right away
  return NextResponse.json({ number }, { status: 201 });
}
