import { NextResponse } from "next/server";
import { z } from "zod";
import { revalidateTag } from "next/cache";
import { prisma } from "@/lib/prisma";

// Auth + admin-role check already enforced by middleware for /api/admin/*.

const UpdateSchema = z.object({
  phone: z.string().min(4).optional(),
  countryId: z.string().optional(),
  type: z.enum(["NORMAL", "VIP", "REPEATED", "EASY", "INTERNATIONAL", "VIRTUAL"]).optional(),
  price: z.number().int().positive().optional(),
  description: z.string().nullable().optional(),
  featured: z.boolean().optional(),
  status: z.enum(["AVAILABLE", "RESERVED", "SOLD", "HIDDEN"]).optional(),
});

export async function PATCH(req: Request, { params }: { params: { id: string } }) {
  const body = await req.json().catch(() => null);
  const parsed = UpdateSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json({ error: parsed.error.issues[0].message }, { status: 400 });
  }

  const number = await prisma.phoneNumber
    .update({ where: { id: params.id }, data: parsed.data, include: { country: true } })
    .catch(() => null);

  if (!number) {
    return NextResponse.json({ error: "الرقم غير موجود" }, { status: 404 });
  }

  revalidateTag("numbers");
  return NextResponse.json({ number });
}

export async function DELETE(_req: Request, { params }: { params: { id: string } }) {
  // Numbers referenced by an existing order can't be hard-deleted (FK
  // constraint) — hide them instead so order history stays intact.
  const hasOrders = await prisma.orderItem.findFirst({ where: { numberId: params.id } });
  if (hasOrders) {
    await prisma.phoneNumber.update({ where: { id: params.id }, data: { status: "HIDDEN" } });
    revalidateTag("numbers");
    return NextResponse.json({ hidden: true });
  }

  await prisma.phoneNumber.delete({ where: { id: params.id } }).catch(() => null);
  revalidateTag("numbers");
  return NextResponse.json({ deleted: true });
}
