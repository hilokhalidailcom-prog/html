import { NextResponse } from "next/server";
import { z } from "zod";
import { auth } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { hasPermission, logActivity } from "@/lib/permissions";

const Body = z.object({ status: z.enum(["APPROVED", "REJECTED"]), rejectionReason: z.string().max(1000).optional() });
export async function PATCH(req: Request, { params }: { params: { merchantId: string; id: string } }) {
  const session = await auth(); const u:any = session?.user;
  if (!u) return NextResponse.json({error:"غير مسجل الدخول"},{status:401});
  if (!hasPermission(u, "product.review")) return NextResponse.json({error:"لا تملك الصلاحية"},{status:403});
  const body = Body.safeParse(await req.json().catch(()=>null));
  if (!body.success) return NextResponse.json({error:body.error.issues[0].message},{status:400});
  if (body.data.status === "REJECTED" && !body.data.rejectionReason?.trim()) return NextResponse.json({error:"سبب الرفض مطلوب"},{status:400});
  const product = await prisma.phoneNumber.findFirst({where:{id:params.id,merchantId:params.merchantId}});
  if (!product) return NextResponse.json({error:"المنتج غير موجود"},{status:404});
  const updated = await prisma.phoneNumber.update({where:{id:product.id},data:{approvalStatus:body.data.status,rejectionReason:body.data.status === "REJECTED" ? body.data.rejectionReason : null}});
  await logActivity({actorId:u.id,actorRole:u.role,action:`product.${body.data.status.toLowerCase()}`,targetType:"PhoneNumber",targetId:updated.id,meta:{merchantId:params.merchantId,rejectionReason:body.data.rejectionReason}});
  const merchant = await prisma.merchant.findUnique({where:{id:params.merchantId}});
  if (merchant) await prisma.notification.create({data:{userId:merchant.userId,title:body.data.status === "APPROVED" ? "تم قبول الرقم" : "تم رفض الرقم",body:body.data.status === "APPROVED" ? "تمت الموافقة على رقمك وأصبح مؤهلًا للعرض." : `تم رفض الرقم: ${body.data.rejectionReason}`,type:`PRODUCT_${body.data.status}`,metadata:{numberId:updated.id}}});
  return NextResponse.json({product:updated});
}
