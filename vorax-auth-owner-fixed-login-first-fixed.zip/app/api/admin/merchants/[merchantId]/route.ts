import { NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { auth } from "@/lib/auth";
import { hasPermission, requirePermission, logActivity, MerchantPermission } from "@/lib/permissions";

// Coarse "is this staff at all" gate already enforced by middleware for
// /api/admin/*. Below we pick the specific permission per action, since a
// developer might be allowed to approve merchants but not suspend them.

export async function GET(_req: Request, { params }: { params: { merchantId: string } }) {
  const session = await auth();
  const denied = await requirePermission(session?.user as any, "merchant.view");
  if (denied) return NextResponse.json(denied.body, { status: denied.status });

  const merchant = await prisma.merchant.findUnique({
    where: { id: params.merchantId },
    include: { user: { select: { id: true, name: true, email: true, status: true } } },
  });
  if (!merchant) return NextResponse.json({ error: "التاجر غير موجود" }, { status: 404 });

  return NextResponse.json({ merchant });
}

const UpdateSchema = z.object({
  storeName: z.string().min(2).max(80).optional(),
  description: z.string().max(1000).nullable().optional(),
  country: z.string().max(60).nullable().optional(),
  contactInfo: z.string().max(200).nullable().optional(),
  commissionPercent: z.number().int().min(0).max(100).optional(),
  status: z.enum(["PENDING", "ACTIVE", "SUSPENDED", "CLOSED"]).optional(),
  verified: z.boolean().optional(),
});

// Every field in the body maps to the permission required to change it —
// this is the "protect it in the backend, not just hide the button" rule
// from spec §51 applied per-field, not just per-route.
const FIELD_PERMISSION: Record<string, MerchantPermission> = {
  storeName: "merchant.edit",
  description: "merchant.edit",
  country: "merchant.edit",
  contactInfo: "merchant.edit",
  commissionPercent: "merchant.commissions",
  status: "merchant.suspend",
  verified: "merchant.approve",
};

export async function PATCH(req: Request, { params }: { params: { merchantId: string } }) {
  const session = await auth();
  const user = session?.user as any;

  const body = await req.json().catch(() => null);
  const parsed = UpdateSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json({ error: parsed.error.issues[0].message }, { status: 400 });
  }

  const fields = Object.keys(parsed.data);
  if (fields.length === 0) {
    return NextResponse.json({ error: "لا يوجد شيء لتعديله" }, { status: 400 });
  }

  for (const field of fields) {
    const perm = FIELD_PERMISSION[field];
    if (perm && !hasPermission(user, perm)) {
      return NextResponse.json(
        { error: `لا تملك صلاحية "${perm}" اللازمة لتعديل هذا الحقل` },
        { status: 403 }
      );
    }
  }

  const merchant = await prisma.merchant
    .update({ where: { id: params.merchantId }, data: parsed.data })
    .catch(() => null);

  if (!merchant) return NextResponse.json({ error: "التاجر غير موجود" }, { status: 404 });

  await logActivity({
    actorId: user?.id,
    actorRole: user?.role,
    action: "merchant.update",
    targetType: "Merchant",
    targetId: merchant.id,
    meta: parsed.data,
  });

  return NextResponse.json({ merchant });
}

// Archiving a merchant: per spec this is "حذف/أرشفة" (delete/archive) — we
// never hard-delete (their order/product history must survive), only set
// status to CLOSED. Requires merchant.suspend since it's the same
// "can shut this store down" authority.
export async function DELETE(_req: Request, { params }: { params: { merchantId: string } }) {
  const session = await auth();
  const denied = await requirePermission(session?.user as any, "merchant.suspend");
  if (denied) return NextResponse.json(denied.body, { status: denied.status });

  const merchant = await prisma.merchant
    .update({ where: { id: params.merchantId }, data: { status: "CLOSED" } })
    .catch(() => null);

  if (!merchant) return NextResponse.json({ error: "التاجر غير موجود" }, { status: 404 });

  await logActivity({
    actorId: (session?.user as any)?.id,
    actorRole: (session?.user as any)?.role,
    action: "merchant.archive",
    targetType: "Merchant",
    targetId: merchant.id,
  });

  return NextResponse.json({ archived: true, merchant });
}
