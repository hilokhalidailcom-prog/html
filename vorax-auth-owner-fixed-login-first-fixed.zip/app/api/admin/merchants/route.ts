import { NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { auth } from "@/lib/auth";
import { requirePermission, logActivity } from "@/lib/permissions";

// Coarse "is this staff at all" gate already enforced by middleware for
// /api/admin/*. This route additionally requires the specific
// "merchant.view" / "merchant.create" permission — an owner always has it,
// a developer only if it was granted to them.

export async function GET() {
  const session = await auth();
  const denied = await requirePermission(session?.user as any, "merchant.view");
  if (denied) return NextResponse.json(denied.body, { status: denied.status });

  const merchants = await prisma.merchant.findMany({
    include: { user: { select: { id: true, name: true, email: true, status: true } } },
    orderBy: { createdAt: "desc" },
    take: 500,
  });

  return NextResponse.json({ merchants });
}

const CreateSchema = z.object({
  // The customer account this merchant store belongs to, identified by
  // email since that's what an owner/developer actually has on hand after
  // being contacted by the person — not their internal user id.
  userEmail: z.string().email(),
  storeName: z.string().min(2).max(80),
  slug: z
    .string()
    .min(2)
    .max(60)
    .regex(/^[a-z0-9-]+$/, "الرابط يجب أن يحتوي أحرف صغيرة وأرقام وشرطات فقط"),
  description: z.string().max(1000).optional(),
  country: z.string().max(60).optional(),
  contactInfo: z.string().max(200).optional(),
  commissionPercent: z.number().int().min(0).max(100).default(10),
});

export async function POST(req: Request) {
  const session = await auth();
  const denied = await requirePermission(session?.user as any, "merchant.create");
  if (denied) return NextResponse.json(denied.body, { status: denied.status });

  const body = await req.json().catch(() => null);
  const parsed = CreateSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json({ error: parsed.error.issues[0].message }, { status: 400 });
  }

  const targetUser = await prisma.user.findUnique({ where: { email: parsed.data.userEmail.toLowerCase() } });
  if (!targetUser) {
    return NextResponse.json({ error: "لا يوجد مستخدم بهذا البريد الإلكتروني" }, { status: 404 });
  }
  if (targetUser.role === "MERCHANT") {
    return NextResponse.json({ error: "هذا المستخدم لديه متجر بالفعل" }, { status: 409 });
  }
  if (targetUser.role === "ADMIN" || targetUser.role === "DEVELOPER") {
    return NextResponse.json(
      { error: "لا يمكن تحويل مالك أو مطور إلى تاجر" },
      { status: 409 }
    );
  }

  const slugTaken = await prisma.merchant.findUnique({ where: { slug: parsed.data.slug } });
  if (slugTaken) {
    return NextResponse.json({ error: "رابط المتجر مستخدم بالفعل" }, { status: 409 });
  }

  // Create the Merchant record and flip the user's role to MERCHANT together,
  // so we never end up with a MERCHANT-role user with no store or a store
  // whose owner isn't actually flagged as a merchant.
  const merchant = await prisma.$transaction(async (tx) => {
    const created = await tx.merchant.create({
      data: {
        userId: targetUser.id,
        storeName: parsed.data.storeName,
        slug: parsed.data.slug,
        description: parsed.data.description,
        country: parsed.data.country,
        contactInfo: parsed.data.contactInfo,
        commissionPercent: parsed.data.commissionPercent,
        createdById: (session?.user as any)?.id ?? null,
      },
    });
    await tx.user.update({
      where: { id: targetUser.id },
      data: { role: "MERCHANT" },
    });
    return created;
  });

  await logActivity({
    actorId: (session?.user as any)?.id,
    actorRole: (session?.user as any)?.role,
    action: "merchant.create",
    targetType: "Merchant",
    targetId: merchant.id,
    meta: { storeName: merchant.storeName, forUserEmail: targetUser.email },
  });

  return NextResponse.json({ merchant }, { status: 201 });
}
