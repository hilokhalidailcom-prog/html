import{NextResponse}from"next/server";import{auth}from"@/lib/auth";import{prisma}from"@/lib/prisma";import{hasPermission}from"@/lib/permissions";import{z}from"zod";
const S=z.object({name:z.string().min(1),slug:z.string().min(1),active:z.boolean().optional()});
export async function GET(){return NextResponse.json(await prisma.dynamicProductType.findMany({orderBy:{name:"asc"}}))}
export async function POST(req:Request){const s=await auth();const u=s?.user as any;if(!u||!hasPermission(u,"dynamic.manage"))return NextResponse.json({error:"Forbidden"},{status:u?403:401});const p=S.safeParse(await req.json().catch(()=>null));if(!p.success)return NextResponse.json({error:"Invalid payload"},{status:400});return NextResponse.json(await prisma.dynamicProductType.create({data:p.data}),{status:201})}
