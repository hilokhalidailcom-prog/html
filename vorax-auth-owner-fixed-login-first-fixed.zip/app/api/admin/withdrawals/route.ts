import { NextResponse } from "next/server";
import { auth } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { hasPermission } from "@/lib/permissions";

// This was the actual gap: app/api/admin/withdrawals/[id]/route.ts could
// approve/reject a withdrawal by id, but nothing exposed the list of
// pending ones to act on — an owner/developer had no way to discover them
// except querying the database directly.
export async function GET(req: Request) {
  const s = await auth();
  const u = s?.user as any;
  if (!u) return NextResponse.json({ error: "غير مسجل الدخول" }, { status: 401 });
  if (!hasPermission(u, "withdrawals.view") && !hasPermission(u, "withdrawals.approve")) {
    return NextResponse.json({ error: "لا تملك الصلاحية" }, { status: 403 });
  }

  const url = new URL(req.url);
  const status = url.searchParams.get("status");
  const validStatus = status && ["PENDING", "APPROVED", "REJECTED"].includes(status) ? status : undefined;

  const withdrawals = await prisma.withdrawalRequest.findMany({
    where: validStatus ? { status: validStatus as any } : undefined,
    include: {
      merchant: { select: { id: true, storeName: true, slug: true } },
      user: { select: { id: true, name: true, email: true } },
    },
    orderBy: { createdAt: "desc" },
    take: 200,
  });

  return NextResponse.json(withdrawals);
}
