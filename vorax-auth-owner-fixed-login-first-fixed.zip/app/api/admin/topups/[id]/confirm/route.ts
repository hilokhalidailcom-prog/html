import { NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { sendEmail, topUpConfirmedEmail } from "@/lib/email";
import { reportError } from "@/lib/errorReporting";

const Schema = z.object({ action: z.enum(["confirm", "reject"]) });

export async function PATCH(req: Request, { params }: { params: { id: string } }) {
  const body = await req.json().catch(() => null);
  const parsed = Schema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json({ error: "طلب غير صحيح" }, { status: 400 });
  }

  try {
    const result = await prisma.$transaction(async (tx) => {
      const topUp = await tx.topUpRequest.findUniqueOrThrow({
        where: { id: params.id },
        include: { user: true },
      });
      if (topUp.status !== "PENDING") {
        throw new Error("ALREADY_RESOLVED");
      }

      if (parsed.data.action === "confirm") {
        await tx.user.update({
          where: { id: topUp.userId },
          data: { balance: { increment: topUp.amount } },
        });

        await tx.balanceTransaction.create({
          data: {
            userId: topUp.userId,
            amount: topUp.amount,
            type: "TOPUP",
            referenceId: topUp.id,
            description: "شحن رصيد يدوي معتمد من المالك عبر المنصة",
          },
        });
      }

      return tx.topUpRequest.update({
        where: { id: params.id },
        data: {
          status: parsed.data.action === "confirm" ? "CONFIRMED" : "REJECTED",
          resolvedAt: new Date(),
        },
        include: { user: true },
      });
    });

    if (parsed.data.action === "confirm") {
      await sendEmail({
        to: result.user.email,
        subject: "تم شحن رصيدك - VORAX",
        html: topUpConfirmedEmail(result.amount),
      });
    }

    return NextResponse.json({ topUp: result });
  } catch (err) {
    const message = err instanceof Error ? err.message : "UNKNOWN";
    if (message === "ALREADY_RESOLVED") {
      return NextResponse.json({ error: "تم التعامل مع هذا الطلب مسبقًا" }, { status: 409 });
    }
    console.error("topup confirm error:", err);
    reportError("topup-confirm", err);
    return NextResponse.json({ error: "حدث خطأ" }, { status: 500 });
  }
}
