import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";

export const dynamic = "force-dynamic";

// Auth + admin-role check already enforced by middleware for /api/admin/*.
export async function GET() {
  const topUps = await prisma.topUpRequest.findMany({
    where: { status: "PENDING" },
    include: { user: { select: { id: true, name: true, email: true, balance: true } } },
    orderBy: { createdAt: "asc" },
  });
  return NextResponse.json({ topUps });
}
