import { NextResponse } from "next/server";
import { z } from "zod";
import { auth } from "@/lib/auth";
import { prisma } from "@/lib/prisma";

const CreateSchema = z.object({
  subject: z.string().min(3),
  orderId: z.string().optional(),
  message: z.string().min(3),
});

export async function POST(req: Request) {
  const session = await auth();
  if (!session?.user) {
    return NextResponse.json({ error: "يجب تسجيل الدخول أولاً" }, { status: 401 });
  }
  const body = await req.json().catch(() => null);
  const parsed = CreateSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json({ error: parsed.error.issues[0].message }, { status: 400 });
  }

  const userId = (session.user as any).id as string;
  const ticket = await prisma.supportTicket.create({
    data: {
      userId,
      subject: parsed.data.subject,
      orderId: parsed.data.orderId,
      status: "OPEN",
      messages: { create: { from: "user", text: parsed.data.message } },
    },
    include: { messages: true },
  });

  return NextResponse.json({ ticket }, { status: 201 });
}

export async function GET() {
  const session = await auth();
  if (!session?.user) {
    return NextResponse.json({ error: "يجب تسجيل الدخول أولاً" }, { status: 401 });
  }
  const userId = (session.user as any).id as string;
  const tickets = await prisma.supportTicket.findMany({
    where: { userId },
    include: { messages: { orderBy: { at: "asc" } } },
    orderBy: { createdAt: "desc" },
  });
  return NextResponse.json({ tickets });
}
