import { NextResponse } from "next/server";
import { z } from "zod";
import { auth } from "@/lib/auth";
import { prisma } from "@/lib/prisma";

const Schema = z.object({ text: z.string().min(1) });

export async function POST(req: Request, { params }: { params: { id: string } }) {
  const session = await auth();
  if (!session?.user) {
    return NextResponse.json({ error: "يجب تسجيل الدخول أولاً" }, { status: 401 });
  }

  const body = await req.json().catch(() => null);
  const parsed = Schema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json({ error: "رسالة فارغة" }, { status: 400 });
  }

  const userId = (session.user as any).id as string;
  const role = (session.user as any).role as string;

  const ticket = await prisma.supportTicket.findUnique({ where: { id: params.id } });
  if (!ticket) {
    return NextResponse.json({ error: "التذكرة غير موجودة" }, { status: 404 });
  }
  // Only the ticket owner or an admin may reply.
  if (ticket.userId !== userId && role !== "ADMIN") {
    return NextResponse.json({ error: "غير مصرح" }, { status: 403 });
  }

  const isAdmin = role === "ADMIN";
  const message = await prisma.ticketMessage.create({
    data: { ticketId: ticket.id, from: isAdmin ? "admin" : "user", text: parsed.data.text },
  });

  await prisma.supportTicket.update({
    where: { id: ticket.id },
    data: { status: isAdmin ? "IN_PROGRESS" : "OPEN" },
  });

  return NextResponse.json({ message }, { status: 201 });
}
