"use client";

import { Suspense, useState } from "react";
import Link from "next/link";
import { useSearchParams } from "next/navigation";
import Logo from "@/components/Logo";

export default function RegisterPage() {
  return (
    <Suspense fallback={null}>
      <RegisterForm />
    </Suspense>
  );
}

function RegisterForm() {
  const searchParams = useSearchParams();
  const referralCode = searchParams.get("ref") ?? undefined;

  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [done, setDone] = useState(false);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    setError("");
    try {
      const res = await fetch("/api/auth/register", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name, email, phone, password, referralCode }),
      });
      const data = await res.json();
      if (!res.ok) {
        setError(data.error ?? "حدث خطأ");
        return;
      }
      setDone(true);
    } finally {
      setLoading(false);
    }
  }

  return (
    <div dir="rtl" className="flex min-h-screen items-center justify-center bg-neon-bg px-4">
      <div className="w-full max-w-sm rounded-2xl border border-neon-purple/20 bg-neon-card p-8 shadow-[0_0_60px_rgba(14,165,233,0.12)]">
        <div className="mb-4 flex justify-center">
          <Logo size="header" priority />
        </div>
        <p className="mb-1 text-center text-sm text-neon-muted">إنشاء حساب جديد</p>
        {referralCode && (
          <p className="mb-5 text-xs text-green-400">
            🎁 مدعو بكود <strong>{referralCode}</strong> — غادي تاخد رصيد هدية مع أول طلب
          </p>
        )}
        {!referralCode && <div className="mb-6" />}

        {done ? (
          <p className="rounded-lg bg-green-500/10 px-3 py-3 text-sm text-green-400">
            تم إنشاء الحساب! تحقق من بريدك الإلكتروني وفعّل حسابك قبل تسجيل الدخول.
          </p>
        ) : (
          <form onSubmit={handleSubmit} className="flex flex-col gap-3">
            <input
              required
              placeholder="الاسم الكامل"
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="rounded-lg border border-neon-border bg-neon-cardHover px-4 py-2 text-white outline-none focus:border-neon-purple"
            />
            <input
              type="email"
              required
              placeholder="البريد الإلكتروني"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="rounded-lg border border-neon-border bg-neon-cardHover px-4 py-2 text-white outline-none focus:border-neon-purple"
            />
            <input
              placeholder="رقم الهاتف (اختياري)"
              value={phone}
              onChange={(e) => setPhone(e.target.value)}
              className="rounded-lg border border-neon-border bg-neon-cardHover px-4 py-2 text-white outline-none focus:border-neon-purple"
            />
            <input
              type="password"
              required
              minLength={8}
              placeholder="كلمة المرور (8 أحرف على الأقل)"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="rounded-lg border border-neon-border bg-neon-cardHover px-4 py-2 text-white outline-none focus:border-neon-purple"
            />
            {error && <p className="text-sm text-red-400">{error}</p>}
            <button
              type="submit"
              disabled={loading}
              className="mt-1 rounded-lg bg-gradient-to-r from-blue-600 to-neon-purpleBright px-4 py-2 font-bold text-white transition hover:brightness-110 disabled:opacity-50"
            >
              {loading ? "..." : "إنشاء الحساب"}
            </button>
          </form>
        )}

        <div className="mt-4 text-center text-sm">
          <Link href="/login" className="text-neon-muted hover:text-neon-purpleBright">
            عندك حساب؟ سجل الدخول
          </Link>
        </div>
      </div>
    </div>
  );
}
