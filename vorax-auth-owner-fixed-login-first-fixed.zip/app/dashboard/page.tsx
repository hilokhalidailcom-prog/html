"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { useSession } from "next-auth/react";
import AppShell from "@/components/AppShell";
import { formatTikoun } from "@/lib/currency";
import Icon from "@/components/Icon";

type Order = {
  id: string;
  total: number;
  status: "PENDING" | "PROCESSING" | "COMPLETED" | "CANCELLED";
  createdAt: string;
  items: { number: { phone: string; country: { name: string; flag: string } } }[];
};

const STATUS_LABEL: Record<Order["status"], string> = {
  PENDING: "قيد المعالجة",
  PROCESSING: "قيد المعالجة",
  COMPLETED: "مكتمل",
  CANCELLED: "ملغي",
};

function StatCard({
  icon,
  label,
  value,
}: {
  icon: "wallet" | "orders" | "grid" | "store";
  label: string;
  value: string;
}) {
  return (
    <div className="rounded-2xl border border-neon-border bg-neon-card p-4">
      <div className="mb-2 flex h-9 w-9 items-center justify-center rounded-xl bg-neon-purple/15 text-lg">
        <Icon name={icon} size={18} />
      </div>
      <p className="text-xs text-neon-muted">{label}</p>
      <p className="mt-1 text-lg font-bold text-neon-text">{value}</p>
    </div>
  );
}

export default function DashboardPage() {
  const { data: session } = useSession();
  const [balance, setBalance] = useState(0);
  const [orders, setOrders] = useState<Order[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    Promise.all([
      fetch("/api/wallet/topup-request", { cache: "no-store" }).then((r) =>
        r.ok ? r.json() : { balance: 0 }
      ),
      fetch("/api/orders", { cache: "no-store" }).then((r) =>
        r.ok ? r.json() : { orders: [] }
      ),
    ])
      .then(([wallet, ordersData]) => {
        setBalance(wallet.balance ?? 0);
        setOrders(ordersData.orders ?? []);
      })
      .finally(() => setLoading(false));
  }, []);

  const activeServices = new Set(orders.flatMap((o) => o.items.map((i) => i.number.country.name)))
    .size;
  const numbersOwned = orders.reduce((sum, o) => sum + o.items.length, 0);

  return (
    <AppShell>
      {/* Hero */}
      <div className="relative mb-6 overflow-hidden rounded-2xl border border-neon-border bg-neon-card p-6 sm:p-8">
        <div className="pointer-events-none absolute -left-10 -top-10 h-56 w-56 rounded-full bg-neon-purple/25 blur-3xl" />
        <div className="relative">
          <h1 className="text-2xl font-bold text-neon-text sm:text-3xl">
            مرحبًا بك في VORAX{session?.user?.name ? `، ${session.user.name}` : ""}
          </h1>
          <p className="mt-2 max-w-lg text-sm text-neon-muted sm:text-base">
            منصتك المتكاملة لشراء الأرقام والخدمات الرقمية بسهولة وأمان.
          </p>
          <div className="mt-5 flex flex-wrap gap-3">
            <Link
              href="/store"
              className="rounded-xl bg-gradient-to-l from-neon-purple to-neon-purpleBright px-5 py-2.5 text-sm font-semibold text-white shadow-[0_0_20px_rgba(124,58,237,0.35)]"
            >
              تصفح الخدمات
            </Link>
            <Link
              href="/wallet"
              className="rounded-xl border border-neon-border bg-neon-cardHover px-5 py-2.5 text-sm font-semibold text-neon-text"
            >
              شحن الرصيد
            </Link>
          </div>
        </div>
      </div>

      {/* Stats */}
      <div className="mb-6 grid grid-cols-2 gap-3 lg:grid-cols-4">
        <StatCard icon="wallet" label="الرصيد الحالي" value={formatTikoun(balance)} />
        <StatCard icon="orders" label="إجمالي الطلبات" value={`${orders.length} طلب`} />
        <StatCard icon="grid" label="الدول المستخدمة" value={`${activeServices} دولة`} />
        <StatCard icon="store" label="الأرقام المشتراة" value={`${numbersOwned} رقم`} />
      </div>

      {/* Recent orders */}
      <div className="rounded-2xl border border-neon-border bg-neon-card p-4 sm:p-6">
        <div className="mb-4 flex items-center justify-between">
          <h2 className="font-bold text-neon-text">آخر الطلبات</h2>
          <Link href="/orders" className="text-xs text-neon-purpleBright">
            عرض الكل
          </Link>
        </div>
        {loading ? (
          <p className="text-sm text-neon-muted">جارِ التحميل...</p>
        ) : orders.length === 0 ? (
          <p className="text-sm text-neon-muted">لا توجد طلبات بعد.</p>
        ) : (
          <div className="space-y-2">
            {orders.slice(0, 5).map((order) => (
              <div
                key={order.id}
                className="flex items-center justify-between rounded-xl bg-neon-bg px-3 py-2.5 text-sm"
              >
                <span dir="ltr" className="text-neon-text">
                  {order.items[0]?.number.phone ?? "—"}
                  {order.items.length > 1 ? ` +${order.items.length - 1}` : ""}
                </span>
                <span className="text-neon-muted">{STATUS_LABEL[order.status]}</span>
                <span className="font-semibold text-neon-purpleBright">
                  {formatTikoun(order.total)}
                </span>
              </div>
            ))}
          </div>
        )}
      </div>
    </AppShell>
  );
}
