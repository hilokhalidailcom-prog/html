"use client";
import { useState } from "react";

export default function AIPage() {
  const [q, setQ] = useState("أريد رقمًا مميزًا بأقل من 200");
  const [data, setData] = useState<any>(null);
  const [conversationId, setConversationId] = useState<string>();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  async function ask() {
    if (!q.trim()) return;
    setLoading(true);
    setError("");
    try {
      const r = await fetch("/api/ai/assistant", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ message: q, conversationId }),
      });
      const json = await r.json();
      if (!r.ok) throw new Error(json.message || json.error || "AI_UNAVAILABLE");
      setData(json);
      if (json.conversationId) setConversationId(json.conversationId);
    } catch (e: any) {
      setError(e?.message || "تعذر تشغيل الذكاء الاصطناعي");
    } finally {
      setLoading(false);
    }
  }

  return <main className="mx-auto max-w-5xl p-4 sm:p-8">
    <h1 className="text-3xl font-bold">VORAX AI</h1>
    <p className="mt-2 text-gray-500">مساعد ذكي يبحث في بيانات PhoneNumber الحقيقية داخل VORAX.</p>
    <div className="mt-6 flex flex-col gap-3 sm:flex-row">
      <input className="flex-1 rounded-xl border p-3" value={q} onChange={e => setQ(e.target.value)} onKeyDown={e => { if (e.key === "Enter") ask(); }} placeholder="مثال: أريد رقمًا مغربيًا بأقل من 200" />
      <button className="rounded-xl bg-neon-bg px-5 py-3 text-white disabled:opacity-50" onClick={ask} disabled={loading}>{loading ? "يفكر..." : "اسأل VORAX AI"}</button>
    </div>
    {error && <div className="mt-4 rounded-xl border border-red-200 bg-red-50 p-4 text-red-700">{error}</div>}
    {data && <div className="mt-6 space-y-4">
      <div className="rounded-2xl border p-4"><p>{data.answer}</p><small className="text-gray-500">المصدر: {data.provider === "openai" ? `VORAX AI / ${data.model}` : "VORAX Search Fallback"}</small></div>
      <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-4">
        {(data.results ?? []).map((n: any) => <div key={n.id} className="rounded-2xl border p-4"><b>{n.phone}</b><div>{n.price} £</div><small>{n.merchant?.storeName ?? "VORAX"}</small></div>)}
      </div>
    </div>}
  </main>;
}
