import type { Metadata } from "next";
import { SITE_NAME, SITE_URL } from "@/lib/seo";

export const metadata: Metadata = {
  title: `الشروط والأحكام | ${SITE_NAME}`,
  description: `الشروط والأحكام الخاصة باستخدام منصة ${SITE_NAME} وشراء الأرقام.`,
  alternates: { canonical: `${SITE_URL}/terms` },
};

// ⚠️ نموذج عام — راجعه مع محامي قبل تفعيل بوابة دفع حقيقية (CMI/Stripe)،
// وعوّض [اسم الشركة]/[العنوان]/[البريد] بمعطياتك الحقيقية.
export default function TermsPage() {
  return (
    <div dir="rtl" className="min-h-screen bg-neon-bg px-4 py-12 text-neon-text">
      <div className="mx-auto max-w-2xl">
        <h1 className="mb-2 text-2xl font-bold text-neon-purpleBright">الشروط والأحكام</h1>
        <p className="mb-8 text-sm text-neon-muted">آخر تحديث: [التاريخ]</p>

        <section className="mb-6 space-y-2">
          <h2 className="text-lg font-semibold text-white">1. التعريف بالمنصة</h2>
          <p>
            {SITE_NAME} هي منصة إلكترونية تابعة لـ [اسم الشركة]، متخصصة في بيع أرقام هاتف
            (عادية، VIP، مكررة، سهلة، دولية، افتراضية) مقابل رصيد "تيكون" الافتراضي المستعمل
            داخل المنصة فقط.
          </p>
        </section>

        <section className="mb-6 space-y-2">
          <h2 className="text-lg font-semibold text-white">2. الحساب والتسجيل</h2>
          <p>
            يجب تفعيل البريد الإلكتروني قبل استعمال الحساب. المستخدم مسؤول عن سرية بيانات
            الدخول ديالو، وأي عملية تتم من حسابه تعتبر صادرة عنه.
          </p>
        </section>

        <section className="mb-6 space-y-2">
          <h2 className="text-lg font-semibold text-white">3. رصيد تيكون والدفع</h2>
          <p>
            رصيد تيكون كيتشحن يدوياً حالياً عبر التواصل مع الإدارة، ولا يمكن استرجاعه نقداً.
            بمجرد إتمام عملية شراء رقم، الرصيد المخصوم لا يُرجع إلا في حالة خطأ من المنصة
            (رقم غير متوفر، خلل تقني).
          </p>
        </section>

        <section className="mb-6 space-y-2">
          <h2 className="text-lg font-semibold text-white">4. الأرقام المباعة</h2>
          <p>
            الأرقام المعروضة تُباع كما هي ("as is"). المنصة لا تضمن استمرارية عمل الرقم من
            طرف مزود الخدمة الأصلي، وتقتصر مسؤوليتها على تسليم الرقم المطابق للوصف المعروض
            وقت الشراء.
          </p>
        </section>

        <section className="mb-6 space-y-2">
          <h2 className="text-lg font-semibold text-white">5. أكواد الخصم والإحالة</h2>
          <p>
            المنصة كتحتفظ بالحق فـ تعديل، إيقاف، أو إلغاء أي كود خصم أو نظام إحالة فأي وقت،
            وفـ رفض أي استعمال يبان أنه احتيالي (حسابات وهمية، إساءة استعمال الأكواد...).
          </p>
        </section>

        <section className="mb-6 space-y-2">
          <h2 className="text-lg font-semibold text-white">6. التواصل والدعم</h2>
          <p>
            لأي استفسار أو نزاع، تواصل معنا عبر [البريد الإلكتروني] أو نظام التذاكر داخل
            المنصة.
          </p>
        </section>

        <section className="space-y-2">
          <h2 className="text-lg font-semibold text-white">7. القانون المطبق</h2>
          <p>هاذ الشروط خاضعة للقانون المغربي، والاختصاص للمحاكم المختصة بـ [المدينة].</p>
        </section>
      </div>
    </div>
  );
}
