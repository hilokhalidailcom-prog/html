"use client";

import { useEffect, useState } from "react";

interface MerchantMe {
  id: string;
  storeName: string;
  slug: string;
  description: string | null;
  logoUrl: string | null;
  country: string | null;
  contactInfo: string | null;
  status: "PENDING" | "ACTIVE" | "SUSPENDED" | "CLOSED";
  verified: boolean;
  commissionPercent: number;
}

const STATUS_LABEL: Record<string, string> = {
  PENDING: "🟡 قيد المراجعة — سيتم تفعيل متجرك بعد الموافقة",
  ACTIVE: "🟢 متجرك نشط ومرئي للعملاء",
  SUSPENDED: "🔴 متجرك معلّق حالياً — تواصل مع الدعم",
  CLOSED: "⚫ متجرك مغلق",
};

export default function MerchantDashboardPage() {
  const [merchant, setMerchant] = useState<MerchantMe | null>(null);
  const [loading, setLoading] = useState(true);
  const [notFound, setNotFound] = useState(false);

  const [description, setDescription] = useState("");
  const [contactInfo, setContactInfo] = useState("");
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");
  const [saved, setSaved] = useState(false);

  async function load() {
    setLoading(true);
    const res = await fetch("/api/merchant/me");
    if (res.status === 404) {
      setNotFound(true);
      setLoading(false);
      return;
    }
    const data = await res.json();
    setMerchant(data.merchant ?? null);
    setDescription(data.merchant?.description ?? "");
    setContactInfo(data.merchant?.contactInfo ?? "");
    setLoading(false);
  }

  useEffect(() => {
    load();
  }, []);

  async function handleSave(e: React.FormEvent) {
    e.preventDefault();
    setSaving(true);
    setError("");
    setSaved(false);
    try {
      const res = await fetch("/api/merchant/me", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ description, contactInfo }),
      });
      const data = await res.json();
      if (!res.ok) {
        setError(data.error ?? "حدث خطأ");
        return;
      }
      setMerchant(data.merchant);
      setSaved(true);
    } finally {
      setSaving(false);
    }
  }

  if (loading) {
    return <div dir="rtl" className="p-8 text-neon-muted">جاري التحميل...</div>;
  }

  if (notFound || !merchant) {
    return (
      <div dir="rtl" className="mx-auto max-w-xl p-8 text-center text-neon-muted">
        لا يوجد متجر مرتبط بحسابك بعد. تواصل مع إدارة المنصة لإنشاء متجرك.
      </div>
    );
  }

  return (
    <div dir="rtl" className="mx-auto max-w-3xl p-8">
      <h1 className="mb-2 text-2xl font-bold text-neon-purpleBright">🏪 {merchant.storeName}</h1>
      <p className="mb-6 text-sm text-neon-muted">{STATUS_LABEL[merchant.status]}</p>

      <div className="mb-8 grid grid-cols-2 gap-3 sm:grid-cols-4">
        <div className="rounded-xl border border-neon-border bg-neon-card p-4 text-center">
          <p className="text-xs text-neon-muted">العمولة</p>
          <p className="text-lg font-bold text-white">{merchant.commissionPercent}%</p>
        </div>
        <div className="rounded-xl border border-neon-border bg-neon-card p-4 text-center">
          <p className="text-xs text-neon-muted">التوثيق</p>
          <p className="text-lg font-bold text-white">{merchant.verified ? "✓ موثّق" : "غير موثّق"}</p>
        </div>
        <div className="rounded-xl border border-neon-border bg-neon-card p-4 text-center">
          <p className="text-xs text-neon-muted">الرابط</p>
          <p className="truncate text-lg font-bold text-white">/{merchant.slug}</p>
        </div>
        <div className="rounded-xl border border-neon-border bg-neon-card p-4 text-center">
          <p className="text-xs text-neon-muted">الدولة</p>
          <p className="text-lg font-bold text-white">{merchant.country ?? "—"}</p>
        </div>
      </div>

      <form
        onSubmit={handleSave}
        className="flex flex-col gap-3 rounded-xl border border-neon-border bg-neon-card p-5"
      >
        <h2 className="font-semibold text-white">⚙️ إعدادات المتجر</h2>

        <textarea
          placeholder="وصف المتجر"
          value={description}
          onChange={(e) => setDescription(e.target.value)}
          rows={3}
          className="rounded-lg border border-neon-border bg-neon-cardHover px-3 py-2 text-white outline-none focus:border-neon-purple"
        />
        <input
          placeholder="وسيلة التواصل"
          value={contactInfo}
          onChange={(e) => setContactInfo(e.target.value)}
          className="rounded-lg border border-neon-border bg-neon-cardHover px-3 py-2 text-white outline-none focus:border-neon-purple"
        />

        <button
          type="submit"
          disabled={saving}
          className="self-start rounded-lg bg-gradient-to-r from-blue-600 to-neon-purpleBright px-4 py-2 font-bold text-white disabled:opacity-50"
        >
          {saving ? "..." : "حفظ"}
        </button>

        {error && <p className="text-sm text-red-400">{error}</p>}
        {saved && <p className="text-sm text-emerald-400">✅ تم الحفظ</p>}
      </form>

      <p className="mt-4 text-xs text-neon-muted">
        📦 إدارة المنتجات والطلبات والأرباح غادي تتزاد فالمرحلة الجاية.
      </p>
    </div>
  );
}
