# VORAX — Final Build Package Report

## What this package contains
This package starts from the latest VORAX Execution 1 archive and includes the
project source plus a complete machine-readable remaining-roadmap contract.

## Important accuracy note
A source archive cannot honestly be described as having all 19 batches implemented
without actually editing every relevant source file, running the application, applying
database migrations, and validating external integrations. Production-only services
also require real credentials.

Therefore this package does NOT falsely mark unimplemented features as complete.

## Remaining implementation order
- Execution 2: Batches 4 + 5 + 6
- Execution 3: Batches 7 + 8 + 9
- Execution 4: Batches 10 + 11 + 12
- Execution 5: Batches 13 + 14 + 15
- Execution 6: Batches 16 + 17 + 18
- Execution 7: Batch 19 + Final Integration + Final Audit

## Architecture invariants
- PhoneNumber is the actual sellable unit.
- User.balance is the Tikoun (£) source of truth.
- No parallel Product or Wallet system.
- Existing Orders/OrderItems/Reviews/ActivityLog/RBAC are reused.
- Sensitive actions enforce role + permission + ownership.
- AI has constrained backend tools only.

## Added in this integration pass — Merchant/Customer Chat
- Persistent `MerchantChat` and `MerchantChatMessage` domain models.
- Customer and merchant authenticated chat APIs with ownership/order checks.
- Customer chat UI at `/chat` and merchant chat UI at `/merchant/chat`.
- Telegram Bot relay: `/chats`, `/chat <id>`, `/close`, and active-chat message forwarding.
- Web-originated chat messages are relayed to the other participant when they have a linked Telegram account.
- Telegram webhook secret validation remains enabled through `TELEGRAM_WEBHOOK_SECRET`.
- `scripts/set-telegram-webhook.ts` and `telegram:webhook` npm script configure the production webhook.
