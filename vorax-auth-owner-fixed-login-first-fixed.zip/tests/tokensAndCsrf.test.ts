import { describe, it, expect } from "vitest";
import { generateToken } from "@/lib/tokens";
import { isTrustedOrigin } from "@/lib/csrf";

describe("generateToken", () => {
  it("produces a URL-safe token with the requested expiry", () => {
    const { token, expires } = generateToken(60_000);
    expect(token).toMatch(/^[A-Za-z0-9_-]+$/);
    expect(token.length).toBeGreaterThan(30);
    expect(expires.getTime()).toBeGreaterThan(Date.now());
  });

  it("generates unique tokens on each call", () => {
    const a = generateToken(1000).token;
    const b = generateToken(1000).token;
    expect(a).not.toBe(b);
  });
});

describe("isTrustedOrigin", () => {
  it("accepts a matching Origin header", () => {
    const req = new Request("http://x", { headers: { origin: "http://localhost:3000" } });
    expect(isTrustedOrigin(req)).toBe(true);
  });

  it("rejects a mismatched Origin header", () => {
    const req = new Request("http://x", { headers: { origin: "https://evil.example" } });
    expect(isTrustedOrigin(req)).toBe(false);
  });

  it("falls back to Referer when Origin is absent", () => {
    const req = new Request("http://x", { headers: { referer: "http://localhost:3000/checkout" } });
    expect(isTrustedOrigin(req)).toBe(true);
  });

  it("allows requests with neither header (native/server clients)", () => {
    const req = new Request("http://x");
    expect(isTrustedOrigin(req)).toBe(true);
  });
});
