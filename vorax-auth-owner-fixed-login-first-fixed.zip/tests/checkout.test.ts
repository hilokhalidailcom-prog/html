import { describe, it, expect, vi, beforeEach } from "vitest";
import { prismaMock, resetPrismaMock } from "./mocks/prisma";

vi.mock("@/lib/prisma", () => ({ prisma: prismaMock }));
vi.mock("@/lib/auth", () => ({
  auth: vi.fn(async () => ({ user: { id: "user-1", role: "USER" } })),
}));

const { POST } = await import("@/app/api/orders/checkout/route");

function makeRequest(body: unknown) {
  return new Request("http://localhost:3000/api/orders/checkout", {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify(body),
  });
}

const validBody = {
  numberIds: ["n1"],
  customerName: "Yassine",
  customerPhone: "0600000000",
  customerEmail: "y@example.com",
};

describe("POST /api/orders/checkout", () => {
  beforeEach(() => resetPrismaMock());

  it("returns 402 with the platform wallet URL when balance is insufficient", async () => {
    prismaMock.$transaction.mockImplementationOnce(async (fn: any) => {
      // Simulate the real transaction body throwing INSUFFICIENT_BALANCE.
      const tx = {
        phoneNumber: {
          findMany: vi.fn().mockResolvedValue([{ id: "n1", price: 500 }]),
        },
        user: {
          findUniqueOrThrow: vi.fn().mockResolvedValue({ id: "user-1", balance: 100 }),
        },
      };
      return fn(tx as any);
    });

    const res = await POST(makeRequest(validBody));
    const data = await res.json();

    expect(res.status).toBe(402);
    expect(data.error).toBe("INSUFFICIENT_BALANCE");
    expect(data.topUpUrl).toBe("/wallet");
  });

  it("deducts the balance and creates the order when funds are sufficient", async () => {
    const updateBalance = vi.fn().mockResolvedValue({});
    const updateNumbers = vi.fn().mockResolvedValue({});
    const createOrder = vi.fn().mockResolvedValue({ id: "order-1", total: 500, items: [] });

    prismaMock.$transaction.mockImplementationOnce(async (fn: any) => {
      const tx = {
        phoneNumber: {
          findMany: vi.fn().mockResolvedValue([{ id: "n1", price: 500 }]),
          updateMany: updateNumbers,
        },
        user: {
          findUniqueOrThrow: vi.fn().mockResolvedValue({ id: "user-1", balance: 1000 }),
          update: updateBalance,
        },
        order: { create: createOrder },
      };
      return fn(tx as any);
    });

    const res = await POST(makeRequest(validBody));
    const data = await res.json();

    expect(res.status).toBe(201);
    expect(data.order.id).toBe("order-1");
    expect(updateBalance).toHaveBeenCalledWith(
      expect.objectContaining({ data: { balance: { decrement: 500 } } })
    );
    expect(updateNumbers).toHaveBeenCalled();
  });

  it("returns 409 when a requested number is no longer available", async () => {
    prismaMock.$transaction.mockImplementationOnce(async (fn: any) => {
      const tx = { phoneNumber: { findMany: vi.fn().mockResolvedValue([]) } };
      return fn(tx as any);
    });

    const res = await POST(makeRequest(validBody));
    expect(res.status).toBe(409);
  });

  it("requires authentication", async () => {
    const authModule = await import("@/lib/auth");
    (authModule.auth as any).mockResolvedValueOnce(null);

    const res = await POST(makeRequest(validBody));
    expect(res.status).toBe(401);
  });
});
