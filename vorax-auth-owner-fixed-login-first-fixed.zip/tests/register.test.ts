import { describe, it, expect, vi, beforeEach } from "vitest";
import { prismaMock, resetPrismaMock } from "./mocks/prisma";

vi.mock("@/lib/prisma", () => ({ prisma: prismaMock }));
vi.mock("@/lib/email", () => ({
  sendEmail: vi.fn(),
  verificationEmail: vi.fn(() => "<html></html>"),
}));

// Import after mocks are registered so the route picks up the mocked prisma.
const { POST } = await import("@/app/api/auth/register/route");

function makeRequest(body: unknown, ip = "10.0.0.1") {
  return new Request("http://localhost:3000/api/auth/register", {
    method: "POST",
    headers: { "content-type": "application/json", "x-forwarded-for": ip },
    body: JSON.stringify(body),
  });
}

describe("POST /api/auth/register", () => {
  beforeEach(() => resetPrismaMock());

  it("rejects a weak password", async () => {
    const res = await POST(
      makeRequest({ name: "Yassine", email: "y@example.com", password: "123" })
    );
    expect(res.status).toBe(400);
  });

  it("rejects a duplicate email", async () => {
    prismaMock.user.findUnique.mockResolvedValueOnce({ id: "u1" });
    const res = await POST(
      makeRequest({ name: "Yassine", email: "taken@example.com", password: "goodpassword" })
    );
    expect(res.status).toBe(409);
  });

  it("creates a user with balance 0 and an unverified email on success", async () => {
    prismaMock.user.findUnique.mockResolvedValueOnce(null);
    prismaMock.user.create.mockResolvedValueOnce({
      id: "u1",
      name: "Yassine",
      email: "new@example.com",
      balance: 0,
    });

    const res = await POST(
      makeRequest({ name: "Yassine", email: "new@example.com", password: "goodpassword" })
    );
    const data = await res.json();

    expect(res.status).toBe(201);
    expect(data.user.balance).toBe(0);
    expect(prismaMock.user.create).toHaveBeenCalledWith(
      expect.objectContaining({
        data: expect.objectContaining({ balance: 0, verificationToken: expect.any(String) }),
      })
    );
  });

  it("enforces the per-IP rate limit after 5 registrations", async () => {
    prismaMock.user.findUnique.mockResolvedValue(null);
    prismaMock.user.create.mockResolvedValue({ id: "u", name: "x", email: "x@x.com", balance: 0 });

    const ip = `10.0.0.${Math.floor(Math.random() * 255)}`;
    for (let i = 0; i < 5; i++) {
      const res = await POST(makeRequest({ name: "x", email: `x${i}@x.com`, password: "goodpassword" }, ip));
      expect(res.status).toBe(201);
    }
    const sixth = await POST(makeRequest({ name: "x", email: "x6@x.com", password: "goodpassword" }, ip));
    expect(sixth.status).toBe(429);
  });
});
