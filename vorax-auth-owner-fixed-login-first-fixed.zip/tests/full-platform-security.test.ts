import { describe, expect, it } from "vitest";
import { hasPermission, MERCHANT_PERMISSIONS } from "@/lib/permissions";

describe("VORAX full-platform permission boundaries", () => {
  it("owner has all permissions", () => {
    expect(hasPermission({id:"o",role:"ADMIN",permissions:[]}, "withdrawals.approve")).toBe(true);
    expect(hasPermission({id:"o",role:"ADMIN",permissions:[]}, "backup.manage")).toBe(true);
  });
  it("developer only has granted permissions", () => {
    expect(hasPermission({id:"d",role:"DEVELOPER",permissions:["ledger.view"]}, "ledger.view")).toBe(true);
    expect(hasPermission({id:"d",role:"DEVELOPER",permissions:["ledger.view"]}, "withdrawals.approve")).toBe(false);
  });
  it("customer and merchant cannot use staff permissions", () => {
    for (const role of ["USER","MERCHANT"] as const)
      expect(hasPermission({id:"x",role,permissions:[]}, "orders.manage")).toBe(false);
  });
  it("new permission vocabulary is registered", () => {
    expect(MERCHANT_PERMISSIONS).toContain("ai.manage");
    expect(MERCHANT_PERMISSIONS).toContain("security.manage");
    expect(MERCHANT_PERMISSIONS).toContain("dynamic.manage");
  });
});
