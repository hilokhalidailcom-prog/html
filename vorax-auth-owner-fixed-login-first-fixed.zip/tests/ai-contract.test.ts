import { describe, expect, it } from "vitest";

describe("VORAX AI contract", () => {
  it("requires a provider key for live LLM mode and exposes a safe default model", () => {
    expect(process.env.OPENAI_MODEL || "gpt-4.1-mini").toBeTruthy();
  });
});
