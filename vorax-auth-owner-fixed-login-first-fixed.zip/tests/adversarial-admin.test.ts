import { describe, it, expect, beforeEach, vi } from "vitest";
import { prismaMock, resetPrismaMock } from "./mocks/prisma";

vi.mock("@/lib/prisma", () => ({ prisma: prismaMock }));

let currentUser: any = null;
vi.mock("@/lib/auth", () => ({
  auth: vi.fn(async () => (currentUser ? { user: currentUser } : null)),
}));

const { GET: listWithdrawals } = await import("@/app/api/admin/withdrawals/route");
const { PATCH: reviewWithdrawal } = await import("@/app/api/admin/withdrawals/[id]/route");
const { PATCH: updateDeveloperPermissions } = await import("@/app/api/admin/developers/route");

function req(url: string, init?: RequestInit) {
  return new Request(url, init);
}

describe("adversarial: spec §16 named attack cases", () => {
  beforeEach(() => {
    resetPrismaMock();
    currentUser = null;
  });

  it("Customer → Admin API: a plain USER hitting /api/admin/withdrawals gets 403, not data", async () => {
    currentUser = { id: "cust1", role: "USER", permissions: [] };
    const res = await listWithdrawals(req("http://localhost/api/admin/withdrawals"));
    expect(res.status).toBe(403);
    expect(prismaMock.withdrawalRequest.findMany).not.toHaveBeenCalled();
  });

  it("unauthenticated request gets 401, not 403 (no session to check permissions against)", async () => {
    currentUser = null;
    const res = await listWithdrawals(req("http://localhost/api/admin/withdrawals"));
    expect(res.status).toBe(401);
  });

  it("Developer → Permission غير ممنوحة: a developer without withdrawals.approve cannot approve", async () => {
    currentUser = { id: "dev1", role: "DEVELOPER", permissions: ["merchant.view"] };
    const res = await reviewWithdrawal(
      req("http://localhost/api/admin/withdrawals/w1", {
        method: "PATCH",
        body: JSON.stringify({ action: "APPROVE" }),
      }),
      { params: { id: "w1" } }
    );
    expect(res.status).toBe(403);
    expect(prismaMock.withdrawalRequest.update).not.toHaveBeenCalled();
  });

  it("Developer → Permission غير ممنوحة: cannot grant themselves or others new permissions without developer.manage", async () => {
    currentUser = { id: "dev1", role: "DEVELOPER", permissions: ["withdrawals.approve"] };
    const res = await updateDeveloperPermissions(
      req("http://localhost/api/admin/developers", {
        method: "PATCH",
        body: JSON.stringify({ userId: "dev1", permissions: ["backup.manage"] }),
      })
    );
    expect(res.status).toBe(403);
  });

  it("a developer WITH the exact permission granted succeeds", async () => {
    currentUser = { id: "dev1", role: "DEVELOPER", permissions: ["withdrawals.approve"] };
    prismaMock.withdrawalRequest.findUnique.mockResolvedValueOnce({
      id: "w1",
      merchantId: "m1",
      amount: 100,
      status: "PENDING",
    });
    prismaMock.ledgerEntry.aggregate.mockResolvedValue({ _sum: { netAmount: 1000 } });
    prismaMock.ledgerEntry.findMany.mockResolvedValue([]);
    prismaMock.ledgerEntry.create.mockResolvedValue({});
    prismaMock.withdrawalRequest.aggregate.mockResolvedValue({ _sum: { amount: 0 } });
    prismaMock.withdrawalRequest.update.mockResolvedValueOnce({ id: "w1", status: "APPROVED" });

    const res = await reviewWithdrawal(
      req("http://localhost/api/admin/withdrawals/w1", {
        method: "PATCH",
        body: JSON.stringify({ action: "APPROVE" }),
      }),
      { params: { id: "w1" } }
    );
    expect(res.status).toBe(200);
  });
});
