import { describe, it, expect, vi, beforeEach } from "vitest";
import { prismaMock, resetPrismaMock } from "./mocks/prisma";

vi.mock("@/lib/prisma", () => ({ prisma: prismaMock }));
vi.mock("@/lib/email", () => ({
  sendEmail: vi.fn(),
  topUpConfirmedEmail: vi.fn(() => "<html></html>"),
}));

const { PATCH } = await import("@/app/api/admin/topups/[id]/confirm/route");

function makeRequest(action: "confirm" | "reject") {
  return new Request("http://localhost:3000/api/admin/topups/t1/confirm", {
    method: "PATCH",
    headers: { "content-type": "application/json" },
    body: JSON.stringify({ action }),
  });
}

describe("PATCH /api/admin/topups/[id]/confirm", () => {
  beforeEach(() => resetPrismaMock());

  it("credits the user's balance on confirm", async () => {
    const updateBalance = vi.fn().mockResolvedValue({});
    prismaMock.$transaction.mockImplementationOnce(async (fn: any) => {
      const tx = {
        topUpRequest: {
          findUniqueOrThrow: vi.fn().mockResolvedValue({
            id: "t1",
            userId: "user-1",
            amount: 300,
            status: "PENDING",
            user: { id: "user-1", email: "y@example.com" },
          }),
          update: vi.fn().mockResolvedValue({
            id: "t1",
            amount: 300,
            status: "CONFIRMED",
            user: { email: "y@example.com" },
          }),
        },
        user: { update: updateBalance },
      };
      return fn(tx as any);
    });

    const res = await PATCH(makeRequest("confirm"), { params: { id: "t1" } });
    const data = await res.json();

    expect(res.status).toBe(200);
    expect(updateBalance).toHaveBeenCalledWith(
      expect.objectContaining({ data: { balance: { increment: 300 } } })
    );
    expect(data.topUp.status).toBe("CONFIRMED");
  });

  it("does not touch the balance on reject", async () => {
    const updateBalance = vi.fn();
    prismaMock.$transaction.mockImplementationOnce(async (fn: any) => {
      const tx = {
        topUpRequest: {
          findUniqueOrThrow: vi.fn().mockResolvedValue({
            id: "t1",
            userId: "user-1",
            amount: 300,
            status: "PENDING",
            user: { id: "user-1", email: "y@example.com" },
          }),
          update: vi.fn().mockResolvedValue({ id: "t1", status: "REJECTED" }),
        },
        user: { update: updateBalance },
      };
      return fn(tx as any);
    });

    const res = await PATCH(makeRequest("reject"), { params: { id: "t1" } });
    expect(res.status).toBe(200);
    expect(updateBalance).not.toHaveBeenCalled();
  });

  it("returns 409 if the request was already resolved", async () => {
    prismaMock.$transaction.mockImplementationOnce(async (fn: any) => {
      const tx = {
        topUpRequest: {
          findUniqueOrThrow: vi.fn().mockResolvedValue({
            id: "t1",
            status: "CONFIRMED",
            user: {},
          }),
        },
      };
      return fn(tx as any);
    });

    const res = await PATCH(makeRequest("confirm"), { params: { id: "t1" } });
    expect(res.status).toBe(409);
  });
});
