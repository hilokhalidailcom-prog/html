import { vi } from "vitest";

// A minimal mock covering only the methods each test needs. Each test file
// calls `resetPrismaMock()` then sets up `.mockResolvedValueOnce(...)` per case.
export const prismaMock = {
  user: {
    findUnique: vi.fn(),
    findUniqueOrThrow: vi.fn(),
    create: vi.fn(),
    update: vi.fn(),
  },
  phoneNumber: {
    findMany: vi.fn(),
    updateMany: vi.fn(),
  },
  merchant: {
    findUnique: vi.fn(),
  },
  withdrawalRequest: {
    findMany: vi.fn(),
    findUnique: vi.fn(),
    update: vi.fn(),
    aggregate: vi.fn(),
  },
  ledgerEntry: {
    aggregate: vi.fn(),
    findMany: vi.fn(),
    create: vi.fn(),
  },
  order: {
    create: vi.fn(),
    update: vi.fn(),
  },
  topUpRequest: {
    create: vi.fn(),
    findMany: vi.fn(),
    findUniqueOrThrow: vi.fn(),
    update: vi.fn(),
  },
  loginEvent: {
    create: vi.fn(),
  },
  activityLog: {
    create: vi.fn(),
  },
  $transaction: vi.fn(),
};

export function resetPrismaMock() {
  Object.values(prismaMock).forEach((group) => {
    if (typeof group === "function") {
      (group as any).mockReset();
      return;
    }
    Object.values(group).forEach((fn: any) => fn.mockReset());
  });
}
