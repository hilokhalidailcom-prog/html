# VORAX AI — Fixed

The VORAX AI layer now uses a real OpenAI-compatible LLM through the server-side `/api/ai/assistant` route.

## What was fixed
- Real LLM call with tool/function calling.
- Constrained tools only; no direct database access from the model.
- Real PhoneNumber search with availability + approval filtering.
- Natural-language country/category/price/rating/sorting parameters.
- Conversation continuity using stored user/assistant messages.
- User-order tool requires an authenticated user.
- Tool traces are stored as AIMessage records.
- Explicit system instruction prevents invented products, prices, stock, merchants, reviews and orders.
- Graceful deterministic fallback when no provider key is configured.
- AI UI preserves conversationId and reports provider failures.

## Required environment
Set these values in the deployment environment (do not commit secrets):

```env
OPENAI_API_KEY=your_real_key
OPENAI_MODEL=gpt-4.1-mini
OPENAI_BASE_URL=https://api.openai.com/v1
```

The API key is server-side only and is never exposed to the browser.

## Run
```bash
npm install
npx prisma generate
npm run typecheck
npm test
npm run build
```

If `OPENAI_API_KEY` is missing, the marketplace endpoint still works using the deterministic backend search fallback, but the natural-language LLM mode will not be active.
