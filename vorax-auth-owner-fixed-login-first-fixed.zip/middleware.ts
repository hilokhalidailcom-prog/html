import { auth } from "@/lib/auth";
import { NextResponse } from "next/server";
import { isTrustedOrigin } from "@/lib/csrf";

const MUTATING_METHODS = new Set(["POST", "PATCH", "PUT", "DELETE"]);

export default auth((req) => {
  const isLoggedIn = !!req.auth;
  const role = (req.auth?.user as any)?.role;
  const { pathname } = req.nextUrl;

  // CSRF: reject cross-origin state-changing API calls before anything else runs.
  if (
    pathname.startsWith("/api/") &&
    MUTATING_METHODS.has(req.method) &&
    !isTrustedOrigin(req)
  ) {
    return NextResponse.json({ error: "طلب مرفوض (origin غير موثوق)" }, { status: 403 });
  }

  if (pathname === "/") {
    if (!isLoggedIn) return NextResponse.redirect(new URL("/login", req.url));
  }

  if (pathname.startsWith("/admin") && (!isLoggedIn || role !== "ADMIN")) {
    return NextResponse.redirect(new URL("/login", req.url));
  }
  if (pathname.startsWith("/dashboard") && !isLoggedIn) {
    return NextResponse.redirect(new URL("/login", req.url));
  }
  if (
    (pathname.startsWith("/account") ||
      pathname.startsWith("/orders") ||
      pathname.startsWith("/wallet") ||
      pathname.startsWith("/chat") ||
      pathname.startsWith("/support") ||
      pathname.startsWith("/notifications")) &&
    !isLoggedIn
  ) {
    return NextResponse.redirect(new URL("/login", req.url));
  }
  if (pathname.startsWith("/api/admin") && (!isLoggedIn || !["ADMIN", "DEVELOPER"].includes(role))) {
    return NextResponse.json({ error: "غير مصرح" }, { status: 403 });
  }

  return NextResponse.next();
});

export const config = {
  matcher: [
    "/",
    "/admin/:path*",
    "/dashboard/:path*",
    "/account/:path*",
    "/orders/:path*",
    "/wallet/:path*",
    "/chat/:path*",
    "/support/:path*",
    "/notifications/:path*",
    "/api/:path*",
  ],
};
