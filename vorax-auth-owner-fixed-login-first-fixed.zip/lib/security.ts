import { prisma } from "@/lib/prisma";
import { logActivity } from "@/lib/permissions";

export async function securityEvent(data:{
  userId?:string; action:string; severity?:string; ip?:string; userAgent?:string; metadata?:any;
}) {
  await prisma.securityEvent.create({data:{
    userId:data.userId,action:data.action,severity:data.severity ?? "INFO",
    ip:data.ip,userAgent:data.userAgent,metadata:data.metadata
  }}).catch(()=>{});
}
export async function revokeAllSessions(userId:string) {
  await prisma.user.update({where:{id:userId},data:{sessionVersion:{increment:1}}});
  await prisma.sessionDevice.updateMany({where:{userId,revokedAt:null},data:{revokedAt:new Date()}});
  await logActivity({actorId:userId,action:"security.sessions.revoke_all",targetType:"User",targetId:userId});
}
