import { unstable_cache } from "next/cache";
import { prisma } from "@/lib/prisma";

/**
 * Platform-wide "sold" counter and average rating, shown as a trust badge
 * (e.g. "+1,240 رقم تم بيعه"). Cached for 5 minutes — exact-to-the-second
 * accuracy doesn't matter for a badge, and it saves a COUNT(*) query on
 * every page view.
 */
export const getTrustStats = unstable_cache(
  async () => {
    const [soldCount, ratingAgg] = await Promise.all([
      prisma.orderItem.count({
        where: { order: { status: { in: ["PROCESSING", "COMPLETED"] } } },
      }),
      prisma.review.aggregate({ _avg: { rating: true }, _count: true }),
    ]);

    return {
      soldCount,
      averageRating: ratingAgg._avg.rating ?? 0,
      reviewCount: ratingAgg._count,
    };
  },
  ["trust-stats"],
  { revalidate: 300, tags: ["trust-stats"] }
);

/**
 * Recent purchases (customer name partly masked) for the "فلان اشترى رقم
 * من كذا" social-proof toast. Cached briefly so a burst of page loads
 * doesn't hammer the DB.
 */
export const getRecentPurchases = unstable_cache(
  async (limit = 10) => {
    const items = await prisma.orderItem.findMany({
      where: { order: { status: { in: ["PROCESSING", "COMPLETED"] } } },
      orderBy: { order: { createdAt: "desc" } },
      take: limit,
      select: {
        order: { select: { customerName: true, createdAt: true } },
        number: { select: { country: { select: { name: true, flag: true } }, type: true } },
      },
    });

    return items.map((i) => ({
      // Mask the name for privacy: "محمد ..." -> "محمد."
      maskedName: maskName(i.order.customerName),
      countryName: i.number.country.name,
      countryFlag: i.number.country.flag,
      at: i.order.createdAt,
    }));
  },
  ["recent-purchases"],
  { revalidate: 60, tags: ["recent-purchases"] }
);

function maskName(name: string): string {
  const first = name.trim().split(/\s+/)[0] ?? name;
  return first.length <= 2 ? `${first}.` : `${first.slice(0, 2)}${"*".repeat(Math.min(first.length - 2, 4))}`;
}
