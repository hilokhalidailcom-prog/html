import * as Sentry from "@sentry/nextjs";

/**
 * Reports an unexpected error to Sentry (if configured) and logs it locally.
 * Use this in `catch` blocks for anything that's a genuine bug/outage —
 * not for expected user-facing cases like INSUFFICIENT_BALANCE, which are
 * normal control flow and shouldn't spam the error dashboard.
 */
export function reportError(context: string, err: unknown) {
  console.error(`[${context}]`, err);
  if (process.env.NEXT_PUBLIC_SENTRY_DSN) {
    Sentry.captureException(err, { tags: { context } });
  }
}
