import { prisma } from "@/lib/prisma";

async function sendEmail(userId: string, title: string, body: string) {
  const key = process.env.RESEND_API_KEY;
  const from = process.env.EMAIL_FROM;
  if (!key || !from) throw new Error("EMAIL_PROVIDER_NOT_CONFIGURED");
  const user = await prisma.user.findUnique({ where: { id: userId }, select: { email: true } });
  if (!user) throw new Error("USER_NOT_FOUND");
  const r = await fetch("https://api.resend.com/emails", {
    method: "POST",
    headers: { "Authorization": `Bearer ${key}`, "Content-Type": "application/json" },
    body: JSON.stringify({ from, to: user.email, subject: title, text: body }),
  });
  if (!r.ok) throw new Error(`EMAIL_${r.status}`);
}

export async function dispatchPendingNotifications(limit = 50) {
  const rows = await prisma.notificationDelivery.findMany({
    where: { status: "PENDING" }, include: { notification: true }, take: limit,
  });
  let sent = 0;
  for (const d of rows) {
    try {
      if (d.channel === "WEBSITE") {
        await prisma.notificationDelivery.update({ where: { id: d.id }, data: { status: "SENT", sentAt: new Date() } });
        sent++;
        continue;
      }
      if (d.channel === "EMAIL") await sendEmail(d.notification.userId, d.notification.title, d.notification.body);
      await prisma.notificationDelivery.update({ where: { id: d.id }, data: { status: "SENT", sentAt: new Date() } });
      sent++;
    } catch (e) {
      await prisma.notificationDelivery.update({ where: { id: d.id }, data: { status: "FAILED", error: String(e) } });
    }
  }
  return sent;
}
