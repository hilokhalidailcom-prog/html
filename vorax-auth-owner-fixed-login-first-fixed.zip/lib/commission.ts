import { prisma } from "@/lib/prisma";

export async function resolveCommissionPercent(number: {
  merchantId: string | null;
  categoryId: string | null;
  merchant?: { commissionPercent: number } | null;
}) {
  if (number.merchant?.commissionPercent != null) return number.merchant.commissionPercent;
  if (number.merchantId) {
    const merchantRule = await prisma.commissionRule.findFirst({
      where: { scope: "MERCHANT", merchantId: number.merchantId, active: true },
      orderBy: { updatedAt: "desc" },
    });
    if (merchantRule) return merchantRule.percent;
  }
  if (number.categoryId) {
    const categoryRule = await prisma.commissionRule.findFirst({
      where: { scope: "CATEGORY", categoryId: number.categoryId, active: true },
      orderBy: { updatedAt: "desc" },
    });
    if (categoryRule) return categoryRule.percent;
  }
  const global = await prisma.commissionRule.findFirst({
    where: { scope: "GLOBAL", active: true },
    orderBy: { updatedAt: "desc" },
  });
  return global?.percent ?? 10;
}
