import { randomBytes } from "crypto";

/** URL-safe random token, plus its expiry timestamp. */
export function generateToken(ttlMs: number) {
  const token = randomBytes(32).toString("base64url");
  const expires = new Date(Date.now() + ttlMs);
  return { token, expires };
}

export const VERIFICATION_TTL_MS = 24 * 60 * 60 * 1000; // 24h
export const RESET_TTL_MS = 60 * 60 * 1000; // 1h
