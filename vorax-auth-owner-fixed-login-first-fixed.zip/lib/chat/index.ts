import { prisma } from "@/lib/prisma";

export async function canAccessChat(userId: string, chatId: string) {
  const chat = await prisma.merchantChat.findUnique({
    where: { id: chatId },
    include: { merchant: { select: { id: true, userId: true, storeName: true } } },
  });
  if (!chat) return null;
  if (chat.customerId !== userId && chat.merchant.userId !== userId) return null;
  return chat;
}

/**
 * The VORAX chat is web-only. Messages are persisted in the platform and
 * are never relayed to Telegram or any external messenger.
 */
export async function appendChatMessage(
  chatId: string,
  senderUserId: string,
  content: string,
  senderRole: "CUSTOMER" | "MERCHANT" | "SYSTEM"
) {
  const message = await prisma.$transaction(async (tx) => {
    const created = await tx.merchantChatMessage.create({
      data: { chatId, senderUserId, senderRole, content: content.trim() },
    });
    await tx.merchantChat.update({
      where: { id: chatId },
      data: { lastMessageAt: new Date() },
    });
    return created;
  });
  return message;
}
