import { prisma } from "@/lib/prisma";

export async function createNotification(data:{
  userId:string; title:string; body:string; type:string; metadata?:any;
  channels?: ("WEBSITE"|"EMAIL")[];
}) {
  const channels: ("WEBSITE"|"EMAIL")[] = data.channels?.length ? data.channels : ["WEBSITE"];
  const n = await prisma.notification.create({data:{
    userId:data.userId,title:data.title,body:data.body,type:data.type,metadata:data.metadata,
    channel:"WEBSITE",
    deliveries:{create:channels.map(channel=>({channel}))}
  }});
  return n;
}

export async function markNotificationRead(userId:string,id:string) {
  return prisma.notification.updateMany({where:{id,userId},data:{readAt:new Date()}});
}
