// VORAX virtual currency — "Tikoun"
export const CURRENCY_NAME = "تيكون";
export const CURRENCY_SYMBOL = "£";

export function formatTikoun(amount: number): string {
  return `${amount.toLocaleString("ar-MA")} ${CURRENCY_SYMBOL}`;
}

// شحن الرصيد يتم عبر طلب من داخل المنصة، ثم يراجعه المالك ويعتمده من لوحة الإدارة.
