import NextAuth from "next-auth";
import Credentials from "next-auth/providers/credentials";
import Google from "next-auth/providers/google";
import bcrypt from "bcryptjs";
import crypto from "crypto";
import { prisma } from "@/lib/prisma";
import { checkRateLimit, getClientIp } from "@/lib/rateLimit";

const googleProvider =
  process.env.GOOGLE_CLIENT_ID && process.env.GOOGLE_CLIENT_SECRET
    ? [Google({ clientId: process.env.GOOGLE_CLIENT_ID, clientSecret: process.env.GOOGLE_CLIENT_SECRET })]
    : [];

export const { handlers, signIn, signOut, auth } = NextAuth({
  trustHost: process.env.AUTH_TRUST_HOST !== "false",
  secret: process.env.AUTH_SECRET || process.env.NEXTAUTH_SECRET,
  session: { strategy: "jwt" },
  pages: { signIn: "/login" },
  providers: [
    ...googleProvider,
    Credentials({
      name: "credentials",
      credentials: {
        email: { label: "Email", type: "email" },
        password: { label: "Password", type: "password" },
        otp: { label: "2FA Code", type: "text" },
      },
      // `request` is the incoming Request — NextAuth v5 passes it through,
      // which is what lets us rate-limit and log by real client IP.
      async authorize(credentials, request) {
        if (!credentials?.email || !credentials?.password) return null;

        const email = String(credentials.email).toLowerCase();
        const ip = getClientIp(request as unknown as Request);

        // 5 attempts / 10 minutes per IP+email pair — blocks brute force
        // without locking out everyone behind a shared office IP.
        const limit = checkRateLimit(`login:${ip}:${email}`, 5, 10 * 60_000);
        if (!limit.allowed) {
          throw new Error("TOO_MANY_ATTEMPTS");
        }

        let user = await prisma.user.findUnique({ where: { email } });

        // First-login bootstrap for the VORAX owner account.
        // The credentials are only used server-side; the client never receives them.
        const ownerEmail = (process.env.OWNER_EMAIL || "").trim().toLowerCase();
        const ownerBootstrapPassword = process.env.OWNER_PASSWORD || "";
        if (!user && ownerEmail && ownerBootstrapPassword && email === ownerEmail) {
          const ownerHash = await bcrypt.hash(ownerBootstrapPassword, 12);
          user = await prisma.user.create({
            data: {
              name: "VORAX Owner",
              email: ownerEmail,
              passwordHash: ownerHash,
              role: "ADMIN",
              status: "ACTIVE",
              emailVerified: new Date(),
              balance: 0,
            },
          });
        }

        const logAttempt = (success: boolean) =>
          prisma.loginEvent
            .create({ data: { userId: user?.id, email, ip, success } })
            .catch(() => {}); // never let logging break auth

        if (!user) {
          await logAttempt(false);
          return null;
        }
        if (user.status === "DISABLED") {
          await logAttempt(false);
          throw new Error("ACCOUNT_DISABLED");
        }
        if (!user.emailVerified) {
          await logAttempt(false);
          throw new Error("EMAIL_NOT_VERIFIED");
        }

        const valid = await bcrypt.compare(String(credentials.password), user.passwordHash);
        await logAttempt(valid);
        if (!valid) return null;
        if (user.twoFactorEnabled) {
          const otp = String((credentials as any).otp ?? "");
          if (!otp) throw new Error("TWO_FACTOR_REQUIRED");
          const { authenticator } = await import("otplib");
          if (!authenticator.check(otp, user.twoFactorSecret ?? "")) throw new Error("INVALID_2FA");
        }

        return { id: user.id, name: user.name, email: user.email, role: user.role, permissions: user.permissions, sessionVersion: user.sessionVersion };
      },
    }),
  ],
  callbacks: {
    async redirect({ url, baseUrl }) {
      try {
        const target = new URL(url, baseUrl);
        const base = new URL(baseUrl);
        if (target.origin === base.origin) return target.toString();
      } catch {}
      return `${baseUrl}/dashboard`;
    },
    // Google only confirms "this person owns this email" — it doesn't know
    // about our User table. On first Google sign-in for an unseen email we
    // create a normal USER account (never ADMIN/MERCHANT/DEVELOPER — those
    // roles must still be granted explicitly inside the app). If the email
    // already exists (e.g. the owner account made by the seed script), this
    // just links the Google login to that row — its role is untouched.
    async signIn({ user, account }) {
      if (account?.provider !== "google") return true;
      if (!user.email) return false;

      const email = user.email.toLowerCase();
      const existing = await prisma.user.findUnique({ where: { email } });

      if (!existing) {
        // passwordHash is a required column; a Google-only account can never
        // sign in with a password, so this hash is stored as an unusable placeholder.
        const unusablePassword = await bcrypt.hash(crypto.randomBytes(32).toString("hex"), 12);
        await prisma.user.create({
          data: {
            name: user.name ?? email,
            email,
            passwordHash: unusablePassword,
            role: "USER",
            status: "ACTIVE",
            emailVerified: new Date(),
            balance: 0,
          },
        });
      } else if (existing.status === "DISABLED") {
        return false;
      }

      return true;
    },
    // Persist role onto the JWT so we don't hit the DB on every request
    async jwt({ token, user, account }) {
      if (account?.provider === "google" && token.email) {
        // `user` here reflects Google's profile, not our DB row — look up
        // the real user so role/permissions/sessionVersion match what the
        // rest of the app (and the session-revocation check below) expects.
        const dbUser = await prisma.user.findUnique({ where: { email: String(token.email).toLowerCase() } });
        if (dbUser) {
          token.userId = dbUser.id;
          token.role = dbUser.role;
          token.permissions = dbUser.permissions ?? [];
          token.sessionVersion = dbUser.sessionVersion ?? 0;
        }
      } else if (user) {
        token.role = (user as any).role; token.permissions = (user as any).permissions ?? []; token.sessionVersion = (user as any).sessionVersion ?? 0; token.userId = (user as any).id;
      }
      if (token.userId) {
        const current = await prisma.user.findUnique({where:{id:String(token.userId)},select:{sessionVersion:true,status:true}});
        if (!current || current.status === "DISABLED" || current.sessionVersion !== Number(token.sessionVersion ?? 0)) token.error = "SESSION_REVOKED";
      }
      return token;
    },
    async session({ session, token }) {
      if (token.error) return { ...session, user: undefined as any };
      if (session.user) { (session.user as any).role = token.role; (session.user as any).permissions = token.permissions ?? []; (session.user as any).id = token.userId; (session.user as any).authError = token.error; }
      return session;
    },
  },
});
