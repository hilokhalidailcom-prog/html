import { prisma } from "@/lib/prisma";

export async function recordBalanceTransaction(data: {
  userId: string; amount: number; type: string; referenceId?: string; description?: string;
}) { return prisma.balanceTransaction.create({ data }); }

export async function merchantLedgerSummary(merchantId: string) {
  const sales = await prisma.ledgerEntry.aggregate({where:{merchantId,type:"SALE"},_sum:{netAmount:true}});
  const withdrawals = await prisma.withdrawalRequest.aggregate({where:{merchantId,status:{in:["APPROVED"]}},_sum:{amount:true}});
  const pendingRows = await prisma.ledgerEntry.findMany({where:{merchantId,type:"SALE",availableAt:null},select:{netAmount:true}});
  const grossSales=sales._sum.netAmount??0;
  const withdrawn=withdrawals._sum.amount??0;
  const pending=pendingRows.reduce((s:number,e:{netAmount:number})=>s+e.netAmount,0);
  return {available:Math.max(0,grossSales-withdrawn-pending),pending,withdrawn};
}
