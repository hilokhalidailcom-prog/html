// Same-origin check for state-changing requests (POST/PATCH/PUT/DELETE).
// NextAuth's JWT session cookie is httpOnly + sameSite=lax by default,
// which already blocks classic CSRF from a foreign page's form submit —
// this Origin check adds a second layer against tools/scripts that ignore
// cookie sameSite (e.g. fetch with credentials from a malicious site
// running in a context that carries the cookie, or misconfigured proxies).
export function isTrustedOrigin(req: Request): boolean {
  const origin = req.headers.get("origin");
  const allowed = process.env.NEXT_PUBLIC_APP_URL ?? "http://localhost:3000";

  // Some clients (native apps, curl, server-to-server) omit Origin — only
  // enforce the check when the header is present, and fall back to Referer.
  if (origin) return origin === allowed;

  const referer = req.headers.get("referer");
  if (referer) return referer.startsWith(allowed);

  return true;
}
