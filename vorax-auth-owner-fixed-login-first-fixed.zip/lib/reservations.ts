import { prisma } from "@/lib/prisma";

export const RESERVATION_MINUTES = 15;

export async function releaseExpiredReservations() {
  const now = new Date();
  const expired = await prisma.reservation.findMany({ where: { expiresAt: { lt: now }, releasedAt: null }, select: { id:true, numberId:true } });
  for (const r of expired) {
    await prisma.$transaction(async tx => {
      const reservation = await tx.reservation.findUnique({ where:{id:r.id} });
      if (!reservation || reservation.releasedAt || reservation.expiresAt >= now) return;
      await tx.reservation.update({ where:{id:r.id}, data:{releasedAt:now} });
      await tx.phoneNumber.updateMany({ where:{id:r.numberId,status:"RESERVED"}, data:{status:"AVAILABLE"} });
    }).catch(()=>{});
  }
  return expired.length;
}

export async function reserveNumbers(userId: string, numberIds: string[]) {
  const expiresAt = new Date(Date.now() + RESERVATION_MINUTES*60_000);
  return prisma.$transaction(async tx => {
    const numbers = await tx.phoneNumber.findMany({
      where:{id:{in:numberIds},status:"AVAILABLE",approvalStatus:"APPROVED"},
    });
    if (numbers.length !== numberIds.length) throw new Error("NUMBERS_UNAVAILABLE");
    await tx.phoneNumber.updateMany({where:{id:{in:numberIds},status:"AVAILABLE"},data:{status:"RESERVED"}});
    return Promise.all(numberIds.map(numberId=>tx.reservation.create({data:{numberId,userId,expiresAt}})));
  });
}
