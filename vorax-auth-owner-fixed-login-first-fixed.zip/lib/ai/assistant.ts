import { prisma } from "@/lib/prisma";
import {
  searchProducts,
  getProduct,
  getCategories,
  getInventory,
  getMerchant,
  getStoreInfo,
  getUserOrders,
} from "@/lib/ai/tools";

const MODEL = process.env.VORAX_AI_MODEL || process.env.OPENAI_MODEL || "gemini-2.0-flash";
const OPENAI_URL = (process.env.VORAX_AI_BASE_URL || process.env.OPENAI_BASE_URL || "http://localhost:3000/v1").replace(/\/$/, "");
const AI_API_KEY = process.env.VORAX_AI_API_KEY || process.env.OPENAI_API_KEY;
const MAX_TOOL_ROUNDS = 5;

const SYSTEM_PROMPT = `You are VORAX AI, the marketplace assistant for VORAX.
The actual sellable unit is PhoneNumber and the currency is Tikoun (£).
You have no database access. You may only use the tools supplied by the application.
Never invent products, phone numbers, prices, stock, merchants, ratings, discounts or orders.
If data is unavailable, say so clearly and offer the closest real results.
For product searches, only rely on tool results marked as available/approved by the backend.
Do not claim a purchase was made. You may help a user find and compare items, but purchasing requires a separate explicit confirmation flow.
Keep answers concise and useful. When results exist, mention real phone numbers and prices from the tool output.
If the user asks for their orders, use getUserOrders and never infer private order information.
Answer in the user's language when possible.`;

const toolDefinitions = [
  {
    type: "function",
    function: {
      name: "searchProducts",
      description: "Search real available and approved PhoneNumbers in VORAX.",
      parameters: {
        type: "object",
        properties: {
          query: { type: "string", description: "Phone number, description, keyword, or search phrase." },
          countryId: { type: "string" },
          categoryId: { type: "string" },
          maxPrice: { type: "number", description: "Maximum price in Tikoun (£)." },
          minPrice: { type: "number", description: "Minimum price in Tikoun (£)." },
          sort: { type: "string", enum: ["newest", "cheapest", "expensive", "featured", "rating"] },
          country: { type: "string", description: "Country name or ISO code, if specified by the user." },
          category: { type: "string", description: "Category name or slug, if specified by the user." },
          minRating: { type: "number", minimum: 0, maximum: 5 },
          limit: { type: "number", minimum: 1, maximum: 20 },
        },
        additionalProperties: false,
      },
    },
  },
  {
    type: "function",
    function: {
      name: "getProduct",
      description: "Get one real approved/available PhoneNumber by id.",
      parameters: { type: "object", properties: { id: { type: "string" } }, required: ["id"], additionalProperties: false },
    },
  },
  {
    type: "function",
    function: {
      name: "getCategories",
      description: "List active VORAX product categories.",
      parameters: { type: "object", properties: {}, additionalProperties: false },
    },
  },
  {
    type: "function",
    function: {
      name: "getInventory",
      description: "Get the current available approved PhoneNumber count for a merchant.",
      parameters: { type: "object", properties: { merchantId: { type: "string" } }, required: ["merchantId"], additionalProperties: false },
    },
  },
  {
    type: "function",
    function: {
      name: "getMerchant",
      description: "Get public information for an active merchant by id.",
      parameters: { type: "object", properties: { id: { type: "string" } }, required: ["id"], additionalProperties: false },
    },
  },
  {
    type: "function",
    function: {
      name: "getStoreInfo",
      description: "Get public information for an active merchant store by slug.",
      parameters: { type: "object", properties: { slug: { type: "string" } }, required: ["slug"], additionalProperties: false },
    },
  },
  {
    type: "function",
    function: {
      name: "getUserOrders",
      description: "Get the authenticated user's recent orders. Requires the logged-in user.",
      parameters: { type: "object", properties: {}, additionalProperties: false },
    },
  },
] as const;

function safeJson(value: unknown) {
  return JSON.stringify(value, (_key, v) => (typeof v === "bigint" ? Number(v) : v));
}

export async function executeAITool(name: string, args: any, userId?: string) {
  switch (name) {
    case "searchProducts": return searchProducts(args);
    case "getProduct": return getProduct(String(args.id));
    case "getCategories": return getCategories();
    case "getInventory": return getInventory(String(args.merchantId));
    case "getMerchant": return getMerchant(String(args.id));
    case "getStoreInfo": return getStoreInfo(String(args.slug));
    case "getUserOrders":
      if (!userId) throw new Error("AUTH_REQUIRED");
      return getUserOrders(userId);
    default: throw new Error("TOOL_NOT_ALLOWED");
  }
}

async function deterministicFallback(message: string) {
  const price = message.match(/(?:under|less than|below|أقل من|تحت)\s*(\d+)/i)?.[1];
  const data = await searchProducts({
    query: message.replace(/(?:under|less than|below|أقل من|تحت)\s*\d+/i, "").trim(),
    maxPrice: price ? Number(price) : undefined,
    limit: 8,
  });
  return {
    answer: data.length
      ? "وجدت نتائج حقيقية مطابقة من مخزون VORAX."
      : "لم أجد منتجًا مطابقًا حاليًا، لكن يمكنني عرض أقرب النتائج.",
    results: data,
    toolEvents: [{ name: "searchProducts", content: safeJson(data) }],
    provider: "fallback",
  };
}

export async function marketplaceAssistant(
  message: string,
  userId?: string,
  conversationId?: string,
) {
  if (!AI_API_KEY) return deterministicFallback(message);

  const history = conversationId && userId
    ? await prisma.aIMessage.findMany({
        where: { conversationId, conversation: { userId } },
        orderBy: { createdAt: "asc" },
        take: 20,
      })
    : [];

  const messages: any[] = [
    { role: "system", content: SYSTEM_PROMPT },
    ...history.filter((m: { role: string }) => m.role === "user" || m.role === "assistant").map((m: { role: string; content: string }) => ({ role: m.role, content: m.content })),
    { role: "user", content: message },
  ];

  const toolEvents: { name: string; content: string }[] = [];
  let finalText = "";
  let latestResults: any[] = [];

  for (let round = 0; round < MAX_TOOL_ROUNDS; round++) {
    const response = await fetch(`${OPENAI_URL}/chat/completions`, {
      method: "POST",
      headers: {
        "content-type": "application/json",
        authorization: `Bearer ${AI_API_KEY}`,
      },
      body: JSON.stringify({
        model: MODEL,
        temperature: 0.2,
        messages,
        tools: toolDefinitions,
        tool_choice: "auto",
      }),
    });

    if (!response.ok) {
      const body = await response.text().catch(() => "");
      throw new Error(`AI_PROVIDER_ERROR:${response.status}:${body.slice(0, 300)}`);
    }

    const payload = await response.json();
    const choice = payload?.choices?.[0];
    const assistantMessage = choice?.message;
    if (!assistantMessage) throw new Error("AI_EMPTY_RESPONSE");

    messages.push(assistantMessage);

    if (!assistantMessage.tool_calls?.length) {
      finalText = String(assistantMessage.content || "لم أستطع توليد إجابة حاليًا.");
      break;
    }

    for (const call of assistantMessage.tool_calls) {
      if (call.type !== "function") continue;
      const name = String(call.function?.name || "");
      let args: any = {};
      try { args = JSON.parse(call.function?.arguments || "{}"); }
      catch { args = {}; }

      try {
        const result = await executeAITool(name, args, userId);
        if (Array.isArray(result)) latestResults = result;
        toolEvents.push({ name, content: safeJson(result) });
        messages.push({ role: "tool", tool_call_id: call.id, content: safeJson(result).slice(0, 12000) });
      } catch (error) {
        const code = error instanceof Error ? error.message : "TOOL_ERROR";
        const toolError = safeJson({ error: code === "AUTH_REQUIRED" ? "AUTH_REQUIRED" : "TOOL_FAILED" });
        toolEvents.push({ name, content: toolError });
        messages.push({ role: "tool", tool_call_id: call.id, content: toolError });
      }
    }
  }

  if (!finalText) finalText = latestResults.length
    ? "وجدت نتائج حقيقية من مخزون VORAX."
    : "لم أجد نتائج مطابقة حاليًا.";

  return {
    answer: finalText,
    results: latestResults,
    toolEvents,
    provider: "gemini-proxy",
    model: MODEL,
  };
}
