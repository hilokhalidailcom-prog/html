import { prisma } from "@/lib/prisma";

const publicWhere = {
  status: "AVAILABLE" as const,
  approvalStatus: "APPROVED" as const,
};

export async function searchProducts(args:{query?:string;countryId?:string;country?:string;categoryId?:string;category?:string;maxPrice?:number;minPrice?:number;minRating?:number;limit?:number;sort?:"newest"|"cheapest"|"expensive"|"featured"|"rating"}) {
  const q = args.query?.trim();
  const country = args.country?.trim();
  const category = args.category?.trim();
  const limit = Math.min(args.limit ?? 10, 20);
  const countryFilter = args.countryId
    ? { countryId: args.countryId }
    : country
      ? { country: { OR: [{ id: country }, { code: country.toUpperCase() }, { name: { contains: country, mode: "insensitive" } }] } }
      : {};
  const categoryFilter = args.categoryId
    ? { categoryId: args.categoryId }
    : category
      ? { category: { OR: [{ id: category }, { slug: category.toLowerCase() }, { name: { contains: category, mode: "insensitive" } }] } }
      : {};
  const where:any = {
    ...publicWhere,
    ...countryFilter,
    ...categoryFilter,
    ...(args.maxPrice != null || args.minPrice != null ? { price: { ...(args.minPrice != null ? { gte: args.minPrice } : {}), ...(args.maxPrice != null ? { lte: args.maxPrice } : {}) } } : {}),
    ...(q ? { OR: [{ phone: { contains: q, mode: "insensitive" } }, { description: { contains: q, mode: "insensitive" } }] } : {}),
  };
  const candidates = await prisma.phoneNumber.findMany({
    where,
    include: {
      country: true,
      category: true,
      merchant: { select: { id: true, storeName: true, slug: true, verified: true } },
      reviews: { select: { rating: true } },
    },
    take: args.sort === "rating" ? 100 : limit,
    orderBy: args.sort === "cheapest" ? { price: "asc" } : args.sort === "expensive" ? { price: "desc" } : args.sort === "featured" ? { featured: "desc" } : { createdAt: "desc" },
  });
  const withRating = candidates.map((item:any) => {
    const ratings = item.reviews ?? [];
    const averageRating = ratings.length ? ratings.reduce((sum:number, r:any) => sum + r.rating, 0) / ratings.length : 0;
    return { ...item, averageRating: Number(averageRating.toFixed(2)), reviewCount: ratings.length };
  });
  const filtered = args.minRating != null ? withRating.filter((item:any) => item.averageRating >= Number(args.minRating)) : withRating;
  if (args.sort === "rating") filtered.sort((a:any,b:any) => b.averageRating - a.averageRating || a.price - b.price);
  return filtered.slice(0, limit).map(({ reviews, ...item }:any) => item);
}
export async function getProduct(id:string) {
  return prisma.phoneNumber.findFirst({where:{id,...publicWhere},include:{country:true,category:true,merchant:true}});
}
export async function getCategories() {
  return prisma.category.findMany({where:{active:true},orderBy:{name:"asc"}});
}
export async function getInventory(merchantId:string) {
  return prisma.phoneNumber.count({where:{merchantId,status:"AVAILABLE",approvalStatus:"APPROVED"}});
}
export async function getMerchant(id:string) {
  return prisma.merchant.findUnique({where:{id,status:"ACTIVE"},include:{category:true}});
}
export async function getStoreInfo(slug:string) {
  return prisma.merchant.findUnique({where:{slug,status:"ACTIVE"},include:{category:true}});
}
export async function getUserOrders(userId:string) {
  return prisma.order.findMany({where:{userId},include:{items:{include:{number:true}}},orderBy:{createdAt:"desc"},take:20});
}
