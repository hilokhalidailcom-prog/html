import { prisma } from "@/lib/prisma";

export async function productApprovalRequired() {
  const setting = await prisma.platformSetting.findUnique({ where: { key: "product_approval_required" } });
  return setting ? Boolean(setting.value) : false;
}

export const publicNumberWhere = (extra: Record<string, unknown> = {}) => ({
  status: "AVAILABLE" as const,
  approvalStatus: "APPROVED" as const,
  ...extra,
});

export async function merchantRating(merchantId: string) {
  const agg = await prisma.merchantReview.aggregate({ where: { merchantId }, _avg: { rating: true }, _count: { _all: true } });
  return { average: agg._avg.rating ?? 0, count: agg._count._all };
}
