import { randomBytes } from "crypto";
import { prisma } from "@/lib/prisma";

// Both sides get this many Tikoun (£) once the referred user's first
// order goes through. Tune freely — it's read from one place.
export const REFERRAL_REWARD = 20;

function randomCode(): string {
  // 6 uppercase alphanumeric chars, no ambiguous 0/O/1/I — easy to read
  // aloud or paste into a WhatsApp message.
  const alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
  const bytes = randomBytes(6);
  return Array.from(bytes, (b) => alphabet[b % alphabet.length]).join("");
}

/** Every user gets exactly one code, created lazily on first request. */
export async function getOrCreateReferralCode(userId: string) {
  const existing = await prisma.referralCode.findUnique({ where: { userId } });
  if (existing) return existing;

  // Retry on the rare collision — code is globally unique.
  for (let attempt = 0; attempt < 5; attempt++) {
    try {
      return await prisma.referralCode.create({
        data: { userId, code: randomCode() },
      });
    } catch (err: any) {
      if (err?.code !== "P2002" || attempt === 4) throw err;
    }
  }
  throw new Error("REFERRAL_CODE_GENERATION_FAILED");
}

/**
 * Called right after a new user registers, if they signed up with a
 * ?ref=CODE link. Records the link as PENDING — no credit yet, that
 * happens on their first completed order (see rewardReferralIfPending).
 * Silently no-ops on an invalid code or self-referral so it never blocks
 * registration.
 */
export async function applyReferralCode(newUserId: string, rawCode: string) {
  const code = rawCode.trim().toUpperCase();
  if (!code) return;

  const referralCode = await prisma.referralCode.findUnique({ where: { code } });
  if (!referralCode || referralCode.userId === newUserId) return;

  await prisma.referralUse.create({
    data: {
      referralCodeId: referralCode.id,
      referrerId: referralCode.userId,
      referredUserId: newUserId,
    },
  }).catch(() => {}); // unique constraint (already referred) -> ignore
}

/**
 * Call after a user's order is successfully placed. If they were referred
 * and haven't been rewarded yet, credits both wallets atomically.
 */
export async function rewardReferralIfPending(referredUserId: string) {
  const use = await prisma.referralUse.findUnique({ where: { referredUserId } });
  if (!use || use.status === "REWARDED") return;

  await prisma.$transaction([
    prisma.referralUse.update({
      where: { id: use.id },
      data: { status: "REWARDED", rewardAmount: REFERRAL_REWARD, rewardedAt: new Date() },
    }),
    prisma.user.update({
      where: { id: use.referrerId },
      data: { balance: { increment: REFERRAL_REWARD } },
    }),
    prisma.user.update({
      where: { id: referredUserId },
      data: { balance: { increment: REFERRAL_REWARD } },
    }),
  ]);
}
