import { prisma } from "@/lib/prisma";
import { getOwnMerchant } from "@/lib/permissions";

/**
 * Returns the chat if `userId` is allowed to see it — either the customer
 * who opened it, the owner of the merchant it belongs to, or a platform
 * ADMIN doing a review (owner can review any chat).
 * Returns null both when the chat doesn't exist and when the user has no
 * access to it, so callers can't use this to probe which chat ids exist.
 */
export async function canAccessChat(userId: string, chatId: string) {
  const chat = await prisma.merchantChat.findUnique({ where: { id: chatId } });
  if (!chat) return null;

  if (chat.customerId === userId) return chat;

  const merchant = await getOwnMerchant(userId);
  if (merchant && chat.merchantId === merchant.id) return chat;

  const user = await prisma.user.findUnique({ where: { id: userId }, select: { role: true } });
  if (user?.role === "ADMIN") return chat;

  return null;
}

/**
 * Appends a message to a chat and bumps `lastMessageAt` so chat lists can
 * sort by recent activity without a separate query.
 */
export async function appendChatMessage(
  chatId: string,
  senderUserId: string,
  content: string,
  senderRole: "CUSTOMER" | "MERCHANT" | "SYSTEM",
) {
  const [message] = await prisma.$transaction([
    prisma.merchantChatMessage.create({
      data: { chatId, senderUserId, content, senderRole },
    }),
    prisma.merchantChat.update({
      where: { id: chatId },
      data: { lastMessageAt: new Date() },
    }),
  ]);
  return message;
}
