/** Production-safe environment validation. Never logs secret values. */
const isProd = process.env.NODE_ENV === 'production';

export function validateEnvironment() {
  const required = ['DATABASE_URL', 'NEXT_PUBLIC_APP_URL'];
  const missing = required.filter((key) => !process.env[key]);
  if (!process.env.AUTH_SECRET && !process.env.NEXTAUTH_SECRET) missing.push('AUTH_SECRET');

  if (isProd) {
    if (process.env.RESEND_API_KEY && !process.env.EMAIL_FROM) {
      missing.push('EMAIL_FROM');
    }
  }

  if (missing.length) {
    throw new Error(`Missing required environment variables: ${missing.join(', ')}`);
  }

  const appUrl = process.env.NEXT_PUBLIC_APP_URL!;
  if (isProd && !appUrl.startsWith('https://')) {
    throw new Error('NEXT_PUBLIC_APP_URL must use HTTPS in production');
  }

  return { appUrl };
}
