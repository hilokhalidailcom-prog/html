import { prisma } from "@/lib/prisma";

type ValidationResult =
  | { ok: true; promoCodeId: string; discount: number }
  | { ok: false; error: string };

/**
 * Validates a promo code against the current cart subtotal and returns
 * the Tikoun (£) discount to apply. Does NOT increment usedCount — that
 * happens inside the checkout transaction so a code can't be
 * double-spent under concurrent requests.
 */
export async function validatePromoCode(rawCode: string, subtotal: number): Promise<ValidationResult> {
  const code = rawCode.trim().toUpperCase();
  const promo = await prisma.promoCode.findUnique({ where: { code } });

  if (!promo || !promo.active) {
    return { ok: false, error: "الكود غير صحيح" };
  }
  if (promo.expiresAt && promo.expiresAt < new Date()) {
    return { ok: false, error: "الكود منتهي الصلاحية" };
  }
  if (promo.maxUses !== null && promo.usedCount >= promo.maxUses) {
    return { ok: false, error: "الكود وصل للحد الأقصى من الاستعمال" };
  }
  if (subtotal < promo.minOrder) {
    return { ok: false, error: `هاذ الكود صالح فقط لطلبات أكثر من ${promo.minOrder} £` };
  }

  const discount =
    promo.discountType === "PERCENT"
      ? Math.floor((subtotal * promo.amount) / 100)
      : Math.min(promo.amount, subtotal);

  return { ok: true, promoCodeId: promo.id, discount };
}
