// Uses Resend's REST API directly (no SDK needed) — add RESEND_API_KEY and
// EMAIL_FROM to your .env. Swap the implementation of `sendEmail` if you
// prefer another provider (Postmark, SES, etc.) — every caller in this
// codebase only depends on this one function's signature.

interface SendEmailInput {
  to: string;
  subject: string;
  html: string;
}

export async function sendEmail({ to, subject, html }: SendEmailInput): Promise<void> {
  const apiKey = process.env.RESEND_API_KEY;
  const from = process.env.EMAIL_FROM ?? "VORAX <no-reply@vorax.example>";

  if (!apiKey) {
    // Fail loud in production, but don't crash local dev if the key isn't set yet.
    console.warn(`[email] RESEND_API_KEY missing — skipped email to ${to}: "${subject}"`);
    return;
  }

  const res = await fetch("https://api.resend.com/emails", {
    method: "POST",
    headers: {
      Authorization: `Bearer ${apiKey}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({ from, to, subject, html }),
  });

  if (!res.ok) {
    const body = await res.text().catch(() => "");
    console.error(`[email] send failed (${res.status}): ${body}`);
  }
}

const BRAND_WRAPPER = (title: string, bodyHtml: string) => `
  <div style="font-family: -apple-system, sans-serif; background:#0a0a0a; padding:32px; color:#e5e5e5;">
    <div style="max-width:480px; margin:0 auto; background:#171717; border-radius:16px; padding:32px; border:1px solid #eab30833;">
      <h1 style="color:#eab308; font-size:22px; margin:0 0 16px;">VORAX</h1>
      <h2 style="color:#fff; font-size:18px; margin:0 0 12px;">${title}</h2>
      <div style="color:#d4d4d4; font-size:14px; line-height:1.7;">${bodyHtml}</div>
    </div>
  </div>`;

export function verificationEmail(link: string) {
  return BRAND_WRAPPER(
    "أكّد بريدك الإلكتروني",
    `<p>مرحبًا بك في VORAX. اضغط الزر لتفعيل حسابك (صالح لمدة 24 ساعة):</p>
     <a href="${link}" style="display:inline-block; margin-top:12px; background:#eab308; color:#000; padding:12px 24px; border-radius:10px; text-decoration:none; font-weight:bold;">تفعيل الحساب</a>`
  );
}

export function resetPasswordEmail(link: string) {
  return BRAND_WRAPPER(
    "إعادة تعيين كلمة المرور",
    `<p>طلبت إعادة تعيين كلمة المرور. اضغط الزر (صالح لمدة ساعة واحدة). إذا لم تكن أنت، تجاهل هذه الرسالة:</p>
     <a href="${link}" style="display:inline-block; margin-top:12px; background:#eab308; color:#000; padding:12px 24px; border-radius:10px; text-decoration:none; font-weight:bold;">إعادة تعيين كلمة المرور</a>`
  );
}

export function orderStatusEmail(orderId: string, status: string) {
  const labels: Record<string, string> = {
    PENDING: "قيد الانتظار",
    PROCESSING: "قيد المعالجة",
    COMPLETED: "مكتمل",
    CANCELLED: "ملغى",
  };
  return BRAND_WRAPPER(
    "تحديث حالة طلبك",
    `<p>طلبك <strong>#${orderId.slice(-8)}</strong> أصبحت حالته الآن: <strong style="color:#eab308;">${labels[status] ?? status}</strong></p>`
  );
}

export function topUpConfirmedEmail(amount: number) {
  return BRAND_WRAPPER(
    "تم شحن رصيدك",
    `<p>تم تأكيد شحن <strong style="color:#eab308;">${amount.toLocaleString("ar-MA")} £</strong> في محفظتك. يمكنك الآن استخدامه للشراء.</p>`
  );
}
