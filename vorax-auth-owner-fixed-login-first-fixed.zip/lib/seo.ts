import type { Metadata } from "next";
import { CURRENCY_NAME, formatTikoun } from "@/lib/currency";

// Single source of truth for the public site URL — used by sitemap.ts,
// robots.ts, and every generateMetadata() below. Reuses the same
// NEXT_PUBLIC_APP_URL already set for email links (see lib/tokens usage
// in the auth routes) so there's only one URL to configure.
export const SITE_URL = (process.env.NEXT_PUBLIC_APP_URL ?? "http://localhost:3000").replace(/\/$/, "");

export const SITE_NAME = "VORAX";

// Reused as the default OpenGraph/Twitter image wherever a page doesn't
// set its own (product pages override this with numberMetadata below).
// The favicon/app-icon itself is handled automatically by Next.js from
// app/icon.png — no extra config needed for that part.
const DEFAULT_OG_IMAGE = `${SITE_URL}/logo.png`;

/** Spread this into the root layout's `export const metadata` for
 * sitewide defaults (title template, default OG image, icons). */
export const siteMetadata: Metadata = {
  title: { default: "VORAX — منصة الخدمات الرقمية", template: `%s | ${SITE_NAME}` },
  description: "VORAX منصة رقمية متكاملة لشراء وإدارة الخدمات والأرقام الرقمية بسهولة وأمان.",
  metadataBase: new URL(SITE_URL),
  openGraph: {
    siteName: SITE_NAME,
    locale: "ar_MA",
    images: [{ url: DEFAULT_OG_IMAGE, width: 1254, height: 1254 }],
  },
  twitter: { card: "summary", images: [DEFAULT_OG_IMAGE] },
};

const NUMBER_TYPE_LABEL: Record<string, string> = {
  NORMAL: "عادي",
  VIP: "VIP",
  REPEATED: "مكرر",
  EASY: "سهل",
  INTERNATIONAL: "دولي",
  VIRTUAL: "افتراضي",
};

type NumberForSeo = {
  id: string;
  phone: string;
  price: number;
  type: string;
  description?: string | null;
  country: { name: string; code: string; dial: string };
};

/**
 * Metadata for a single number's product page (app/numbers/[id]/page.tsx).
 * Call from generateMetadata() with the number fetched by prisma.
 */
export function numberMetadata(n: NumberForSeo): Metadata {
  const typeLabel = NUMBER_TYPE_LABEL[n.type] ?? n.type;
  const title = `${n.phone} — رقم ${typeLabel} من ${n.country.name} | ${SITE_NAME}`;
  const description =
    n.description?.trim() ||
    `اشري رقم هاتف ${typeLabel} من ${n.country.name} (${n.country.dial}) بـ ${formatTikoun(
      n.price
    )} على ${SITE_NAME}. توصيل فوري وضمان.`;
  const url = `${SITE_URL}/numbers/${n.id}`;

  return {
    title,
    description,
    alternates: { canonical: url },
    openGraph: {
      title,
      description,
      url,
      siteName: SITE_NAME,
      locale: "ar_MA",
      type: "website",
    },
    twitter: {
      card: "summary",
      title,
      description,
    },
  };
}

/**
 * Metadata for a country listing page (app/country/[code]/page.tsx or
 * app/numbers/page.tsx?country=CODE, depending on your routing).
 */
export function countryMetadata(country: { name: string; code: string }, count?: number): Metadata {
  const title = `أرقام هاتف من ${country.name} للبيع | ${SITE_NAME}`;
  const description =
    typeof count === "number"
      ? `${count} رقم هاتف متوفر من ${country.name} (VIP، مكرر، سهل، دولي). اشري بـ ${CURRENCY_NAME} مع توصيل فوري.`
      : `أرقام هاتف مميزة من ${country.name} للبيع على ${SITE_NAME}. اشري بـ ${CURRENCY_NAME} مع توصيل فوري.`;
  const url = `${SITE_URL}/country/${country.code}`;

  return {
    title,
    description,
    alternates: { canonical: url },
    openGraph: { title, description, url, siteName: SITE_NAME, locale: "ar_MA" },
  };
}

/**
 * Schema.org Product JSON-LD for a featured/single number. Render the
 * result inside a <script type="application/ld+json"> tag — see
 * components/ProductSchema.tsx for the ready-made component.
 */
export function numberProductJsonLd(n: NumberForSeo) {
  const typeLabel = NUMBER_TYPE_LABEL[n.type] ?? n.type;
  return {
    "@context": "https://schema.org",
    "@type": "Product",
    name: `رقم ${typeLabel} — ${n.phone}`,
    description:
      n.description?.trim() || `رقم هاتف ${typeLabel} من ${n.country.name} (${n.country.dial}).`,
    sku: n.id,
    category: `أرقام هاتف/${n.country.name}`,
    offers: {
      "@type": "Offer",
      url: `${SITE_URL}/numbers/${n.id}`,
      priceCurrency: "MAD", // Tikoun is pegged 1:1 for display purposes; adjust if not.
      price: n.price,
      availability: "https://schema.org/InStock",
    },
  };
}
