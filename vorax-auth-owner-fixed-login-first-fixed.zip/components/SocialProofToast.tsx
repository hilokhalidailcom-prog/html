"use client";

import { useEffect, useState } from "react";

type Purchase = {
  maskedName: string;
  countryName: string;
  countryFlag: string;
  at: string;
};

// Fixed-position toast that cycles through recent purchases:
// "محمد. اشترى رقم من 🇲🇦 المغرب — قبل 4 دقائق"
// Mount once near the root layout. Fetches its own data client-side so
// it doesn't block the initial page render.
export default function SocialProofToast() {
  const [purchases, setPurchases] = useState<Purchase[]>([]);
  const [index, setIndex] = useState(0);
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    let cancelled = false;
    fetch("/api/social-proof")
      .then((r) => r.json())
      .then((data) => {
        if (!cancelled) setPurchases(data.purchases ?? []);
      })
      .catch(() => {});
    return () => {
      cancelled = true;
    };
  }, []);

  useEffect(() => {
    if (purchases.length === 0) return;
    const showTimer = setInterval(() => {
      setIndex((i) => (i + 1) % purchases.length);
      setVisible(true);
      const hideTimer = setTimeout(() => setVisible(false), 5000);
      return () => clearTimeout(hideTimer);
    }, 9000);
    // show the first one shortly after mount
    const first = setTimeout(() => setVisible(true), 2000);
    const firstHide = setTimeout(() => setVisible(false), 7000);
    return () => {
      clearInterval(showTimer);
      clearTimeout(first);
      clearTimeout(firstHide);
    };
  }, [purchases]);

  if (purchases.length === 0) return null;
  const p = purchases[index];

  return (
    <div
      dir="rtl"
      className={`fixed bottom-4 left-4 z-50 flex items-center gap-2 rounded-xl border border-neon-purple/20 bg-neon-card/95 px-4 py-3 text-sm text-neon-text shadow-lg backdrop-blur transition-all duration-500 ${
        visible ? "translate-y-0 opacity-100" : "pointer-events-none translate-y-4 opacity-0"
      }`}
    >
      <span className="text-lg">{p.countryFlag}</span>
      <span>
        <strong className="text-neon-purpleBright">{p.maskedName}</strong> اشترى رقم من {p.countryName}
      </span>
    </div>
  );
}
