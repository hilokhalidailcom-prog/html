"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useEffect, useState } from "react";
import { useSession, signOut } from "next-auth/react";
import Logo from "./Logo";
import Icon from "./Icon";
import { formatTikoun } from "@/lib/currency";

const NAV = [
  { href: "/dashboard", label: "الرئيسية", icon: "home" as const },
  { href: "/store", label: "المتجر", icon: "store" as const },
  { href: "/store?service=whatsapp", label: "WhatsApp", icon: "whatsapp" as const },
  { href: "/store?service=telegram", label: "Telegram", icon: "telegram" as const },
  { href: "/wallet", label: "المحفظة", icon: "wallet" as const },
  { href: "/orders", label: "طلباتي", icon: "orders" as const },
  { href: "/chat", label: "الشات", icon: "chat" as const },
  { href: "/notifications", label: "الإشعارات", icon: "bell" as const },
  { href: "/support", label: "الدعم", icon: "support" as const },
  { href: "/account", label: "حسابي", icon: "user" as const },
];

const MOBILE_NAV = [
  { href: "/dashboard", label: "الرئيسية", icon: "home" as const },
  { href: "/store", label: "الخدمات", icon: "grid" as const },
  { href: "/orders", label: "الطلبات", icon: "orders" as const },
  { href: "/chat", label: "الشات", icon: "chat" as const },
  { href: "/account", label: "حسابي", icon: "user" as const },
];

function isActive(pathname: string, href: string) {
  const base = href.split("?")[0];
  if (base === "/dashboard" || base === "/") return pathname === base;
  return pathname === base || pathname.startsWith(`${base}/`);
}

export default function AppShell({ children }: { children: React.ReactNode }) {
  const pathname = usePathname();
  const { data: session } = useSession();
  const [balance, setBalance] = useState<number | null>(null);

  useEffect(() => {
    if (!session?.user) return;
    let cancelled = false;
    fetch("/api/wallet/topup-request", { cache: "no-store" })
      .then((r) => (r.ok ? r.json() : null))
      .then((data) => { if (!cancelled && data) setBalance(data.balance ?? 0); })
      .catch(() => {});
    return () => { cancelled = true; };
  }, [session?.user]);

  return (
    <div dir="rtl" className="min-h-screen bg-neon-bg text-neon-text">
      <div className="mx-auto flex min-h-screen max-w-[1600px]">
        <aside className="sticky top-0 hidden h-screen w-64 shrink-0 flex-col border-l border-neon-border/80 bg-neon-surface/80 p-4 backdrop-blur-xl lg:flex">
          <Logo size="header" className="mb-8 px-2" priority />
          <nav className="flex flex-1 flex-col gap-1.5">
            {NAV.map((item) => {
              const active = isActive(pathname, item.href);
              return (
                <Link key={item.href} href={item.href} className={`flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium transition-all ${active ? "bg-neon-purple/15 text-neon-purpleBright shadow-[inset_2px_0_0_#A855F7]" : "text-neon-muted hover:bg-neon-cardHover hover:text-white"}`}>
                  <Icon name={item.icon} size={18} />
                  <span>{item.label}</span>
                </Link>
              );
            })}
          </nav>
          <button onClick={() => signOut({ callbackUrl: "/login" })} className="flex items-center gap-3 rounded-xl border border-neon-border px-3 py-2.5 text-sm text-neon-muted transition hover:border-neon-danger/50 hover:text-neon-danger">
            <Icon name="logout" size={18} />
            تسجيل خروج
          </button>
        </aside>

        <div className="flex min-w-0 flex-1 flex-col">
          <header className="sticky top-0 z-30 border-b border-neon-border/80 bg-neon-bg/85 px-4 py-3 backdrop-blur-xl lg:px-8">
            <div className="flex items-center gap-3">
              <div className="lg:hidden"><Logo size="header" /></div>
              <div className="hidden flex-1 lg:block">
                <Link href="/store" className="flex max-w-xl items-center gap-3 rounded-xl border border-neon-border bg-neon-surface/70 px-4 py-2.5 text-sm text-neon-muted transition hover:border-neon-purple/60 hover:text-white">
                  <Icon name="search" size={18} />
                  <span>ابحث عن رقم أو خدمة...</span>
                </Link>
              </div>
              <div className="mr-auto flex items-center gap-2 lg:mr-0">
                <Link href="/notifications" aria-label="الإشعارات" className="rounded-xl border border-neon-border bg-neon-surface p-2.5 text-neon-muted transition hover:text-white"><Icon name="bell" size={18} /></Link>
                <Link href="/wallet" className="flex items-center gap-2 rounded-xl bg-gradient-to-l from-neon-purple to-neon-purpleBright px-3 py-2 text-sm font-bold text-white shadow-[0_8px_30px_rgba(124,58,237,0.22)]">
                  <Icon name="wallet" size={17} />
                  <span>{balance === null ? "..." : formatTikoun(balance)}</span>
                </Link>
                <Link href="/account" aria-label="الحساب" className="hidden rounded-xl border border-neon-border bg-neon-surface p-2.5 text-neon-muted transition hover:text-white sm:block"><Icon name="user" size={18} /></Link>
              </div>
            </div>
          </header>
          <main className="flex-1 px-4 pb-24 pt-5 lg:px-8 lg:pb-8 lg:pt-7">{children}</main>
        </div>
      </div>

      <nav className="fixed inset-x-0 bottom-0 z-40 grid grid-cols-5 border-t border-neon-border bg-neon-surface/95 py-2 backdrop-blur-xl lg:hidden">
        {MOBILE_NAV.map((item) => {
          const active = isActive(pathname, item.href);
          return <Link key={item.href} href={item.href} className={`flex flex-col items-center gap-1 px-2 py-1 text-[11px] font-medium ${active ? "text-neon-purpleBright" : "text-neon-muted"}`}><Icon name={item.icon} size={19} /><span>{item.label}</span></Link>;
        })}
      </nav>
    </div>
  );
}
