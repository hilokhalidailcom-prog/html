import { numberProductJsonLd } from "@/lib/seo";

type Props = {
  number: {
    id: string;
    phone: string;
    price: number;
    type: string;
    description?: string | null;
    country: { name: string; code: string; dial: string };
  };
};

// Drop this in app/numbers/[id]/page.tsx next to the product content:
//   <ProductSchema number={number} />
// It renders nothing visible — just the structured data Google reads.
export default function ProductSchema({ number }: Props) {
  const json = numberProductJsonLd(number);
  return (
    <script
      type="application/ld+json"
      // eslint-disable-next-line react/no-danger
      dangerouslySetInnerHTML={{ __html: JSON.stringify(json) }}
    />
  );
}
