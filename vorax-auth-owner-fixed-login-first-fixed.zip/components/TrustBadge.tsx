import { getTrustStats } from "@/lib/stats";

// Server component — drop anywhere (homepage hero, product page) with
// no props. Data is cached 5 min via unstable_cache, so this never adds
// a blocking per-request query.
export default async function TrustBadge() {
  const { soldCount, averageRating, reviewCount } = await getTrustStats();

  if (soldCount === 0) return null;

  return (
    <div className="flex flex-wrap items-center gap-2 text-sm">
      <span className="inline-flex items-center gap-1 rounded-full border border-neon-purple/30 bg-neon-purple/10 px-3 py-1 font-medium text-neon-purpleBright">
        ✓ منصة موثوقة
      </span>
      <span className="text-neon-muted">
        تم بيع{" "}
        <strong className="text-white">{soldCount.toLocaleString("ar-MA")}</strong> رقم
      </span>
      {reviewCount > 0 && (
        <span className="text-neon-muted">
          · تقييم{" "}
          <strong className="text-white">{averageRating.toFixed(1)}</strong>/5 (
          {reviewCount.toLocaleString("ar-MA")} رأي)
        </span>
      )}
    </div>
  );
}
