"use client";

import { formatTikoun } from "@/lib/currency";

interface Props {
  open: boolean;
  onClose: () => void;
  neededAmount?: number;
}

export default function InsufficientBalanceModal({ open, onClose, neededAmount }: Props) {
  if (!open) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-neon-bg/70 backdrop-blur-sm" onClick={onClose}>
      <div className="mx-4 w-full max-w-sm rounded-2xl border border-neon-purple/30 bg-neon-card p-6 text-center shadow-[0_0_40px_rgba(14,165,233,0.2)]" onClick={(e) => e.stopPropagation()} dir="rtl">
        <div className="mb-3 text-5xl">😅</div>
        <h2 className="mb-2 text-xl font-bold text-neon-purpleBright">أوووبس، ما عندكش رصيد كافي!</h2>
        <p className="mb-1 text-sm text-neon-muted">اشحن رصيدك مباشرة من منصة VORAX</p>
        {neededAmount ? (
          <p className="mb-5 text-sm text-neon-muted">المبلغ المطلوب: <span className="font-semibold text-neon-purpleBright">{formatTikoun(neededAmount)}</span></p>
        ) : <div className="mb-5" />}
        <div className="flex flex-col gap-2">
          <a href="/wallet" className="flex items-center justify-center rounded-xl bg-gradient-to-r from-blue-600 to-neon-purpleBright px-4 py-3 font-semibold text-white transition hover:brightness-110">💳 فتح المحفظة وشحن الرصيد</a>
        </div>
        <button onClick={onClose} className="mt-4 text-sm text-neon-muted underline underline-offset-4 hover:text-neon-text">إلغاء</button>
      </div>
    </div>
  );
}
