"use client";

import { useCart } from "@/lib/cart-context";
import { formatTikoun } from "@/lib/currency";

interface Props {
  numberId: string;
  phone: string;
  price: number;
  countryFlag?: string;
}

export default function AddToCartButton({ numberId, phone, price, countryFlag }: Props) {
  const { items, addItem } = useCart();
  const inCart = items.some((i) => i.numberId === numberId);

  return (
    <button
      disabled={inCart}
      onClick={() => addItem({ numberId, phone, price, countryFlag })}
      className="rounded-lg bg-neon-purple px-4 py-2 text-sm font-bold text-white transition hover:brightness-110 disabled:cursor-not-allowed disabled:bg-neon-cardHover disabled:text-neon-muted"
    >
      {inCart ? "في السلة ✓" : `أضف للسلة — ${formatTikoun(price)}`}
    </button>
  );
}
