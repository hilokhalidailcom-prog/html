import Image from "next/image";
import Link from "next/link";

type Props = {
  /** "header" = small nav logo, "hero" = large logo for landing/empty states */
  size?: "header" | "hero";
  className?: string;
  /** Set true only for the single logo instance that's above the fold on first paint (e.g. the navbar). */
  priority?: boolean;
};

const SIZES = {
  header: { px: 40, src: "/logo-header.png" },
  hero: { px: 180, src: "/logo.png" },
} as const;

// next/image handles resizing, format conversion (webp/avif), and lazy
// loading automatically — this replaces any <img src="/logo..."> tag.
// /logo-header.png is a pre-shrunk 320x320 copy so the navbar never
// downloads the full 1254x1254 source.
export default function Logo({ size = "header", className, priority }: Props) {
  const { px, src } = SIZES[size];
  return (
    <Link href="/" aria-label="VORAX" className={className}>
      <Image
        src={src}
        alt="VORAX — متجرك للأرقام والخدمات الرقمية"
        width={px}
        height={px}
        priority={priority}
        className="select-none"
      />
    </Link>
  );
}
