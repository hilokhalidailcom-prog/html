# VORAX Owner Login

The current VORAX schema uses `ADMIN` as the owner-level role.

Owner account configured:
- Email: `alexalexronaldo07@gmail.com`
- Role: `ADMIN` (Owner)
- Email verification: pre-verified by the bootstrap

The owner email has a safe default in `prisma/seed-owner.ts`. The owner password is intentionally **not** stored in GitHub or inside the source code.

Run after installing dependencies and configuring `DATABASE_URL`:

```bash
npm install
npx prisma generate
OWNER_EMAIL="alexalexronaldo07@gmail.com" OWNER_PASSWORD="ضع_كلمة_مرور_المالك_في_بيئة_الخادم" npm run owner:bootstrap
```

The password is never stored as plaintext; the bootstrap stores only a bcrypt hash.
After bootstrapping, sign in at `/login`.
