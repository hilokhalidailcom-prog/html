# VORAX Production Setup

## Required environment variables

- `DATABASE_URL` — PostgreSQL connection string.
- `AUTH_SECRET` — long random secret used by NextAuth/Auth.js.
- `NEXT_PUBLIC_APP_URL` — canonical HTTPS URL of the deployed VORAX app.
- `AUTH_TRUST_HOST=true` — required for the trusted reverse-proxy deployment path used by Netlify.

Optional:

- `GOOGLE_CLIENT_ID` / `GOOGLE_CLIENT_SECRET` — enables Google sign-in. If omitted, the Google button is disabled and credentials login remains available.
- `RESEND_API_KEY` / `EMAIL_FROM` — email delivery.
- `SENTRY_DSN` — error reporting.

## Netlify

Build command:

```bash
npm run build
```

The project uses the Next.js App Router and must **not** use `output: "export"`.
`netlify.toml` uses `@netlify/plugin-nextjs` and `.next` as the publish directory.

After changing environment variables or build configuration, run a clean deploy / clear build cache.

## Database

Run migrations with:

```bash
npm run db:deploy
```

Before production activation, verify:

```bash
npm run preflight
npm run typecheck
npm run build
npm test
```

## Telegram policy

Telegram is a **VORAX marketplace category only**. It is not a bot integration, account-linking system, webhook, or chat bridge. Customer/merchant chat stays inside VORAX.

Do not add Telegram bot credentials to production unless a future product decision explicitly reintroduces that integration.
