import { prisma } from "@/lib/prisma";
import type { Role } from "@prisma/client";

/**
 * VORAX permission model
 * -----------------------
 * OWNER      -> stored as Role.ADMIN (unchanged from before this feature,
 *               so nothing that already checks `role === "ADMIN"` breaks).
 *               Implicitly has every permission — never consult `permissions`.
 * DEVELOPER  -> Role.DEVELOPER. Only has the specific strings in
 *               `User.permissions`. Never gets more than what was granted.
 * MERCHANT   -> Role.MERCHANT. Can only manage their own Merchant record —
 *               checked via ownership (merchant.userId === session.user.id),
 *               not via the permission-string system below.
 * USER       -> Role.USER (= CUSTOMER in the spec's naming). No admin
 *               permissions at all.
 *
 * All of the permission strings a DEVELOPER can be granted, per spec §15.
 * Keep this list in sync with what routes actually check — a permission
 * that exists here but nothing checks is dead weight; a check for a
 * permission not listed here can never be granted through the UI.
 */
export const MERCHANT_PERMISSIONS = [
  "merchant.view",
  "merchant.create",
  "merchant.edit",
  "merchant.suspend",
  "merchant.products",
  "merchant.orders",
  "merchant.withdrawals",
  "merchant.approve",
  "merchant.commissions",
] as const;

export type MerchantPermission = (typeof MERCHANT_PERMISSIONS)[number];

export type SessionUser = {
  id: string;
  role: Role;
  permissions?: string[];
};

export function isOwner(user: SessionUser | null | undefined): boolean {
  return user?.role === "ADMIN";
}

export function isDeveloper(user: SessionUser | null | undefined): boolean {
  return user?.role === "DEVELOPER";
}

export function isMerchant(user: SessionUser | null | undefined): boolean {
  return user?.role === "MERCHANT";
}

/** Owner or developer — i.e. "staff", allowed into /admin at all. */
export function isStaff(user: SessionUser | null | undefined): boolean {
  return isOwner(user) || isDeveloper(user);
}

/**
 * Does this user have the given permission?
 * OWNER always yes. DEVELOPER only if it's in their granted list.
 * Everyone else: no — this function is for staff-only actions.
 */
export function hasPermission(
  user: SessionUser | null | undefined,
  permission: MerchantPermission
): boolean {
  if (!user) return false;
  if (isOwner(user)) return true;
  if (isDeveloper(user)) return (user.permissions ?? []).includes(permission);
  return false;
}

/**
 * Server-side guard for API routes. Returns null if allowed, or a
 * ready-to-return NextResponse-shaped object if not — call sites do:
 *
 *   const denied = await requirePermission(session, "merchant.create");
 *   if (denied) return denied;
 *
 * This is what actually enforces §51 ("Backend must check this, not just
 * hide buttons") — middleware.ts only gets DEVELOPER as far as /api/admin/*,
 * each route decides for itself which specific permission it needs.
 */
export async function requirePermission(
  user: SessionUser | null | undefined,
  permission: MerchantPermission
): Promise<{ status: number; body: { error: string } } | null> {
  if (!user) return { status: 401, body: { error: "غير مسجل الدخول" } };
  if (!hasPermission(user, permission)) {
    return { status: 403, body: { error: "لا تملك الصلاحية الكافية لهذا الإجراء" } };
  }
  return null;
}

/**
 * Fetch the Merchant record owned by this user, or null. Used by every
 * /api/merchant/* route to scope queries to "my store only" — this is the
 * ownership check spec §51's example (Merchant A editing Merchant B's
 * product) depends on.
 */
export async function getOwnMerchant(userId: string) {
  return prisma.merchant.findUnique({ where: { userId } });
}

/** Write one row to ActivityLog. Never throws — logging must not break the action it's logging. */
export async function logActivity(entry: {
  actorId?: string | null;
  actorRole?: Role | null;
  action: string;
  targetType?: string;
  targetId?: string;
  meta?: Record<string, unknown>;
}) {
  try {
    await prisma.activityLog.create({
      data: {
        actorId: entry.actorId ?? null,
        actorRole: entry.actorRole ?? null,
        action: entry.action,
        targetType: entry.targetType,
        targetId: entry.targetId,
        meta: entry.meta as any,
      },
    });
  } catch (err) {
    console.error("[activityLog] failed to write:", err);
  }
}
