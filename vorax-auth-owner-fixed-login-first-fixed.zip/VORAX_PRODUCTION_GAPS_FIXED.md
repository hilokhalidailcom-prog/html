# VORAX — Production Gaps Fixed

This release closes the source-level operational gaps identified in the previous package:

- Added production environment validation and database preflight.
- Added a health check that verifies PostgreSQL connectivity.
- Added production database bootstrap fallback when the archive has no committed Prisma migrations.
- Added Docker health checks and dedicated reservation, alert, and notification worker services.
- Added explicit production environment variables for Telegram owner authorization and API routing.
- Replaced Telegram top-up flow with an in-platform wallet top-up request flow; the owner now reviews and approves/rejects requests from `/admin/topups`.
- Added Telegram balance and owner-only top-up approval endpoints.
- Added an idempotent top-up approval transaction that writes the balance transaction audit entry.
- Removed the old mismatch where the bot called `/api/topups/*` while the app exposed different routes.
- Documented the polling/webhook exclusivity for Telegram.

## Still dependent on deployment credentials

No code can manufacture real infrastructure credentials. Before public launch, set the real PostgreSQL URL, HTTPS domain, Telegram token/owner ID/webhook secret, email credentials if email is enabled, and external backup storage if off-site backups are required.
- Removed the committed `.env` from the distributable package so credentials are not shipped in the archive.
- Docker now runs production setup before starting the application and waits for the database health check.
- Added optional off-host backup upload via a pre-signed `BACKUP_STORAGE_URL`.
